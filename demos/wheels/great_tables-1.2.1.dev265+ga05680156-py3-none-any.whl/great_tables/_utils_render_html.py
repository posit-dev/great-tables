from __future__ import annotations

import html as html_lib
import re
from dataclasses import dataclass, field
from itertools import chain
from typing import TYPE_CHECKING, Any, cast

from . import _locations as loc
from ._data_color.utils import _html_color
from ._gt_data import (
    _NO_GROUP,
    ColInfo,
    ColInfoTypeEnum,
    FootnoteInfo,
    FootnotePlacement,
    GroupRowInfo,
    GTData,
    StyleInfo,
    Styles,
    SummaryRowInfo,
)
from ._html import HTML, Tag, TagList, css
from ._spanners import spanners_print_matrix
from ._styles import CellStyleBorders, CellStyleFill, CellStyleText, _FillWithoutContrastText
from ._tbl_data import TblData, _get_cell, cast_frame_to_string, replace_null_frame
from ._text import BaseText, _process_text
from ._theme import CSS_COLOR_KEYWORDS, dark_blend, foreground_option
from ._utils import heading_has_subtitle, heading_has_title, seq_groups

if TYPE_CHECKING:
    from ._tbl_data import TblData


# TODO: The footnote ordering functions (_get_locnum_for_footnote_location,
# _get_summary_locnum, _get_footnote_mark_string, _process_footnotes_for_display)
# should be extracted to a shared module (e.g., _footnote_ordering.py) so that
# LaTeX and other renderers can reuse the same ordering logic.


def _get_locnum_for_footnote_location(locname: loc.Loc | None) -> int | float:
    """Get the visual hierarchy order for footnote location ordering."""
    if locname is None:
        return 999

    # Visual hierarchy mapping for footnote location ordering
    if isinstance(locname, loc.LocTitle):
        return 1
    elif isinstance(locname, loc.LocSubTitle):
        return 2
    elif isinstance(locname, (loc.LocStubhead, loc.LocStubheadLabel)):
        return 3
    elif isinstance(locname, (loc.LocColumnHeader, loc.LocSpannerLabels)):
        return 4
    elif isinstance(locname, loc.LocColumnLabels):
        return 5
    elif isinstance(locname, (loc.LocBody, loc.LocStub, loc.LocRowGroups)):
        return 6
    elif isinstance(locname, (loc.LocSummaryStub, loc.LocSummary)):
        return 7
    elif isinstance(locname, (loc.LocGrandSummaryStub, loc.LocGrandSummary)):
        return 8
    else:
        return 999  # Default to 999 for unknown locations


def _get_summary_locnum(data: GTData, fn_info: FootnoteInfo) -> int | float:
    """Get the locnum for a summary footnote, accounting for side positioning.

    When summary rows are side="top", they appear visually before body rows.
    Grand summary (top) appears above group summaries (top), which appear above body rows.
    Row group labels visually attach to the first row of their group (summary top or body).
    """
    locnum = _get_locnum_for_footnote_location(fn_info.locname)

    if isinstance(fn_info.locname, (loc.LocSummaryStub, loc.LocSummary)):
        # Group summary: check the side of the targeted summary row
        group_id = fn_info.grpname
        summary_rows = data._summary_rows.get_summary_rows(group_id=group_id)
        if not summary_rows:
            return locnum

        # Determine the side of the specific summary row targeted by this footnote
        rownum = fn_info.rownum if fn_info.rownum is not None else 0
        if rownum < len(summary_rows) and summary_rows[rownum].side == "top":
            return 5.6  # After grand summary top (5.4), before body (6)

    elif isinstance(fn_info.locname, (loc.LocGrandSummaryStub, loc.LocGrandSummary)):
        # Grand summary: check side of the targeted grand summary row
        grand_summary_rows = data._summary_rows_grand.get_summary_rows()
        if not grand_summary_rows:
            return locnum

        rownum = fn_info.rownum if fn_info.rownum is not None else 0
        if rownum < len(grand_summary_rows) and grand_summary_rows[rownum].side == "top":
            return 5.4  # Before group summary top (5.6) and body (6)

    elif isinstance(fn_info.locname, loc.LocRowGroups):
        # Row group labels visually appear on the same row as the first item in
        # their group. When the group has top summary rows, the row group label
        # is on the same row as the first top summary row.
        group_id = fn_info.grpname
        summary_rows = data._summary_rows.get_summary_rows(group_id=group_id)
        if summary_rows and summary_rows[0].side == "top":
            return 5.6  # Same tier as group summary top (colnum -2 sorts left)

    return locnum


def _is_loc(loc: str | loc.Loc, cls: type[loc.Loc]):
    if isinstance(loc, str):
        return loc == cls.groups  # pragma: no cover

    return isinstance(loc, cls)


# A hex color whose alpha channel is not fully opaque
TRANSLUCENT_HEX = re.compile(
    r"#(?:[0-9a-f]{3}[0-9a-e]|[0-9a-f]{6}(?:[0-9a-f][0-9a-e]|[0-9a-e][0-9a-f]))", re.IGNORECASE
)


def _dark_aware_color(style_entries: list[Any]) -> tuple[int | None, str] | None:
    """
    The declaration that makes a cell's literal colors work in dark mode, and where it goes: after
    the style entry at the index given, or before all of them (`None`). `None` if there is none.

    A fill with no text color gets the table's text color for its brightness; it goes first, so
    that any color the user wrote wins. A fill that `data_color()` made with `autocolor_text=False`
    gets it in dark mode only (`light-dark()` picks by the table's `color-scheme`), and keeps the
    inherited text color in light mode. A text color with no fill is blended toward the inherited
    text color in dark mode only, right after that color. Colors that aren't plain strings, or that
    can't be parsed, add nothing.
    """
    fills = [el for el in style_entries if isinstance(el, CellStyleFill)]
    texts = [i for i, el in enumerate(style_entries) if isinstance(el, CellStyleText) and el.color]

    if fills and not texts:
        # (The last fill is the one drawn)
        fill = fills[-1]

        # (Only an opaque color has a brightness: a keyword or a translucent color shows what is
        # behind or around it)
        color = fill.color
        try:
            usable = (
                isinstance(color, str)
                and color.strip().lower() not in CSS_COLOR_KEYWORDS
                and not TRANSLUCENT_HEX.fullmatch(_html_color([color.strip()])[0])
            )
            option = foreground_option(color) if usable else None
        except ValueError:
            option = None

        if option is None:
            return None
        text = TEXT_VARS[option]
        if isinstance(fill, _FillWithoutContrastText):
            # (`currentcolor` in `color` is the inherited color)
            return None, f"color: light-dark(currentcolor, {text});"
        return None, f"color: {text};"

    elif texts and not fills and isinstance(style_entries[texts[-1]].color, str):
        color = style_entries[texts[-1]].color
        return texts[-1], f"color: light-dark({color}, {dark_blend(color)});"

    return None


TEXT_VARS = {
    "table_font_color": "var(--_gt-text-dark)",
    "table_font_color_light": "var(--_gt-text-light)",
}


def _dark_aware_borders(entry: CellStyleBorders) -> str:
    """The declarations that blend a cell's border color toward its text color in dark mode only
    (as the default black would vanish on a dark table), each with a leading space, or `""`."""
    color = entry.color
    if not isinstance(color, str) or color.strip().lower() in CSS_COLOR_KEYWORDS:
        return ""
    sides = [entry.sides] if isinstance(entry.sides, str) else entry.sides
    if "all" in sides:
        sides = ["top", "bottom", "left", "right"]
    blend = f"light-dark({color}, {dark_blend(color)})"
    return "".join(f" border-{side}-color: {blend};" for side in sides)


def _flatten_styles(styles: Styles, wrap: bool = False) -> str | None:
    # flatten all StyleInfo.styles lists
    style_entries = list(chain.from_iterable(x.styles for x in styles))
    rendered_styles = [el._to_html_style() for el in style_entries]
    for i, el in enumerate(style_entries):
        if isinstance(el, CellStyleBorders) and rendered_styles[i]:
            rendered_styles[i] += _dark_aware_borders(el)

    dark_aware = _dark_aware_color(style_entries)
    if dark_aware is not None:
        after, declaration = dark_aware
        if after is None:
            rendered_styles.insert(0, declaration)
        else:
            # (A text style writes its color first)
            authored = f"color: {style_entries[after].color};"
            rest = rendered_styles[after].removeprefix(authored)
            rendered_styles[after] = f"{authored} {declaration}{rest}"

    # TODO dedupe rendered styles in sequence

    if wrap:
        if rendered_styles:
            # return style html attribute
            return f' style="{" ".join(rendered_styles)}"'
        # if no rendered styles, just return a blank
        return ""
    if rendered_styles:
        # return space-separated list of rendered styles
        return " ".join(rendered_styles)
    # if not wrapping the styles for html element,
    # return None so that no style attribute is written
    return None


def _wrap_rotated_column_label(text: str, info: ColInfo) -> HTML | Tag:
    """Wrap a label from `cols_label_rotate()` in a span that rotates it.

    The `writing-mode` is set on the span and not on the `<th>`, since Safari doesn't size a
    rotated cell for its text and so wraps short labels. The `height: max-content` keeps the label
    on one line: Safari shows only the first line of a rotated label that wraps.
    """
    if info.column_label_rotate is None:
        return HTML(text)

    return Tag(
        "span",
        HTML(text),
        style=f"writing-mode: {info.column_label_rotate}; height: max-content;",
    )


def _make_svg_ids_unique(html_str: str, prefix: str) -> str:
    """Prefix the ids defined in each SVG of `html_str`, and the references to them."""

    prefix = _sanitize_id(prefix)

    def rewrite_svg(match: re.Match[str]) -> str:
        svg = match.group(0)
        for svg_id in set(re.findall(r'\bid="([^"]+)"', svg)):
            new_id = f"{prefix}-{svg_id}"
            escaped = re.escape(svg_id)
            svg = re.sub(rf'\bid="{escaped}"', f'id="{new_id}"', svg)
            svg = re.sub(rf"url\(#{escaped}\)", f"url(#{new_id})", svg)
            svg = re.sub(rf'(href=)"#{escaped}"', rf'\1"#{new_id}"', svg)
        return svg

    return re.sub(r"<svg\b.*?</svg>", rewrite_svg, html_str, flags=re.DOTALL)


def _sanitize_id(text: str) -> str:
    """Turn label text (which may be HTML) into a valid id: no markup, spaces or punctuation."""
    text = html_lib.unescape(re.sub(r"<[^>]+>", "", text))
    return re.sub(r"[^\w.:-]+", "-", text).strip("-")


class _IdRegistry:
    """Make element ids that are valid and unique within a table.

    Ids are prefixed by the table id when one is set (`GT(id=)`), so that they're also unique
    across tables on a page. A repeated id gets a numeric suffix (`num`, `num-2`).
    """

    def __init__(self, table_id: str | None) -> None:
        prefix = _sanitize_id(table_id) if table_id else ""
        self.prefix = f"{prefix}-" if prefix else ""
        self.used: set[str] = {table_id} if table_id else set()

    def make(self, base: Any, fallback: str) -> str:
        # Labels may be text or `md()`/`html()` objects; group ids may be any value (e.g., numbers)
        text = (
            _process_text(base)
            if isinstance(base, (str, BaseText))
            else ""
            if base is None
            else str(base)
        )
        name = _sanitize_id(text) or fallback
        candidate = f"{self.prefix}{name}"
        n = 2
        while candidate in self.used:
            candidate = f"{self.prefix}{name}-{n}"
            n += 1
        self.used.add(candidate)
        return candidate


@dataclass
class _HeaderIds:
    """The ids of a table's header cells, and the `headers` of its body cells (HTML output).

    The stubhead, column label, spanner, title and subtitle ids are made first (in that order, so
    that they're the same in the heading, the column labels and the body); group heading, stub and
    summary label ids are made as the body is rendered, where `group` and `stub` hold the ids of
    the headers of the current row (a stub cell merged across rows heads all of them). The title
    and subtitle ids name and describe the table (`aria-labelledby` / `aria-describedby`).
    """

    registry: _IdRegistry
    stubhead: list[str]
    columns: dict[str, str]
    spanners: dict[str, str]
    column_spanners: dict[str, list[str]]
    title: str | None = None
    subtitle: str | None = None
    group: str | None = None
    stub: dict[int, str] = field(default_factory=dict)

    def cell_headers(self, var: str, row_headers: list[str]) -> str:
        """The `headers` attribute of a body cell in column `var`, given its row's headers."""
        ids = [*row_headers, *self.column_spanners.get(var, []), self.columns.get(var)]
        return " ".join(x for x in ids if x)


def _get_header_ids(data: GTData) -> _HeaderIds:
    """Make the ids of the stubhead, column label, spanner, title and subtitle cells."""

    registry = _IdRegistry(data._options.table_id.value)

    has_summary_rows = bool(data._summary_rows or data._summary_rows_grand)
    stub_layout = data._stub._get_stub_layout(
        has_summary_rows=has_summary_rows, options=data._options, boxhead=data._boxhead
    )

    # Without column labels there are no header cells for the columns to refer to
    if data._options.column_labels_hidden.value:
        header_ids = _HeaderIds(registry, stubhead=[], columns={}, spanners={}, column_spanners={})
        return _add_heading_ids(header_ids, data)

    stubhead: list[str] = []
    if stub_layout and data._stubhead:
        stub_label = _resolve_stubhead_label(data._stubhead, stub_layout=stub_layout)
        labels = stub_label if isinstance(stub_label, list) else [stub_label]
        stubhead = [registry.make(label, fallback="stubhead") for label in labels]

    columns = {
        info.var: registry.make(info.var, fallback="column")
        for info in data._boxhead._get_default_columns()
    }

    spanners: dict[str, str] = {}
    column_spanners: dict[str, list[str]] = {var: [] for var in columns}

    if _get_spanners_matrix_height(data=data, omit_columns_row=True) > 0:
        spanner_labels, _ = spanners_print_matrix(
            spanners=data._spanners, boxhead=data._boxhead, include_hidden=False, ids=False
        )
        spanner_id_matrix, _ = spanners_print_matrix(
            spanners=data._spanners, boxhead=data._boxhead, include_hidden=False, ids=True
        )

        # Rows are ordered from the top spanner level down, with the column labels last
        for label_row, id_row in zip(spanner_labels[:-1], spanner_id_matrix[:-1]):
            for var, spanner_id in id_row.items():
                if not spanner_id or not label_row.get(var):
                    continue
                if spanner_id not in spanners:
                    spanners[spanner_id] = registry.make(label_row[var], fallback="spanner")
                column_spanners.setdefault(var, []).append(spanners[spanner_id])

    header_ids = _HeaderIds(registry, stubhead, columns, spanners, column_spanners)
    return _add_heading_ids(header_ids, data)


def _add_heading_ids(header_ids: _HeaderIds, data: GTData) -> _HeaderIds:
    """Make the ids of the title and subtitle cells (after the column ids, which they can't change)."""

    if heading_has_title(data._heading.title):
        header_ids.title = header_ids.registry.make("title", fallback="title")
        if heading_has_subtitle(data._heading.subtitle):
            header_ids.subtitle = header_ids.registry.make("subtitle", fallback="subtitle")

    return header_ids


def _get_table_aria_attrs(data: GTData) -> str:
    """Get the `aria-*` attributes of `<table>` that name it after its title (and subtitle)."""

    header_ids = _get_header_ids(data)

    attrs = ""
    if header_ids.title:
        attrs += f' aria-labelledby="{html_lib.escape(header_ids.title)}"'
    if header_ids.subtitle:
        attrs += f' aria-describedby="{html_lib.escape(header_ids.subtitle)}"'

    return attrs


def create_heading_component_h(data: GTData) -> str:
    title = data._heading.title
    subtitle = data._heading.subtitle

    has_title = heading_has_title(title)
    has_subtitle = heading_has_subtitle(subtitle)

    # If there is no title or heading component, then return an empty string
    if not has_title and not has_subtitle:
        return ""

    # Raise an error if there is a subtitle but no title
    if not has_title and has_subtitle:
        raise ValueError("A subtitle was provided without a title.")

    title = _process_text(title)
    subtitle = _process_text(subtitle)

    # Filter footnotes for title and subtitle - similar to styles filtering
    footnotes_title = [x for x in data._footnotes if isinstance(x.locname, loc.LocTitle)]
    footnotes_subtitle = [x for x in data._footnotes if isinstance(x.locname, loc.LocSubTitle)]

    # Add footnote marks to title and subtitle if applicable
    if has_title:
        title = _apply_footnotes_to_text(footnotes_title, data, title)
    if has_subtitle:
        subtitle = _apply_footnotes_to_text(footnotes_subtitle, data, subtitle)

    # Filter list of StyleInfo for the various header components
    styles_header = [x for x in data._styles if _is_loc(x.locname, loc.LocHeader)]
    styles_title = [x for x in data._styles if _is_loc(x.locname, loc.LocTitle)]
    styles_subtitle = [x for x in data._styles if _is_loc(x.locname, loc.LocSubTitle)]
    title_style = _flatten_styles(styles_header + styles_title, wrap=True)
    subtitle_style = _flatten_styles(styles_header + styles_subtitle, wrap=True)

    has_summary_rows = bool(data._summary_rows or data._summary_rows_grand)

    # Get the effective number of columns, which is number of columns
    # that will finally be rendered accounting for the stub layout
    n_cols_total = data._boxhead._get_effective_number_of_columns(
        stub=data._stub,
        has_summary_rows=has_summary_rows,
        options=data._options,
    )

    # The title (and subtitle) cells have ids so that `<table>` can refer to them as its name (and
    # description)
    header_ids = _get_header_ids(data)
    title_id = f' id="{html_lib.escape(header_ids.title)}"' if header_ids.title else ""
    subtitle_id = f' id="{html_lib.escape(header_ids.subtitle)}"' if header_ids.subtitle else ""

    if has_subtitle:
        heading = f"""
  <tr class="gt_heading">
    <td colspan="{n_cols_total}" class="gt_heading gt_title gt_font_normal"{title_id}{title_style}>{title}</td>
  </tr>
  <tr class="gt_heading">
    <td colspan="{n_cols_total}" class="gt_heading gt_subtitle gt_font_normal gt_bottom_border"{subtitle_id}{subtitle_style}>{subtitle}</td>
  </tr>"""
    else:
        heading = f"""
  <tr class="gt_heading">
    <td colspan="{n_cols_total}" class="gt_heading gt_title gt_font_normal"{title_id}{title_style}>{title}</td>
  </tr>"""

    return heading


def _resolve_stubhead_label(
    stubhead: str | BaseText | list[str | BaseText], stub_layout: list[str]
) -> str | BaseText | list[str | BaseText]:
    """Return the stubhead label, or a list with one label per stub column.

    A list with a single label is treated as a label that spans the whole stub. Otherwise a list
    must have one label for each stub column (not counting a row group column).
    """

    if not isinstance(stubhead, list):
        return stubhead

    if len(stubhead) == 1:
        return stubhead[0]

    n_stub_cols = stub_layout.count("rowname")

    if len(stubhead) != n_stub_cols:
        raise ValueError(
            f"`tab_stubhead()` was given {len(stubhead)} labels but the stub has {n_stub_cols} "
            "column(s). Provide one label per stub column, or a single label for the whole stub."
        )

    return stubhead


def _create_stubhead_cells(
    stub_label: str | BaseText | list[str | BaseText],
    stub_layout: list[str],
    rowspan: int,
    stubhead_ids: list[str],
    footnotes_stubhead: list[FootnoteInfo],
    styles_stubhead: list[StyleInfo],
    data: GTData,
) -> list[Tag]:
    """Create the `<th>` cell(s) of the stubhead.

    A single label spans all of the stub columns. A list of labels gives one cell per stub column
    (with an empty cell above any row group column), and any stubhead footnote mark is placed on
    the first label only.
    """

    class_ = "gt_col_heading gt_columns_bottom_border gt_left"
    style = _flatten_styles(styles_stubhead)

    if not isinstance(stub_label, list):
        return [
            Tag(
                "th",
                HTML(_apply_footnotes_to_text(footnotes_stubhead, data, _process_text(stub_label))),
                class_=class_,
                rowspan=rowspan,
                colspan=len(stub_layout),
                style=style,
                scope="colgroup" if len(stub_layout) > 1 else "col",
                id=stubhead_ids[0] if stubhead_ids else None,
            )
        ]

    cells = []

    if "group_label" in stub_layout:
        cells.append(Tag("th", class_=class_, rowspan=rowspan, colspan=1, style=style, scope="col"))

    for k, label in enumerate(stub_label):
        label_text = _process_text(label)
        if k == 0:
            label_text = _apply_footnotes_to_text(footnotes_stubhead, data, label_text)

        element_id = stubhead_ids[k] if k < len(stubhead_ids) else None

        cells.append(
            Tag(
                "th",
                HTML(label_text),
                class_=class_,
                rowspan=rowspan,
                colspan=1,
                style=style,
                scope="col",
                id=element_id,
            )
        )

    return cells


def create_columns_component_h(data: GTData) -> str:
    """
    Returns the HTML text fragment for the column/spanner labels.
    """

    # Should the column labels be hidden?
    column_labels_hidden: bool = data._options.column_labels_hidden.value

    if column_labels_hidden:
        return ""

    # Get necessary data objects for composing the column labels and spanners
    stubh = data._stubhead
    boxhead = data._boxhead

    # TODO: The body component of the table is only needed for determining RTL alignment
    # is needed in the corresponding column labels
    # body = data._body

    # Get vector representation of stub layout
    has_summary_rows = bool(data._summary_rows or data._summary_rows_grand)
    stub_layout = data._stub._get_stub_layout(
        has_summary_rows=has_summary_rows, options=data._options, boxhead=data._boxhead
    )

    # Determine the finalized number of spanner rows
    spanner_row_count = _get_spanners_matrix_height(data=data, omit_columns_row=True)

    # TODO: Modify alignments for RTL support, skip this for now
    # Detect any RTL script characters within the visible columns;
    # this creates a vector the same length as `col_alignment`
    # rtl_detect = [
    #     any(char in rtl_modern_unicode_charset() for char in str(body[x])) for x in range(len(body))
    # ]
    #
    # For any columns containing characters from RTL scripts; we
    # will transform a 'left' alignment to a 'right' alignment
    # for i in range(len(rtl_detect)):
    #     if rtl_detect[i] and col_alignment[i] != "center":
    #         col_alignment[i] = "right"

    # Get the column headings
    headings_info = boxhead._get_default_columns()

    # Filter list of StyleInfo for the various stubhead and column labels components
    styles_stubhead = [x for x in data._styles if _is_loc(x.locname, loc.LocStubhead)]
    styles_column_labels = [x for x in data._styles if _is_loc(x.locname, loc.LocColumnHeader)]
    styles_spanner_label = [x for x in data._styles if _is_loc(x.locname, loc.LocSpannerLabels)]
    styles_column_label = [x for x in data._styles if _is_loc(x.locname, loc.LocColumnLabels)]

    # If columns are present in the stub, then replace with a set stubhead label or nothing
    if stub_layout and stubh is not None:
        stub_label = _resolve_stubhead_label(stubh, stub_layout=stub_layout)
        stub_var = "::stub"
    else:
        stub_label = ""
        stub_var = None

    # Set a default alignment for the stubhead label
    stubhead_label_alignment = "left"

    # Initialize the column headings list
    table_col_headings = []

    # Get the (unique) ids of the header cells, which the body cells refer to in `headers`
    header_ids = _get_header_ids(data)

    # Filter footnotes for stubhead - similar to styles filtering
    footnotes_stubhead = [x for x in data._footnotes if isinstance(x.locname, loc.LocStubhead)]

    # If there are no spanners, then we have to create the cells for the stubhead label
    # (if present) and for the column headings
    if spanner_row_count == 0:
        # Create the cell(s) for the stubhead label
        if stub_layout:
            table_col_headings.extend(
                _create_stubhead_cells(
                    stub_label=stub_label,
                    stub_layout=stub_layout,
                    rowspan=1,
                    stubhead_ids=header_ids.stubhead,
                    footnotes_stubhead=footnotes_stubhead,
                    styles_stubhead=styles_stubhead,
                    data=data,
                )
            )

        # Create the headings in the case where there are no spanners at all -------------------------
        for info in headings_info:
            # Filter by column label / id, join with overall column labels style
            styles_i = [x for x in styles_column_label if x.colname == info.var]

            # Filter footnotes for column label footnotes
            footnotes_i = [
                x
                for x in data._footnotes
                if isinstance(x.locname, loc.LocColumnLabels) and x.colname == info.var
            ]

            # Add footnote marks to column label if any
            column_label_with_footnotes = _apply_footnotes_to_text(
                footnotes=footnotes_i, data=data, text=_process_text(info.column_label)
            )

            table_col_headings.append(
                Tag(
                    "th",
                    _wrap_rotated_column_label(column_label_with_footnotes, info),
                    class_=f"gt_col_heading gt_columns_bottom_border gt_{info.defaulted_align}",
                    rowspan=1,
                    colspan=1,
                    style=_flatten_styles(styles_column_labels + styles_i),
                    scope="col",
                    id=header_ids.columns.get(info.var),
                )
            )

        # Join the <th> cells into a string and begin each with a newline
        # th_cells = "\n" + "\n".join(["  " + str(tag) for tag in table_col_headings]) + "\n"

        table_col_headings = Tag("tr", *table_col_headings, class_="gt_col_headings")

    #
    # Create the spanners and column labels in the case where there *are* spanners -------------
    #

    if spanner_row_count >= 1:
        spanner_ids, spanner_col_names = spanners_print_matrix(
            spanners=data._spanners, boxhead=boxhead, include_hidden=False, ids=False
        )

        # Build a parallel matrix of spanner IDs (same shape/ordering as the label
        # matrix above). Styles and footnotes targeting spanners are stored by ID,
        # which can differ from the displayed label, so filtering must compare IDs.
        spanner_id_matrix, _ = spanners_print_matrix(
            spanners=data._spanners, boxhead=boxhead, include_hidden=False, ids=True
        )

        # Last is column labels
        # So take second to last
        level_1_index = -2

        # A list of <th> elements that will go in the first level; this
        # includes spanner labels and column labels for solo columns (don't
        # have spanner labels above them)
        level_1_spanners = []

        # A list of <th> elements that will go in the second row. This is
        # all column labels that DO have spanners above them.
        spanned_column_labels = []

        # Create the cell(s) for the stubhead label
        if stub_layout:
            level_1_spanners.extend(
                _create_stubhead_cells(
                    stub_label=stub_label,
                    stub_layout=stub_layout,
                    rowspan=2,
                    stubhead_ids=header_ids.stubhead,
                    footnotes_stubhead=footnotes_stubhead,
                    styles_stubhead=styles_stubhead,
                    data=data,
                )
            )

        # NOTE: Run-length encoding treats missing values as distinct from each other; in other
        # words, each missing value starts a new run of length 1

        spanner_ids_level_1 = spanner_ids[level_1_index]
        spanner_ids_level_1_index = list(spanner_ids_level_1.values())
        # Group adjacent columns by spanner ID since display labels can repeat.
        spanner_id_level_1_index = list(spanner_id_matrix[level_1_index].values())
        spanners_rle = seq_groups(seq=spanner_id_level_1_index)

        # `colspans` matches `spanners` in length; each element is the number of columns that the
        # <th> at that position should span; if 0, then skip the <th> at that position
        group_spans = ([x[1]] + [0] * (x[1] - 1) for x in spanners_rle)

        colspans = list(chain.from_iterable(group_spans))

        for ii, (span_key, h_info) in enumerate(zip(spanner_col_names, headings_info)):
            if spanner_ids_level_1[span_key] is None:
                # Filter by column label / id, join with overall column labels style
                styles_i = [x for x in styles_column_label if x.colname == h_info.var]

                # Filter footnotes for this column label - similar to styles filtering
                footnotes_i = [
                    x
                    for x in data._footnotes
                    if isinstance(x.locname, loc.LocColumnLabels) and x.colname == h_info.var
                ]

                # Get the alignment values for the first set of column labels
                first_set_alignment = h_info.defaulted_align

                # Add footnote marks to column label if any
                column_label_with_footnotes = _apply_footnotes_to_text(
                    footnotes_i, data, _process_text(h_info.column_label)
                )

                # Creation of <th> tags for column labels with no spanners above them
                level_1_spanners.append(
                    Tag(
                        "th",
                        _wrap_rotated_column_label(column_label_with_footnotes, h_info),
                        class_=f"gt_col_heading gt_columns_bottom_border gt_{first_set_alignment}",
                        rowspan=2,
                        colspan=1,
                        style=_flatten_styles(styles_column_labels + styles_i),
                        scope="col",
                        id=header_ids.columns.get(h_info.var),
                    )
                )
            # If colspans[i] == 0, it means that a previous cell's
            # `colspan` will cover us
            elif (spanner_ids_level_1[span_key] is not None) and (colspans[ii] > 0):
                # Filter by spanner label / id, join with overall column labels style
                styles_i = [
                    x
                    for x in styles_spanner_label
                    if spanner_id_level_1_index[ii] and spanner_id_level_1_index[ii] in x.grpname
                ]

                # Filter footnotes for this spanner label - similar to styles filtering
                footnotes_i = [
                    x
                    for x in data._footnotes
                    if isinstance(x.locname, loc.LocSpannerLabels)
                    and spanner_id_level_1_index[ii]
                    and x.grpname == spanner_id_level_1_index[ii]
                ]

                level_1_spanners.append(
                    Tag(
                        "th",
                        Tag(
                            "span",
                            HTML(
                                _apply_footnotes_to_text(
                                    footnotes_i,
                                    data,
                                    _process_text(spanner_ids_level_1_index[ii]),
                                )
                            ),
                            class_="gt_column_spanner",
                        ),
                        class_="gt_center gt_columns_top_border gt_column_spanner_outer",
                        rowspan=1,
                        colspan=colspans[ii],
                        style=_flatten_styles(styles_column_labels + styles_i),
                        scope="colgroup" if colspans[ii] > 1 else "col",
                        id=header_ids.spanners.get(spanner_id_level_1_index[ii]),
                    )
                )

        remaining_headings = [k for k, v in spanner_ids[level_1_index].items() if v is not None]
        remaining_headings_labels = (
            entry.column_label for entry in boxhead if entry.var in remaining_headings
        )
        # col_alignment = [
        #     entry.defaulted_align for entry in boxhead if entry.var in remaining_headings
        # ]

        if remaining_headings:
            spanned_column_labels = []

            for remaining_heading, remaining_headings_label in zip(
                remaining_headings, remaining_headings_labels
            ):
                # Filter by column label / id, join with overall column labels style
                # TODO check this filter logic
                styles_i = [x for x in styles_column_label if x.colname == remaining_heading]

                # Filter footnotes for this column label - similar to styles filtering
                footnotes_i = [
                    x
                    for x in data._footnotes
                    if isinstance(x.locname, loc.LocColumnLabels) and x.colname == remaining_heading
                ]

                remaining_alignment = boxhead._get_boxhead_get_alignment_by_var(
                    var=remaining_heading
                )

                # Add footnote marks to column label if any
                remaining_headings_label_with_footnotes = _apply_footnotes_to_text(
                    footnotes_i,
                    data,
                    _process_text(remaining_headings_label),
                )

                spanned_column_labels.append(
                    Tag(
                        "th",
                        _wrap_rotated_column_label(
                            remaining_headings_label_with_footnotes,
                            next(info for info in boxhead if info.var == remaining_heading),
                        ),
                        class_=f"gt_col_heading gt_columns_bottom_border gt_{remaining_alignment}",
                        rowspan=1,
                        colspan=1,
                        style=_flatten_styles(styles_column_labels + styles_i),
                        scope="col",
                        id=header_ids.columns.get(remaining_heading),
                    )
                )

            table_col_headings = TagList(
                Tag("tr", level_1_spanners, class_="gt_col_headings gt_spanner_row"),
                Tag("tr", spanned_column_labels, class_="gt_col_headings"),
            )

        else:
            # Create the `table_col_headings` HTML component
            table_col_headings = Tag(
                "tr", level_1_spanners, class_="gt_col_headings gt_spanner_row"
            )

    if _get_spanners_matrix_height(data=data) > 2:
        # Spanners are listed top to bottom, so we need to work bottom to top
        # We can skip the last (column labels) and second to last (first spanner)
        higher_spanner_rows = TagList()

        for spanners_row, spanner_id_row in zip(spanner_ids[:-2], spanner_id_matrix[:-2]):
            spanners_row = {k: "" if v is None else v for k, v in spanners_row.items()}
            # Group adjacent columns by spanner ID; the IDs are wrapped in tuples because
            # `seq_groups()` never joins `None` values, and adjacent columns without a spanner
            # here share one blank cell
            spanners_rle = seq_groups((span_id,) for span_id in spanner_id_row.values())
            group_spans = ([x[1]] + [0] * (x[1] - 1) for x in spanners_rle)
            colspans = list(chain.from_iterable(group_spans))
            level_i_spanners = []

            for colspan, span_label, span_id in zip(
                colspans, spanners_row.values(), spanner_id_row.values()
            ):
                if colspan > 0:
                    # Filter by spanner id (styles/footnotes are stored by ID, which
                    # may differ from the displayed label)
                    styles_i = [x for x in styles_spanner_label if span_id and span_id in x.grpname]

                    # Filter footnotes for this spanner label - similar to styles filtering
                    footnotes_i = [
                        x
                        for x in data._footnotes
                        if isinstance(x.locname, loc.LocSpannerLabels)
                        and span_id
                        and x.grpname == span_id
                    ]

                    if span_label:
                        span = Tag(
                            "span",
                            HTML(
                                _apply_footnotes_to_text(
                                    footnotes_i,
                                    data,
                                    _process_text(span_label),
                                )
                            ),
                            class_="gt_column_spanner",
                        )
                    else:
                        span = Tag("span", HTML("&nbsp;"))

                    level_i_spanners.append(
                        Tag(
                            "th",
                            span,
                            class_="gt_center gt_columns_bottom_border gt_columns_top_border gt_column_spanner_outer",
                            rowspan=1,
                            colspan=colspan,
                            style=_flatten_styles(styles_column_labels + styles_i),
                            scope="colgroup" if colspan > 1 else "col",
                            id=header_ids.spanners.get(span_id) if span_label else None,
                        )
                    )

            if stub_layout:
                level_i_spanners.insert(
                    0,
                    Tag(
                        "th",
                        Tag("span", HTML("&nbsp")),
                        class_=f"gt_col_heading gt_columns_bottom_border gt_{stubhead_label_alignment}",
                        rowspan=1,
                        colspan=len(stub_layout),
                        scope="colgroup" if len(stub_layout) > 1 else "col",
                        # TODO check if ok to just use base styling?
                        style=_flatten_styles(styles_column_labels),
                    ),
                )

            higher_spanner_rows = TagList(
                higher_spanner_rows,
                TagList(
                    Tag(
                        "tr",
                        level_i_spanners,
                        class_="gt_col_headings gt_spanner_row",
                        # TODO check if ok to just use base styling?
                        style=_flatten_styles(styles_column_labels),
                    )
                ),
            )

        table_col_headings = TagList(
            higher_spanner_rows,
            table_col_headings,
        )
    return table_col_headings


def _calculate_hierarchical_stub_rowspans(
    stub_col_names: list[str],
    ordered_index: list[tuple[int, Any]],
    tbl_data: TblData,
) -> list[list[int]]:
    """Compute the rowspan of each cell in a hierarchical (multi-column) stub.

    Cells of an outer stub column are merged across adjacent rows (in display order) when the rows
    are in the same group and have the same values in that column and every column to its left.
    The values compared are the formatted ones shown in the table. The last (primary) column is
    never merged, since each row keeps its own label.

    Returns one list per stub column, holding one value per row in `ordered_index`: the rowspan
    for a cell that starts a run (`1` for an unmerged cell), or `0` for a cell covered by a
    rowspan above it (and so not rendered).
    """

    n_rows = len(ordered_index)

    # Each row's key for each level: the values of that column and all columns to its left
    row_values = [
        [str(_get_cell(tbl_data, row_index, col)) for col in stub_col_names]
        for row_index, _ in ordered_index
    ]

    all_rowspans: list[list[int]] = []

    for k in range(len(stub_col_names)):
        spans = [1] * n_rows

        if k < len(stub_col_names) - 1:
            run_start = 0
            for j in range(1, n_rows + 1):
                continues_run = (
                    j < n_rows
                    and ordered_index[j][1] is ordered_index[run_start][1]
                    and row_values[j][: k + 1] == row_values[run_start][: k + 1]
                )
                if not continues_run:
                    spans[run_start] = j - run_start
                    for covered in range(run_start + 1, j):
                        spans[covered] = 0
                    run_start = j

        all_rowspans.append(spans)

    return all_rowspans


def create_body_component_h(data: GTData) -> str:
    all_body_rows = "\n".join(create_body_rows_h(data))

    return f"""<tbody class="gt_table_body">
{all_body_rows}
</tbody>"""


def create_body_rows_h(
    data: GTData, cell_classes: dict[int, dict[str, str]] | None = None
) -> list[str]:
    # The body's `<tr>`s. (`cell_classes` gives classes to add to the data rows' cells: by each
    # row's place among the data rows shown, from 0, then by column, as a GTI table's kernel mode
    # tints missing values)

    # for now, just coerce everything in the original data to a string
    # so we can fill in the body data with it
    _str_orig_data = cast_frame_to_string(data._tbl_data)
    tbl_data = replace_null_frame(data._body.body, _str_orig_data)

    # Filter list of StyleInfo to only those that apply to the stub
    styles_row_group_label = [x for x in data._styles if _is_loc(x.locname, loc.LocRowGroups)]
    styles_row_label = [x for x in data._styles if _is_loc(x.locname, loc.LocStub)]
    styles_summary_label = [x for x in data._styles if _is_loc(x.locname, loc.LocSummaryStub)]
    styles_grand_summary_label = [
        x for x in data._styles if _is_loc(x.locname, loc.LocGrandSummaryStub)
    ]

    # Filter list of StyleInfo to only those that apply to the body
    styles_cells = [x for x in data._styles if _is_loc(x.locname, loc.LocBody)]
    # styles_body = [x for x in data._styles if _is_loc(x.locname, loc.LocBody2)]
    styles_summary = [x for x in data._styles if _is_loc(x.locname, loc.LocSummary)]
    styles_grand_summary = [x for x in data._styles if _is_loc(x.locname, loc.LocGrandSummary)]

    # Get the default column vars
    column_vars = data._boxhead._get_default_columns()

    row_stub_var = data._boxhead._get_stub_column()

    has_summary_rows = bool(data._summary_rows or data._summary_rows_grand)
    stub_layout = data._stub._get_stub_layout(
        has_summary_rows=has_summary_rows, options=data._options, boxhead=data._boxhead
    )

    has_row_stub_column = "rowname" in stub_layout
    has_group_stub_column = "group_label" in stub_layout
    has_groups = data._stub.group_ids is not None and len(data._stub.group_ids) > 0

    # All stub columns in hierarchy order (outer → primary); may be >1 for multi-col stubs
    stub_col_vars = data._boxhead._get_stub_columns()

    # If there is a stub, then prepend that to the `column_vars` list
    if has_row_stub_column:
        # There are one or more stub columns assigned to rownames
        if stub_col_vars:
            column_vars = stub_col_vars + column_vars
        # Else we have summary rows but no stub yet
        else:
            # TODO: this naming is not ideal
            summary_row_stub_var = ColInfo(
                "__do_not_use__", ColInfoTypeEnum.summary_placeholder, column_align="left"
            )
            column_vars = [summary_row_stub_var, *column_vars]

    # The ids of the header cells, which each body cell lists in its `headers` attribute
    header_ids = _get_header_ids(data)

    # Is the stub to be striped?
    table_stub_striped = data._options.row_striping_include_stub.value

    # Are the rows in the table body to be striped?
    table_body_striped = data._options.row_striping_include_table_body.value

    body_rows: list[str] = []

    # Add grand summary rows at top
    top_g_summary_rows = data._summary_rows_grand.get_summary_rows(side="top")
    for i, summary_row in enumerate(top_g_summary_rows):
        row_html = _create_row_component_h(
            header_ids=header_ids,
            column_vars=column_vars,
            row_stub_var=row_stub_var,  # Should probably include group stub?
            has_row_stub_column=has_row_stub_column,  # Should probably include group stub?
            has_group_stub_column=has_group_stub_column,  # Add this parameter
            apply_stub_striping=False,  # No striping for summary rows
            apply_body_striping=False,  # No striping for summary rows
            styles_cells=styles_grand_summary,
            styles_labels=styles_grand_summary_label,
            row_index=i,
            summary_row=summary_row,
            css_class="gt_last_grand_summary_row_top" if i == len(top_g_summary_rows) - 1 else None,
            data=data,
        )
        body_rows.append(row_html)

    # iterate over rows (ordered by groupings)
    prev_group_info = None

    ordered_index: list[tuple[int, GroupRowInfo]] = data._stub.group_indices_map()

    # Pre-compute the rowspans of a hierarchical stub (columns ordered outermost to primary)
    stub_col_names = [c.var for c in stub_col_vars]
    if len(stub_col_names) > 1:
        stub_rowspans_by_col = _calculate_hierarchical_stub_rowspans(
            stub_col_names, ordered_index, tbl_data
        )
    else:
        stub_rowspans_by_col = []

    # The data rows covered by each stub cell (several, for a cell merged across rows), so that a
    # style or footnote targeting any of those rows in that stub column is applied to the cell
    stub_rows_by_col = [
        [[ordered_index[j + t][0] for t in range(span)] for j, span in enumerate(spans)]
        for spans in stub_rowspans_by_col
    ]

    for j, (i, group_info) in enumerate(ordered_index):
        # For table striping we want to add a striping CSS class to the even-numbered
        # rows in the rendered table; to target these rows, determine if `i` in the current
        # row render is an odd number

        odd_j_row = j % 2 == 1

        leading_cell = None

        # Create table row or label in the stub specifically for group (if applicable)
        # Only create if this is the first row of data within the group
        if has_groups and (group_info is not prev_group_info):
            # The group's label cell heads all of its rows
            header_ids.group = header_ids.registry.make(group_info.group_id, fallback="group")
            group_id_attr = f' id="{html_lib.escape(header_ids.group)}"'

            # When a groupname_col formatter ran, group_label is already
            # safe HTML; when it's the raw group_id, escape it.
            if group_info.group_label is not None:
                group_label = group_info.group_label
            else:
                group_label = _process_text(group_info.group_id)

            _styles = [
                style for style in styles_row_group_label if group_info.group_id in style.grpname
            ]
            group_styles = _flatten_styles(_styles, wrap=True)

            # Apply footnote marks to group label
            footnotes_group = [
                x
                for x in data._footnotes
                if isinstance(x.locname, loc.LocRowGroups) and x.grpname == group_info.group_id
            ]
            group_label = _apply_footnotes_to_text(footnotes_group, data, group_label)

            # Get top summary rows for this group (needed for rowspan calculation)
            top_summary_rows_for_group = (
                data._summary_rows.get_summary_rows(group_id=group_info.group_id, side="top")
                if data._summary_rows
                else []
            )
            bottom_summary_rows_for_group = (
                data._summary_rows.get_summary_rows(group_id=group_info.group_id, side="bottom")
                if data._summary_rows
                else []
            )

            # Add group label that spans multiple columns when row_group_as_column is true
            if has_group_stub_column:
                rowspan_value = (
                    len(group_info.indices)
                    + len(top_summary_rows_for_group)
                    + len(bottom_summary_rows_for_group)
                )

                leading_cell = f"""  <th{group_styles} class="gt_row gt_left gt_stub_row_group"
    rowspan="{rowspan_value}" scope="rowgroup"{group_id_attr}>{group_label}</th>"""

            # Append a table row for the group heading
            else:
                colspan_value = data._boxhead._get_effective_number_of_columns(
                    stub=data._stub, has_summary_rows=has_summary_rows, options=data._options
                )

                group_class = (
                    "gt_empty_group_heading" if group_label == "" else "gt_group_heading_row"
                )
                group_scope = "colgroup" if colspan_value > 1 else "col"

                group_row = f"""  <tr class="{group_class}">
    <th class="gt_group_heading" colspan="{colspan_value}" scope="{group_scope}"{group_id_attr}{group_styles}>{group_label}</th>
  </tr>"""

                body_rows.append(group_row)

            # Render top summary rows immediately after the group heading
            if data._summary_rows and top_summary_rows_for_group:
                for si, summary_row in enumerate(top_summary_rows_for_group):
                    # Attach leading_cell (group label) to first top summary row
                    # when row_group_as_column is true
                    summary_leading = leading_cell if si == 0 else None
                    row_html = _create_row_component_h(
                        header_ids=header_ids,
                        column_vars=column_vars,
                        row_stub_var=row_stub_var,
                        has_row_stub_column=has_row_stub_column,
                        has_group_stub_column=has_group_stub_column,
                        leading_cell=summary_leading,
                        apply_stub_striping=False,
                        apply_body_striping=False,
                        styles_cells=styles_summary,
                        styles_labels=styles_summary_label,
                        row_index=si,
                        summary_row=summary_row,
                        css_class="gt_last_summary_row_top"
                        if si == len(top_summary_rows_for_group) - 1
                        else None,
                        data=data,
                        summary_group_id=group_info.group_id,
                        row_class="gt_row_group_first" if si == 0 and leading_cell else None,
                    )
                    body_rows.append(row_html)

                # Clear leading_cell so data row doesn't also get it
                if leading_cell:
                    leading_cell = None

        # For multi-column stubs, extract the pre-computed rowspans (and covered rows) for row j
        row_stub_rowspans = (
            [stub_rowspans_by_col[k][j] for k in range(len(stub_col_names))]
            if stub_rowspans_by_col
            else None
        )
        row_stub_rows = (
            [stub_rows_by_col[k][j] for k in range(len(stub_col_names))]
            if stub_rows_by_col
            else None
        )

        # Create data row
        row_html = _create_row_component_h(
            header_ids=header_ids,
            column_vars=column_vars,
            row_stub_var=row_stub_var,
            has_row_stub_column=has_row_stub_column,
            has_group_stub_column=has_group_stub_column,
            leading_cell=leading_cell,
            apply_stub_striping=table_stub_striped and odd_j_row,
            apply_body_striping=table_body_striped and odd_j_row,
            styles_cells=styles_cells,
            styles_labels=styles_row_label,
            row_index=i,
            tbl_data=tbl_data,
            data=data,
            row_class="gt_row_group_first" if leading_cell else None,
            stub_col_rowspans=row_stub_rowspans,
            stub_col_rows=row_stub_rows,
            cell_classes=cell_classes.get(j) if cell_classes else None,
        )
        body_rows.append(row_html)

        prev_group_info = group_info

        # After the last row in the group, append the bottom summary rows
        if has_groups and group_info is not None and data._summary_rows:
            # Determine if this is the last row of the current group
            is_last_in_group = (
                j == len(ordered_index) - 1 or ordered_index[j + 1][1] is not group_info
            )

            if is_last_in_group:
                group_id = group_info.group_id

                # Add bottom summary rows for this group
                bottom_summary_rows = data._summary_rows.get_summary_rows(
                    group_id=group_id, side="bottom"
                )
                for si, summary_row in enumerate(bottom_summary_rows):
                    row_html = _create_row_component_h(
                        header_ids=header_ids,
                        column_vars=column_vars,
                        row_stub_var=row_stub_var,
                        has_row_stub_column=has_row_stub_column,
                        has_group_stub_column=has_group_stub_column,
                        apply_stub_striping=False,
                        apply_body_striping=False,
                        styles_cells=styles_summary,
                        styles_labels=styles_summary_label,
                        row_index=si,
                        summary_row=summary_row,
                        css_class="gt_first_summary_row" if si == 0 else None,
                        data=data,
                        summary_group_id=group_id,
                    )
                    body_rows.append(row_html)

    # Add grand summary rows at bottom
    bottom_g_summary_rows = data._summary_rows_grand.get_summary_rows(side="bottom")
    for i, summary_row in enumerate(bottom_g_summary_rows):
        row_html = _create_row_component_h(
            header_ids=header_ids,
            column_vars=column_vars,
            row_stub_var=row_stub_var,
            has_row_stub_column=has_row_stub_column,
            has_group_stub_column=has_group_stub_column,  # Add this parameter
            apply_stub_striping=False,
            apply_body_striping=False,
            styles_cells=styles_grand_summary,
            styles_labels=styles_grand_summary_label,
            row_index=i + len(top_g_summary_rows),
            summary_row=summary_row,
            css_class="gt_first_grand_summary_row_bottom" if i == 0 else None,
            data=data,
        )
        body_rows.append(row_html)

    return body_rows


def _create_row_component_h(
    column_vars: list[ColInfo],
    row_stub_var: ColInfo | None,
    has_row_stub_column: bool,
    has_group_stub_column: bool,
    apply_stub_striping: bool,
    apply_body_striping: bool,
    styles_cells: list[StyleInfo],  # Either styles_cells OR styles_grand_summary
    styles_labels: list[StyleInfo],  # Either styles_row_label OR styles_grand_summary_label
    leading_cell: str | None = None,  # For group label when row_group_as_column = True
    row_index: int | None = None,
    summary_row: SummaryRowInfo | None = None,  # For summary rows
    tbl_data: TblData | None = None,
    css_class: str | None = None,
    data: GTData | None = None,  # For footnote handling
    summary_group_id: Any = _NO_GROUP,  # For group summary rows; any key, None included
    row_class: str | None = None,  # CSS class for the <tr> element
    stub_col_rowspans: list[int] | None = None,  # Rowspan values for stub cols (multi-col stub)
    stub_col_rows: list[list[int]] | None = None,  # Data rows covered by each stub cell
    header_ids: _HeaderIds | None = None,  # Ids of the header cells, for `headers` attributes
    cell_classes: dict[str, str] | None = None,  # Classes to add to cells, by column
) -> str:
    """Create a single table row (either data row or summary row)"""

    is_summary_row = summary_row is not None
    is_group_summary = summary_group_id is not _NO_GROUP
    summary_css_class = "gt_summary_row" if is_group_summary else "gt_grand_summary_row"
    body_cells: list[str] = []

    if leading_cell:
        body_cells.append(leading_cell)

    # A summary row's label cell heads the row; a data row is headed by its stub cells (made below,
    # as they're rendered) and, in either case, by its row group's label cell
    summary_label_id = None
    if header_ids is not None and is_summary_row:
        summary_base = f"summary-{summary_group_id}" if is_group_summary else "grand-summary"
        summary_label_id = header_ids.registry.make(
            f"{summary_base}-{summary_row.id}", fallback="summary"
        )
    summary_id_attr = f' id="{html_lib.escape(summary_label_id)}"' if summary_label_id else ""

    # Handle special cases for summary rows with group stub columns
    if is_summary_row and has_group_stub_column:
        cell_styles = _flatten_styles(
            [x for x in styles_labels if x.rownum == row_index], wrap=True
        )

        classes = ["gt_row", "gt_left", "gt_stub", summary_css_class]
        if css_class:
            classes.append(css_class)
        classes_str = " ".join(classes)

        # Apply footnotes to the summary stub label
        stub_label = _process_text(summary_row.id)
        if data is not None:
            if is_group_summary:
                footnotes_i = [
                    x
                    for x in data._footnotes
                    if isinstance(x.locname, loc.LocSummaryStub)
                    and x.rownum == row_index
                    and x.grpname == summary_group_id
                ]
            else:
                footnotes_i = [
                    x
                    for x in data._footnotes
                    if isinstance(x.locname, loc.LocGrandSummaryStub) and x.rownum == row_index
                ]
            stub_label = _apply_footnotes_to_text(footnotes_i, data, stub_label)

        # Count row stub columns (may be >1 for multi-col stubs)
        n_row_stub_cols = sum(1 for c in column_vars if c.is_stub)

        if is_group_summary:
            # Group summary rows are covered by the group label cell's rowspan.
            # Span across all row stub columns with a single label cell.
            colspan_attr = f' colspan="{n_row_stub_cols}"' if n_row_stub_cols > 1 else ""
            body_cells.append(
                f"""    <th{cell_styles}{colspan_attr} scope="row"{summary_id_attr} class="{classes_str}">{stub_label}</th>"""
            )
        elif has_row_stub_column:
            # Grand summary rows must span the group stub column AND all row stub columns.
            grand_colspan = 1 + n_row_stub_cols
            body_cells.append(
                f"""    <th{cell_styles} class="{classes_str}" colspan="{grand_colspan}" scope="row"{summary_id_attr}>{stub_label}</th>"""
            )
        else:
            # Grand summary rows with only group stub column (no row stub)
            body_cells.append(
                f"""    <th{cell_styles} scope="row"{summary_id_attr} class="{classes_str}">{stub_label}</th>"""
            )

        # Skip stub columns in column_vars since we've already handled the stub
        column_vars_to_process = [column for column in column_vars if not column.is_stub]

    else:
        # Normal case: process all column_vars
        column_vars_to_process = column_vars

    stub_cell_idx = 0  # tracks which stub column we're on (for rowspan lookup)

    # A summary row has a single label cell spanning all of the stub columns
    n_stub_cells = sum(1 for c in column_vars_to_process if c.is_stub)
    summary_label_colspan = (
        f' colspan="{n_stub_cells}"' if is_summary_row and n_stub_cells > 1 else ""
    )

    for colinfo in column_vars_to_process:
        if is_summary_row and colinfo.is_stub and stub_cell_idx > 0:
            # The summary label cell already spans this stub column
            continue

        # The data rows covered by a stub cell; styles and footnotes that target this stub column
        # (via `loc.stub(columns=)`) in any of these rows are applied to the cell
        covered_rows = (
            stub_col_rows[stub_cell_idx]
            if colinfo.is_stub and stub_col_rows is not None and not is_summary_row
            else [row_index]
        )

        # Get cell content
        if is_summary_row:
            if colinfo == row_stub_var or colinfo.is_stub:
                cell_content = _process_text(summary_row.id)
            else:
                cell_content = summary_row.values.get(colinfo.var)
        elif colinfo.type == ColInfoTypeEnum.summary_placeholder:
            # TODO: this row is technically a summary row, but is_summary_row is False here
            cell_content = "&nbsp;"
        else:
            cell_content = _get_cell(tbl_data, row_index, colinfo.var)

        classes = [css_class] if css_class else []
        if cell_classes and colinfo.var in cell_classes:
            classes.append(cell_classes[colinfo.var])

        cell_str = str(cell_content)
        cell_alignment = colinfo.defaulted_align

        # Apply footnotes to cell content if data is provided
        if data is not None and not is_summary_row:
            if colinfo.is_stub:
                # Stub footnotes without a column (colname=None) are marked on the primary stub
                # column; those from `loc.stub(columns=)` are marked on the targeted column
                is_primary = row_stub_var is None or colinfo == row_stub_var
                footnotes_i = [
                    x
                    for x in data._footnotes
                    if isinstance(x.locname, loc.LocStub)
                    and (
                        (x.colname is None and is_primary and x.rownum == row_index)
                        or (x.colname == colinfo.var and x.rownum in covered_rows)
                    )
                ]
                cell_str = _apply_footnotes_to_text(footnotes_i, data, cell_str)
            else:
                footnotes_i = [
                    x
                    for x in data._footnotes
                    if isinstance(x.locname, loc.LocBody)
                    and x.colname == colinfo.var
                    and x.rownum == row_index
                ]
                cell_str = _apply_footnotes_to_text(footnotes_i, data, cell_str)
        elif data is not None and is_summary_row:
            if is_group_summary:
                if colinfo.is_stub:
                    footnotes_i = [
                        x
                        for x in data._footnotes
                        if isinstance(x.locname, loc.LocSummaryStub)
                        and x.rownum == row_index
                        and x.grpname == summary_group_id
                    ]
                    cell_str = _apply_footnotes_to_text(footnotes_i, data, cell_str)
                else:
                    footnotes_i = [
                        x
                        for x in data._footnotes
                        if isinstance(x.locname, loc.LocSummary)
                        and x.colname == colinfo.var
                        and x.rownum == row_index
                        and x.grpname == summary_group_id
                    ]
                    cell_str = _apply_footnotes_to_text(footnotes_i, data, cell_str)
            else:
                if colinfo.is_stub:
                    footnotes_i = [
                        x
                        for x in data._footnotes
                        if isinstance(x.locname, loc.LocGrandSummaryStub) and x.rownum == row_index
                    ]
                    cell_str = _apply_footnotes_to_text(footnotes_i, data, cell_str)
                else:
                    footnotes_i = [
                        x
                        for x in data._footnotes
                        if isinstance(x.locname, loc.LocGrandSummary)
                        and x.colname == colinfo.var
                        and x.rownum == row_index
                    ]
                    cell_str = _apply_footnotes_to_text(footnotes_i, data, cell_str)

        # Get styles
        _body_styles = [
            x for x in styles_cells if x.rownum == row_index and x.colname == colinfo.var
        ]
        _rowname_styles = (
            [
                x
                for x in styles_labels
                if (x.colname is None and x.rownum == row_index)
                or (x.colname == colinfo.var and x.rownum in covered_rows)
            ]
            if colinfo.is_stub
            else []
        )
        if len(covered_rows) > 1:
            # A merged cell is covered by several rows that one `tab_style()` call may all target;
            # its style is applied once
            _rowname_styles = list({id(x.styles): x for x in _rowname_styles}.values())

        # Build classes and element
        if colinfo.is_stub:
            el_name = "th"
            classes += ["gt_row", "gt_left", "gt_stub"]
            if is_summary_row:
                classes.append(summary_css_class)
            if apply_stub_striping:
                classes.append("gt_striped")
        else:
            el_name = "td"
            classes += ["gt_row", f"gt_{cell_alignment}"]
            if is_summary_row:
                classes.append(summary_css_class)
            if apply_body_striping:
                classes.append("gt_striped")

        # Apply stub indent CSS class for regular (non-summary) data rows; in a hierarchical stub
        # only the primary column is indented
        if (
            colinfo.is_stub
            and (row_stub_var is None or colinfo == row_stub_var)
            and not is_summary_row
            and data is not None
            and row_index is not None
        ):
            indent_level = data._stub.rows[row_index].indent
            if 1 <= indent_level <= 5:
                classes.append(f"gt_indent_{indent_level}")

        classes_str = " ".join(classes)
        cell_styles = _flatten_styles(_body_styles + _rowname_styles, wrap=True)

        # Ids inside an SVG in the cell (e.g., a flag's clip path or a nanoplot's fill pattern) are
        # made unique to the cell, so that cells with the same SVG don't repeat an id and a
        # reference can't resolve to another cell's definition
        if "<svg" in cell_str and " id=" in cell_str:
            prefix = header_ids.registry.prefix if header_ids is not None else ""
            cell_str = _make_svg_ids_unique(cell_str, prefix=f"{prefix}{colinfo.var}-{row_index}")

        # Cells of a hierarchical stub may span rows (or be covered by a span from above)
        span_attr = ""
        scope_attr = ""
        if colinfo.is_stub:
            if is_summary_row:
                span_attr = summary_label_colspan
            elif stub_col_rowspans is not None:
                rowspan_val = stub_col_rowspans[stub_cell_idx]
                if rowspan_val == 0:
                    stub_cell_idx += 1
                    continue
                if rowspan_val > 1:
                    span_attr = f' rowspan="{rowspan_val}"'
            stub_cell_idx += 1

            # A stub cell is the header of its row, or of the group of rows it spans (as in R gt)
            scope_attr = ' scope="rowgroup"' if span_attr.startswith(" rowspan") else ' scope="row"'

        # Header cells get an id, and body cells list the ids of their headers
        id_attr = ""
        if header_ids is not None:
            if is_summary_row and colinfo.is_stub:
                cell_id = summary_label_id
            elif colinfo.is_stub and colinfo.type != ColInfoTypeEnum.summary_placeholder:
                level = stub_cell_idx - 1
                multi = stub_col_rowspans is not None
                cell_id = header_ids.registry.make(
                    f"stub-{data._stub.row_number(row_index)}" + (f"-{level + 1}" if multi else ""),
                    fallback="stub",
                )
                header_ids.stub[level] = cell_id
            else:
                cell_id = None

            if cell_id:
                id_attr = f' id="{html_lib.escape(cell_id)}"'
            elif not colinfo.is_stub:
                if is_summary_row:
                    row_headers = [header_ids.group if is_group_summary else None, summary_label_id]
                else:
                    row_headers = [header_ids.group, *header_ids.stub.values()]
                cell_headers = header_ids.cell_headers(colinfo.var, row_headers)
                if cell_headers:
                    id_attr = f' headers="{html_lib.escape(cell_headers)}"'

        body_cells.append(
            f"""    <{el_name}{cell_styles}{span_attr}{scope_attr}{id_attr} class="{classes_str}">{cell_str}</{el_name}>"""
        )

    tr_open = f'  <tr class="{row_class}">' if row_class else "  <tr>"
    return tr_open + "\n" + "\n".join(body_cells) + "\n  </tr>"


def create_source_notes_component_h(data: GTData) -> str:
    source_notes = data._source_notes

    # Filter list of StyleInfo to only those that apply to the source notes
    styles_footer = [x for x in data._styles if _is_loc(x.locname, loc.LocFooter)]
    styles_source_notes = [x for x in data._styles if _is_loc(x.locname, loc.LocSourceNotes)]

    # If there are no source notes, then return an empty string
    if not source_notes:
        return ""

    # Obtain the `multiline` and `separator` options from `_options`
    multiline = data._options.source_notes_multiline.value
    separator = cast("str", data._options.source_notes_sep.value)

    # Get the effective number of columns, which is number of columns
    # that will finally be rendered accounting for the stub layout
    has_summary_rows = bool(data._summary_rows or data._summary_rows_grand)
    n_cols_total = data._boxhead._get_effective_number_of_columns(
        stub=data._stub, has_summary_rows=has_summary_rows, options=data._options
    )

    # Handle the multiline source notes case (each note takes up one line)
    if multiline:
        # Create the source notes component as a series of `<tr><td>` (one per
        # source note) inside of a `<tfoot>`

        source_notes_tr: list[str] = []

        _styles = _flatten_styles(styles_footer + styles_source_notes, wrap=True)
        for note in source_notes:
            note_str = _process_text(note)

            source_notes_tr.append(
                f"""
  <tr>
    <td class="gt_sourcenote" colspan="{n_cols_total}"{_styles}>{note_str}</td>
  </tr>
"""
            )

        source_notes_joined = "\n".join(source_notes_tr)

        source_notes_component = f"""  <tfoot class="gt_sourcenotes">
  {source_notes_joined}
</tfoot>"""

        return source_notes_component

    # TODO: Perform HTML escaping on the separator text and
    # transform space characters to non-breaking spaces

    # Create the source notes component as a single `<tr><td>` inside
    # of a `<tfoot>`

    source_note_list: list[str] = []
    for note in source_notes:
        note_str = _process_text(note)
        source_note_list.append(note_str)

    source_notes_str_joined = separator.join(source_note_list)

    source_notes_component = f"""<tfoot>
  <tr class="gt_sourcenotes">
    <td class="gt_sourcenote" colspan="{n_cols_total}">
      <div style="padding-bottom:2px;">{source_notes_str_joined}</div>
    </td>
  </tr>
</tfoot>
    """

    return source_notes_component


def create_footer_component_h(data: GTData) -> str:
    source_notes = data._source_notes
    footnotes = data._footnotes

    # Get the effective number of columns for colspan
    has_summary_rows = bool(data._summary_rows or data._summary_rows_grand)
    n_cols_total = data._boxhead._get_effective_number_of_columns(
        stub=data._stub, has_summary_rows=has_summary_rows, options=data._options
    )

    footer_rows = []

    # Add footnotes if they exist (above the source notes, as in gt)
    if footnotes:
        # Process footnotes and assign marks
        footnotes_with_marks = _process_footnotes_for_display(data, footnotes)

        if footnotes_with_marks:
            styles_footer = [x for x in data._styles if _is_loc(x.locname, loc.LocFooter)]
            styles_footnotes = [x for x in data._styles if _is_loc(x.locname, loc.LocFootnotes)]
            _fn_styles = _flatten_styles(styles_footer + styles_footnotes, wrap=True)

            # Each footnote gets its own row
            for footnote_data in footnotes_with_marks:
                mark = footnote_data.get("mark", "")
                text = footnote_data.get("text", "")

                ftr_spec = _parse_footnote_spec(cast("str", data._options.footnotes_spec_ftr.value))
                footnote_mark_html = _create_footnote_mark_html(mark=mark, spec=ftr_spec)

                # Wrap footnote text in `gt_from_md` span if it contains HTML markup
                if "<" in text and ">" in text:
                    footnote_text = f'<span class="gt_from_md">{text}</span>'
                else:
                    footnote_text = text

                footnote_html = f"{footnote_mark_html} {footnote_text}"
                footer_rows.append(
                    f'<tr class="gt_footnotes"><td class="gt_footnote" colspan="{n_cols_total}"{_fn_styles}>{footnote_html}</td></tr>'
                )

    # Add source notes if they exist
    if source_notes:
        # Filter list of StyleInfo to only those that apply to the source notes
        styles_footer = [x for x in data._styles if _is_loc(x.locname, loc.LocFooter)]
        styles_source_notes = [x for x in data._styles if _is_loc(x.locname, loc.LocSourceNotes)]

        # Obtain the `multiline` and `separator` options from `_options`
        multiline = data._options.source_notes_multiline.value
        separator = cast("str", data._options.source_notes_sep.value)

        _styles = _flatten_styles(styles_footer + styles_source_notes, wrap=True)

        if multiline:
            # Each source note gets its own row with gt_sourcenotes class on the tr
            for note in source_notes:
                note_str = _process_text(note)
                footer_rows.append(
                    f'<tr class="gt_sourcenotes"><td class="gt_sourcenote" colspan="{n_cols_total}"{_styles}><span class="gt_from_md">{note_str}</span></td></tr>'
                )
        else:
            # All source notes in a single row with gt_sourcenotes class on the tr
            source_note_list = []
            for note in source_notes:
                note_str = _process_text(note)
                source_note_list.append(note_str)

            source_notes_str_joined = separator.join(source_note_list)
            footer_rows.append(
                f'<tr class="gt_sourcenotes"><td class="gt_sourcenote" colspan="{n_cols_total}"{_styles}><span class="gt_from_md">{source_notes_str_joined}</span></td></tr>'
            )

    # If no footer content, return empty string
    if not footer_rows:
        return ""

    return f"<tfoot>{''.join(footer_rows)}</tfoot>"


def _get_stub_footnote_colnum(data: GTData, footnote: FootnoteInfo) -> float:
    """Column order of a stub footnote: between the row group column (-2) and the data columns.

    A footnote on an outer level of a hierarchical stub sorts before one on the primary column.
    """

    stub_columns = [col.var for col in data._boxhead._get_stub_columns()]
    if footnote.colname not in stub_columns:
        return -1

    n_levels_right = len(stub_columns) - 1 - stub_columns.index(footnote.colname)
    return -1 - n_levels_right / len(stub_columns)


def _should_display_footnote(data: GTData, footnote: FootnoteInfo) -> bool:
    # A title or subtitle note is shown only when that part of the heading exists.
    # `rm_header()` clears both; a header can also have a title and no subtitle.
    if isinstance(footnote.locname, loc.LocTitle):
        return heading_has_title(data._heading.title)
    if isinstance(footnote.locname, loc.LocSubTitle):
        return heading_has_subtitle(data._heading.subtitle)

    # A spanner note is shown only when that spanner is still in the table and at
    # least one of its columns is visible. `rm_spanners()` drops the spanner, and
    # `cols_hide()` can hide every column it covers; either way the label is gone.
    if isinstance(footnote.locname, loc.LocSpannerLabels):
        return _footnote_spanner_is_shown(data, footnote.grpname)

    # If footnote targets a specific column, check if it's hidden
    if footnote.colname is not None:
        # Get column info from boxhead to check if it's hidden
        for col_info in data._boxhead._d:
            if col_info.var == footnote.colname:
                return col_info.visible
        # If column not found in boxhead, assume it should be displayed
        return True

    # Footnotes with no column (for example a markless note) are displayed
    return True


def _footnote_spanner_is_shown(data: GTData, spanner_id: str | None) -> bool:
    spanner = next((span for span in data._spanners if span.spanner_id == spanner_id), None)
    if spanner is None:
        return False

    visible_vars = {col.var for col in data._boxhead._d if col.visible}
    return any(var in visible_vars for var in spanner.vars)


def _process_footnotes_for_display(
    data: GTData, footnotes: list[FootnoteInfo]
) -> list[dict[str, str]]:
    if not footnotes:
        return []

    # Drop footnotes whose target is not shown (a hidden column, or a missing
    # title, subtitle, or spanner) so they neither appear in the footer nor take a mark
    visible_footnotes = [f for f in footnotes if _should_display_footnote(data, f)]

    # Sort footnotes by visual order (same logic as in _get_footnote_mark_string);
    # this ensures footnotes appear in the footnotes section in the same order as their
    # marks in the table
    footnote_positions: list[tuple[tuple[int | float, int, int], FootnoteInfo]] = []

    for fn_info in visible_footnotes:
        if fn_info.locname is None:
            continue

        # Assign locnum based on visual hierarchy (summary side-aware)
        locnum = _get_summary_locnum(data, fn_info)

        # Assign column number, with row groups and stub getting lower values than data columns
        if isinstance(fn_info.locname, loc.LocRowGroups):
            colnum = -2  # Row group column is leftmost
        elif isinstance(
            fn_info.locname, (loc.LocStub, loc.LocSummaryStub, loc.LocGrandSummaryStub)
        ):
            # Stub appears before data columns but after row group column
            colnum = _get_stub_footnote_colnum(data, fn_info)
        elif isinstance(fn_info.locname, loc.LocSpannerLabels):
            colnum = _get_spanner_leftmost_column_index(data, fn_info.grpname)
        else:
            colnum = _get_column_index(data, fn_info.colname) if fn_info.colname else 0
        rownum = (
            0
            if isinstance(fn_info.locname, loc.LocColumnLabels)
            else (fn_info.rownum if fn_info.rownum is not None else 0)
        )

        sort_key = (locnum, rownum, colnum)
        footnote_positions.append((sort_key, fn_info))

    # Sort by visual order
    footnote_positions.sort(key=lambda x: x[0])
    sorted_footnotes = [fn_info for _, fn_info in footnote_positions]

    # Group footnotes by their text to avoid duplicates and get their marks
    footnote_data: dict[str, str] = {}  # text -> mark_string
    footnote_order: list[str] = []

    for footnote in sorted_footnotes:
        if footnote.footnotes:
            footnote_text = footnote.footnotes[0] if footnote.footnotes else ""
            if footnote_text not in footnote_data:
                mark_string = _get_footnote_mark_string(data, footnote)
                footnote_data[footnote_text] = mark_string
                footnote_order.append(footnote_text)

    # Build the marked footnotes list (sorted by visual order)
    mark_type = _get_footnote_marks_option(data)
    if isinstance(mark_type, str) and mark_type == "numbers":
        sorted_texts = sorted(
            footnote_order,
            key=lambda text: (
                int(footnote_data[text]) if footnote_data[text].isdigit() else float("inf")
            ),
        )
    else:
        sorted_texts = footnote_order

    marked_items: list[dict[str, str]] = [
        {"mark": footnote_data[text], "text": text} for text in sorted_texts
    ]

    # Build the markless footnotes list (also filter for visibility)
    markless_footnotes = [f for f in visible_footnotes if f.locname is None]  # type: ignore
    markless_items: list[dict[str, str]] = []
    for footnote in markless_footnotes:
        if footnote.footnotes:
            markless_items.append({"mark": "", "text": footnote.footnotes[0]})

    # Arrange marked vs markless based on the footnotes_order option
    order_option = cast("str", data._options.footnotes_order.value)

    if order_option == "marks_first":
        return marked_items + markless_items
    elif order_option == "preserve_order":
        # Maintain insertion order from data._footnotes
        seen_texts: set[str] = set()
        result: list[dict[str, str]] = []
        for fn_info in data._footnotes:
            if not fn_info.footnotes:
                continue
            if not _should_display_footnote(data, fn_info):
                continue
            footnote_text = fn_info.footnotes[0]
            if footnote_text in seen_texts:
                continue
            seen_texts.add(footnote_text)
            if fn_info.locname is None:
                result.append({"mark": "", "text": footnote_text})
            elif footnote_text in footnote_data:
                result.append({"mark": footnote_data[footnote_text], "text": footnote_text})
        return result
    else:
        # "marks_last" (default): markless first, then marked
        return markless_items + marked_items


def _get_footnote_mark_symbols() -> dict[str, list[str]]:
    from ._helpers import LETTERS, letters

    return {
        "numbers": [],
        "letters": letters(),
        "LETTERS": LETTERS(),
        "standard": ["*", "†", "‡", "§"],
        "extended": ["*", "†", "‡", "§", "‖", "¶"],
    }


def _generate_footnote_mark(mark_index: int, mark_type: str | list[str] = "numbers") -> str:
    if isinstance(mark_type, str):
        if mark_type == "numbers":
            return str(mark_index)

        symbol_sets = _get_footnote_mark_symbols()
        if mark_type in symbol_sets:
            symbols = symbol_sets[mark_type]
        else:
            # Default to numbers if unknown type
            return str(mark_index)
    else:
        symbols = mark_type

    if not symbols:
        return str(mark_index)

    # Calculate symbol and repetition for cycling behavior;
    # e.g., for 4 symbols: index 1-4 -> symbol once, 5-8 -> symbol twice, etc.
    symbol_index = (mark_index - 1) % len(symbols)
    repetitions = (mark_index - 1) // len(symbols) + 1

    return symbols[symbol_index] * repetitions


def _get_footnote_marks_option(data: GTData) -> str | list[str]:
    # Read from the options system
    if hasattr(data, "_options") and hasattr(data._options, "footnotes_marks"):
        marks_value = data._options.footnotes_marks.value
        if marks_value is not None:
            return marks_value

    # Default to numbers
    return "numbers"


@dataclass(frozen=True)
class FootnoteMarkSpec:
    superscript: bool = False
    bold: bool = False
    italic: bool = False
    enclosure: str | None = None  # "()", "[]", or None
    period: bool = False


def _parse_footnote_spec(spec: str) -> FootnoteMarkSpec:
    superscript = "^" in spec
    bold = "b" in spec
    italic = "i" in spec
    period = "." in spec

    enclosure: str | None = None
    if "(" in spec or ")" in spec:
        enclosure = "()"
    elif "[" in spec or "]" in spec:
        enclosure = "[]"

    return FootnoteMarkSpec(
        superscript=superscript,
        bold=bold,
        italic=italic,
        enclosure=enclosure,
        period=period,
    )


def _apply_footnote_spec_to_mark(mark: str, spec: FootnoteMarkSpec) -> str:
    if spec.enclosure == "()":
        mark = f"({mark})"
    elif spec.enclosure == "[]":
        mark = f"[{mark}]"

    if spec.period:
        mark = f"{mark}."

    return mark


def _build_footnote_mark_style(spec: FootnoteMarkSpec) -> str:
    parts = ["white-space:nowrap"]
    parts.append(f"font-style:{'italic' if spec.italic else 'normal'}")
    parts.append(f"font-weight:{'bold' if spec.bold else 'normal'}")
    if spec.superscript:
        parts.append("line-height:0")
    else:
        # Override the .gt_footnote_marks class defaults (vertical-align:0.4em; font-size:75%)
        parts.append("vertical-align:baseline")
        parts.append("font-size:100%")
    return ";".join(parts) + ";"


def _create_footnote_mark_html(mark: str, spec: FootnoteMarkSpec | None = None) -> str:
    if not mark:
        return ""

    if spec is None:
        spec = FootnoteMarkSpec(superscript=True, italic=True)

    mark = _apply_footnote_spec_to_mark(mark, spec)
    style = _build_footnote_mark_style(spec)

    return f'<span class="gt_footnote_marks" style="{style}">{mark}</span>'


def _get_footnote_mark_string(data: GTData, footnote_info: FootnoteInfo) -> str:
    if not data._footnotes or not footnote_info.footnotes:
        mark_type = _get_footnote_marks_option(data)
        return _generate_footnote_mark(1, mark_type)

    order_option = cast("str", data._options.footnotes_order.value)

    # Build unique footnote texts in the appropriate order
    if order_option == "preserve_order":
        # Insertion order: walk data._footnotes as-is
        unique_footnotes: list[str] = []
        for fn_info in data._footnotes:
            if not fn_info.footnotes or fn_info.locname is None:
                continue
            if not _should_display_footnote(data, fn_info):
                continue
            footnote_text = _process_text(fn_info.footnotes[0])
            if footnote_text not in unique_footnotes:
                unique_footnotes.append(footnote_text)
    else:
        # Visual reading order (default): sort by (locnum, rownum, colnum)
        footnote_positions: list[tuple[tuple[int | float, int, int], str]] = []

        for fn_info in data._footnotes:
            if not fn_info.footnotes or fn_info.locname is None:
                continue

            if not _should_display_footnote(data, fn_info):
                continue

            footnote_text = _process_text(fn_info.footnotes[0])

            locnum = _get_summary_locnum(data, fn_info)

            if isinstance(fn_info.locname, loc.LocRowGroups):
                colnum = -2
            elif isinstance(
                fn_info.locname, (loc.LocStub, loc.LocSummaryStub, loc.LocGrandSummaryStub)
            ):
                colnum = _get_stub_footnote_colnum(data, fn_info)
            elif isinstance(fn_info.locname, loc.LocSpannerLabels):
                colnum = _get_spanner_leftmost_column_index(data, fn_info.grpname)
            else:
                colnum = _get_column_index(data, fn_info.colname) if fn_info.colname else 0

            if isinstance(fn_info.locname, loc.LocColumnLabels):
                rownum = 0
            else:
                rownum = fn_info.rownum if fn_info.rownum is not None else 0

            sort_key = (locnum, rownum, colnum)
            footnote_positions.append((sort_key, footnote_text))

        footnote_positions.sort(key=lambda x: x[0])

        unique_footnotes = []
        for _, text in footnote_positions:
            if text not in unique_footnotes:
                unique_footnotes.append(text)

    # Find the mark index for this footnote's text
    if footnote_info.footnotes:
        footnote_text = _process_text(footnote_info.footnotes[0])
        try:
            mark_index = unique_footnotes.index(footnote_text) + 1  # Use 1-based indexing
            mark_type = _get_footnote_marks_option(data)
            return _generate_footnote_mark(mark_index, mark_type)
        except ValueError:  # pragma: no cover
            mark_type = _get_footnote_marks_option(data)
            return _generate_footnote_mark(1, mark_type)

    mark_type = _get_footnote_marks_option(data)  # pragma: no cover
    return _generate_footnote_mark(1, mark_type)  # pragma: no cover


def _get_column_index(data: GTData, colname: str | None) -> int:
    if not colname:
        return 0

    # Get the column order from boxhead
    columns = data._boxhead._get_default_columns()
    for i, col_info in enumerate(columns):
        if col_info.var == colname:
            return i

    return 0


def _get_spanner_leftmost_column_index(data: GTData, spanner_grpname: str | None) -> int:
    if not spanner_grpname:
        return 0

    # Find the spanner with this group name (spanner footnotes store the spanner ID, not its label)
    for spanner in data._spanners:
        if spanner.spanner_id == spanner_grpname:
            # Get the column indices for all columns in this spanner
            column_indices = []
            for col_var in spanner.vars:
                col_index = _get_column_index(data, col_var)
                column_indices.append(col_index)

            # Return the minimum (leftmost) column index
            return min(column_indices) if column_indices else 0

    return 0


def _apply_footnotes_to_text(footnotes: list[FootnoteInfo], data: GTData, text: str) -> str:
    if not footnotes:
        return text

    # Get mark strings for each footnote
    mark_strings: list[str] = []
    footnote_placements: list[FootnoteInfo] = []
    for footnote in footnotes:
        mark_string = _get_footnote_mark_string(data, footnote)
        if mark_string not in mark_strings:
            mark_strings.append(mark_string)
            footnote_placements.append(footnote)

    # Sort marks: for numbers, sort numerically; for symbols, sort by their order in symbol set
    mark_type = _get_footnote_marks_option(data)
    if isinstance(mark_type, str) and mark_type == "numbers":
        # Sort numerically for numbers
        mark_strings.sort(key=lambda x: int(x) if x.isdigit() else float("inf"))
    else:
        # For symbols, maintain the order they appear (which should already be correct)
        # since `_get_footnote_mark_string()` returns them in visual order
        pass

    # Create a single footnote mark span with comma-separated marks
    if mark_strings:
        ref_spec = _parse_footnote_spec(cast("str", data._options.footnotes_spec_ref.value))

        # Apply enclosure and period to each individual mark, then join
        decorated_marks = [_apply_footnote_spec_to_mark(m, ref_spec) for m in mark_strings]
        marks_text = ",".join(decorated_marks)
        style = _build_footnote_mark_style(ref_spec)
        marks_html = f'<span class="gt_footnote_marks" style="{style}">{marks_text}</span>'

        # Determine placement based on the first footnote's placement setting
        # (all footnotes for the same location should have the same placement)
        placement = footnote_placements[0].placement if footnote_placements else None

        # Apply placement logic
        return _apply_footnote_placement(text, marks_html, placement)

    return text  # pragma: no cover


def _apply_footnote_placement(
    text: str, marks_html: str, placement: FootnotePlacement | None
) -> str:
    # Default to auto if no placement specified
    placement_setting = FootnotePlacement.auto if placement is None else placement

    if placement_setting == FootnotePlacement.left:
        # Left placement: footnote marks + space + text
        return f"{marks_html} {text}"
    elif placement_setting == FootnotePlacement.right:
        # Right placement: text + footnote marks
        return f"{text}{marks_html}"
    else:
        # Auto placement: left for numbers, right for everything else
        if _is_numeric_content(text):
            # For numbers, place marks on the left so alignment is preserved
            return f"{marks_html} {text}"
        else:
            # For text, place marks on the right
            return f"{text}{marks_html}"


def _is_numeric_content(text: str) -> bool:
    import re

    # Strip HTML tags for analysis
    clean_text = re.sub(r"<[^>]+>", "", text).strip()

    if not clean_text:
        return False

    # Remove common formatting characters to get to the core content
    # This handles formatted numbers with commas, currency symbols, percent signs, etc.
    # Include a wide range of currency symbols and formatting characters
    formatting_chars = r"[,\s$%€£¥₹₽₩₪₱₡₴₦₨₵₸₲₩\(\)−\-+]"
    number_core = re.sub(formatting_chars, "", clean_text)

    # Check if what remains is primarily numeric (including decimals)
    if not number_core:
        return False

    # Check if the core is a valid number: must have at least one digit,
    # and can have at most one decimal point
    numeric_pattern = r"^\d*\.?\d+$|^\d+\.?\d*$"
    return bool(re.match(numeric_pattern, number_core)) and number_core != "."


def rtl_modern_unicode_charset() -> str:  # pragma: no cover
    """
    Returns a string containing a regular expression that matches all characters
    from RTL scripts that are supported by modern web browsers.
    """
    # The Hebrew Unicode character set (112 code points)
    hebrew_unicode_charset = r"[\u0590-\u05FF]"

    # The Arabic Unicode character set (256 code points)
    arabic_unicode_charset = r"[\u0600-\u06FF]"

    # The Syriac Unicode character set (80 code points)
    syriac_unicode_charset = r"[\u0700-\u074F]"

    # The Thaana Unicode character set (64 code points)
    thaana_unicode_charset = r"[\u0780-\u07BF]"

    # The Samaritan Unicode character set (61 code points)
    samaritan_unicode_charset = r"[\u0800-\u083F]"

    # The Mandaic Unicode character set (32 code points)
    mandaic_unicode_charset = r"[\u0840-\u085F]"

    # The combination of these RTL character sets
    rtl_modern_unicode_charset = (
        hebrew_unicode_charset
        + "|"
        + arabic_unicode_charset
        + "|"
        + syriac_unicode_charset
        + "|"
        + thaana_unicode_charset
        + "|"
        + samaritan_unicode_charset
        + "|"
        + mandaic_unicode_charset
    )

    return rtl_modern_unicode_charset


def _get_spanners_matrix_height(
    data: GTData, include_hidden: bool = False, omit_columns_row: bool = False
) -> int:
    """
    Returns the height of the spanners matrix.

    Args:
        data (GTData): The data to be used for rendering the table.
        include_hidden (bool, optional): Whether to include hidden columns in the table. Defaults to False.
        omit_columns_row (bool, optional): Whether to omit the columns row in the table. Defaults to False.

    Returns:
        int: The height of the spanners matrix.
    """
    spanners_matrix, _ = spanners_print_matrix(
        spanners=data._spanners,
        boxhead=data._boxhead,
        include_hidden=include_hidden,
        omit_columns_row=omit_columns_row,
    )

    return len(spanners_matrix)


# Get the attributes needed for the <table> tag
def _get_table_defs(data: GTData) -> dict[str, Any]:
    # Get the `table-layout` value, which is set in `_options`
    table_layout = data._options.table_layout.value
    table_style = f"table-layout: {table_layout};"

    # Get the number of columns that have a width set
    column_widths = data._boxhead._get_column_widths()

    # If all values in the `column_widths` lists are None, then return a dictionary with
    # `table_style` and `table_colgroups` set to None; this is the case where column widths are
    # not set for any columns and, as a result, there should not be a `<colgroup>` tag requirement
    if all(width is None for width in column_widths):
        return {"table_style": None, "table_colgroups": None}

    # Get the table's width (which or may not have been set)
    table_width = data._options.table_width.value

    # Get finalized names of the columns (this includes the stub column)
    final_columns = data._boxhead.final_columns(options=data._options)

    # Get the widths of the columns
    widths = [col.column_width for col in final_columns]

    # If all of the widths are defined as px values for all columns, then ensure that the width
    # values are strictly respected as absolute width values (even if table width already set)
    if (
        all(isinstance(width, str) and width is not None and "px" in width for width in widths)
        and table_width == "auto"
    ):
        table_width = "0px"

    if (
        all(isinstance(width, str) and width is not None and "%" in width for width in widths)
        and table_width == "auto"
    ):
        table_width = "100%"

    if table_width != "auto":
        table_style = f"{table_style}; width: {table_width}"

    # Stop function if all length dimensions (where provided)
    # don't conform to accepted CSS length definitions
    # TODO: skipping this for now as the method/function doesn't exist
    # validate_css_lengths(widths)
    # Create the `<colgroup>` tag
    table_colgroups = Tag("colgroup", [Tag("col", style=css(width=width)) for width in widths])

    table_defs_dict = {"table_style": table_style, "table_colgroups": table_colgroups}

    return table_defs_dict
