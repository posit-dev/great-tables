from __future__ import annotations

import html
import math
import numbers
import re
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta
from decimal import ROUND_HALF_EVEN, Context, Decimal, localcontext
from functools import cache, partial
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Literal,
    TypeAlias,
    TypedDict,
    TypeVar,
    cast,
    overload,
)

import babel
from babel.core import get_global
from babel.dates import PATTERN_CHARS, format_date, format_datetime, format_time, parse_pattern

from ._fontawesome import fa_svg
from ._gt_data import FormatFn, FormatFns, FormatInfo, FormatterSkipElement, GTData, PFrameData
from ._helpers import px
from ._locale import (
    FlagsDataDict,
    _get_currencies_data,
    _get_default_locales_data,
    _get_flags_data,
    _get_locales_data,
)
from ._locations import RowSelectExpr, resolve_cols_c, resolve_rows_i
from ._styles import FromColumn
from ._tbl_data import (
    Agnostic,
    DataFrameLike,
    NpBool,
    PlExpr,
    SelectExpr,
    _get_column_dtype,
    is_na,
    is_series,
    to_list,
)
from ._text import _html_escape, _latex_escape, _md_html, _md_latex, escape_pattern_str_latex
from ._utils import _str_detect, _str_replace, is_valid_http_schema
from ._utils_nanoplots import _generate_nanoplot

if TYPE_CHECKING:
    from ._types import GTSelf

T = TypeVar("T")
DateStyle: TypeAlias = Literal[
    "iso",
    "wday_month_day_year",
    "wd_m_day_year",
    "wday_day_month_year",
    "month_day_year",
    "m_day_year",
    "day_m_year",
    "day_month_year",
    "day_month",
    "day_m",
    "year",
    "month",
    "day",
    "year.mn.day",
    "y.mn.day",
    "year_week",
    "year_quarter",
    "yMd",
    "yMEd",
    "yMMM",
    "yMMMM",
    "yMMMd",
    "yMMMEd",
    "GyMd",
    "GyMMMd",
    "GyMMMEd",
    "yM",
    "Md",
    "MEd",
    "MMMd",
    "MMMEd",
    "MMMMd",
    "GyMMM",
    "yQQQ",
    "yQQQQ",
    "Gy",
    "y",
    "M",
    "MMM",
    "d",
    "Ed",
]
TimeStyle: TypeAlias = Literal[
    "iso",
    "iso-short",
    "h_m_s_p",
    "h_m_p",
    "h_p",
    "Hms",
    "Hm",
    "H",
    "EHm",
    "EHms",
    "Hmsv",
    "Hmv",
    "hms",
    "hm",
    "h",
    "Ehm",
    "Ehms",
    "EBhms",
    "Bhms",
    "EBhm",
    "Bhm",
    "Bh",
    "hmsv",
    "hmv",
    "ms",
]
PlotType: TypeAlias = Literal[
    "line",
    "bar",
    "boxplot",
]
NumberSystem: TypeAlias = Literal["intl", "ind"]
MissingVals: TypeAlias = Literal[
    "marker",
    "gap",
    "zero",
    "remove",
]


def fmt(
    self: GTSelf,
    fns: FormatFn,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    is_substitution: bool = False,
) -> GTSelf:
    """
    Set a column format with a formatter function.

    The `fmt()` method provides a way to execute custom formatting functionality with raw data
    values in a way that can consider all output contexts.

    Along with the `columns` and `rows` arguments that provide some precision in targeting data
    cells, the `fns` argument allows you to define a function for manipulating the raw data.

    Parameters
    ----------
    fns
        A formatting function to apply to the targeted cells.
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in `columns` being formatted.
        Alternatively, we can supply a row index, a list of row indices, or (for Polars DataFrames)
        a Polars expression such as `pl.col("x") > 0`.
    is_substitution
        Whether the formatter is a substitution. Substitutions are run last, after other formatters.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Let's use the `exibble` dataset to create a table. With the `fmt()` method, we'll add a prefix
    `^` and a suffix `$` to the `row` and `group` columns.

    ```{python}
    from great_tables import GT, exibble

    (
        GT(exibble)
        .fmt(lambda x: f"^{x}$", columns=["row", "group"])
    )
    ```
    """

    # If a single function is supplied to `fns` then
    # repackage that into a list as the `default` function
    if isinstance(fns, FormatFns):
        pass
    elif isinstance(fns, Callable):
        fns = FormatFns(default=fns)
    else:
        raise TypeError("Input to fns= should be a callable.")

    row_res = resolve_rows_i(self, rows)
    row_pos = [name_pos[1] for name_pos in row_res]

    # Formatters can target the stub and the row group column (which formats the group labels)
    col_res = resolve_cols_c(self, columns, excl_stub=False, excl_group=False)

    formatter = FormatInfo(fns, col_res, row_pos)

    if is_substitution:
        return self._replace(_substitutions=[*self._substitutions, formatter])

    return self._replace(_formats=[*self._formats, formatter])


def fmt_number(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    decimals: int = 2,
    n_sigfig: int | None = None,
    drop_trailing_zeros: bool = False,
    drop_trailing_dec_mark: bool = True,
    use_seps: bool = True,
    accounting: bool = False,
    scale_by: float = 1,
    compact: bool = False,
    pattern: str = "{x}",
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign: bool = False,
    min_sep_threshold: int = 1,
    locale: str | None = None,
    system: NumberSystem = "intl",
) -> GTSelf:
    """
    Format numeric values.

    With numeric values within a table's body cells, we can perform number-based formatting so that
    the targeted values are rendered with a higher consideration for tabular presentation.
    Furthermore, there is finer control over numeric formatting with the following options:

    - decimals: choice of the number of decimal places, option to drop trailing zeros, and a choice
    of the decimal symbol
    - digit grouping separators: options to enable/disable digit separators and provide a choice of
    separator symbol
    - scaling: we can choose to scale targeted values by a multiplier value
    - large-number suffixing: larger figures (thousands, millions, etc.) can be autoscaled and
    decorated with the appropriate suffixes
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: providing a locale ID will result in number formatting specific to
    the chosen locale

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    decimals
        The `decimals` values corresponds to the exact number of decimal places to use. A value such
        as `2.34` can, for example, be formatted with `0` decimal places and it would result in
        `"2"`. With `4` decimal places, the formatted value becomes `"2.3400"`. The trailing zeros
        can be removed with `drop_trailing_zeros=True`. If you always need `decimals = 0`, the
        [`fmt_integer()`](`great_tables.GT.fmt_integer`) method should be considered.
    n_sigfig
        A option to format numbers to *n* significant figures. By default, this is `None` and thus
        number values will be formatted according to the number of decimal places set via
        `decimals`. If opting to format according to the rules of significant figures, `n_sigfig`
        must be a number greater than or equal to `1`. Any values passed to the `decimals` and
        `drop_trailing_zeros` arguments will be ignored.
    drop_trailing_zeros
        A boolean value that allows for removal of trailing zeros (those redundant zeros after the
        decimal mark).
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    use_seps
        The `use_seps` option allows for the use of digit group separators. The type of digit group
        separator is set by `sep_mark` and overridden if a locale ID is provided to `locale`. This
        setting is `True` by default.
    accounting
        Whether to use accounting style, which wraps negative numbers in parentheses instead of
        using a minus sign.
    scale_by
        All numeric values will be multiplied by the `scale_by` value before undergoing formatting.
        Since the `default` value is `1`, no values will be changed unless a different multiplier
        value is supplied.
    compact
        A boolean value that allows for compact formatting of numeric values. Values will be scaled
        and decorated with the appropriate suffixes (e.g., `1230` becomes `1.23K`, and `1230000`
        becomes `1.23M`). The `compact` option is `False` by default. With `system="ind"`, values
        are expressed in lakhs and crores instead (e.g., `1234567` becomes `12.35 Lac`).
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    min_sep_threshold
        The minimum number of digits in the integer part of a number for digit grouping
        separators to be used. The default of `1` uses separators from 4-digit numbers onward
        (e.g., `1,000`), `2` starts at 5-digit numbers (`10,000`), and `3` starts at 6-digit
        numbers (`100,000`). When a locale is in effect (through `locale=` or a locale set in
        `GT()`), the locale's own minimum grouping digits value is used instead (it's `2` for
        locales like `"es"` and `"pl"`).
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).
    system
        The numbering system to use for digit grouping. The international numbering system
        (`"intl"`, the default) always separates groups of three digits (e.g., `"1,234,567"`). The
        Indian numbering system (`"ind"`) separates the last three digits and then groups of two,
        which correspond to thousands, lakhs, crores, and higher quantities (e.g., `"12,34,567"`).
        The separator itself is still set by `sep_mark=` (or the locale) and can be turned off with
        `use_seps=False`.


    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator and decimal marks will be correct for the given locale. Should
    any values be provided in `sep_mark` or `dec_mark`, they will be overridden by the locale's
    preferred values.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    Let's use the `exibble` dataset to create a table. With the
    [`fmt_number()`](`great_tables.GT.fmt_number`) method, we'll format the `num` column to have
    three decimal places (with `decimals=3`) and omit the use of digit separators (with
    `use_seps=False`).

    ```{python}
    from great_tables import GT, exibble

    (
        GT(exibble)
        .fmt_number(columns="num", decimals=3, use_seps=False)
    )
    ```

    Large values can be grouped according to the Indian numbering system with `system="ind"`, and
    with `compact=True` they're expressed in lakhs and crores.

    ```{python}
    import polars as pl

    values = [12345.0, 123456.0, 1234567.0, 123456789.0]
    df = pl.DataFrame({"value": values, "compact": values})

    (
        GT(df)
        .fmt_number(columns="value", system="ind")
        .fmt_number(columns="compact", system="ind", compact=True)
    )
    ```
    """
    _validate_number_system(system)

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=min_sep_threshold, locale=locale)
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)

    pf_format = partial(
        fmt_number_context,
        data=self,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        accounting=accounting,
        scale_by=scale_by,
        compact=compact,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
        pattern=pattern,
        system=system,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_number_context(
    x: float | None,
    data: GTData,
    decimals: int,
    n_sigfig: int | None,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    use_seps: bool,
    accounting: bool,
    scale_by: float,
    compact: bool,
    sep_mark: str,
    min_sep_threshold: int,
    dec_mark: str,
    force_sign: bool,
    pattern: str,
    context: str,
    system: NumberSystem = "intl",
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by a defined `scale_by` value
    x = _scale_value(x, scale_by=scale_by)

    # Determine whether the value is positive
    is_negative = _has_negative_value(value=x)

    if compact:
        x_formatted = _format_number_compactly(
            value=x,
            decimals=decimals,
            n_sigfig=n_sigfig,
            drop_trailing_zeros=drop_trailing_zeros,
            drop_trailing_dec_mark=drop_trailing_dec_mark,
            use_seps=use_seps,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
            dec_mark=dec_mark,
            force_sign=force_sign,
            system=system,
        )
    else:
        x_formatted = _value_to_decimal_notation(
            value=x,
            decimals=decimals,
            n_sigfig=n_sigfig,
            drop_trailing_zeros=drop_trailing_zeros,
            drop_trailing_dec_mark=drop_trailing_dec_mark,
            use_seps=use_seps,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
            dec_mark=dec_mark,
            force_sign=force_sign,
            system=system,
        )

    # A value that rounds to zero is shown as zero, so it gets no minus sign or accounting style
    if _rounds_to_zero(x_formatted):
        is_negative = False

    # Implement minus sign replacement for `x_formatted` or use accounting style
    if is_negative:
        if accounting:
            x_formatted = f"({_remove_minus(x_formatted)})"

        else:
            minus_mark = _context_minus_mark(context=context)
            x_formatted = _replace_minus(x_formatted, minus_mark=minus_mark)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_integer(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    use_seps: bool = True,
    scale_by: float = 1,
    accounting: bool = False,
    compact: bool = False,
    pattern: str = "{x}",
    sep_mark: str = ",",
    force_sign: bool = False,
    min_sep_threshold: int = 1,
    locale: str | None = None,
    system: NumberSystem = "intl",
) -> GTSelf:
    """
    Format values as integers.

    With numeric values in one or more table columns, we can perform number-based formatting so that
    the targeted values are always rendered as integer values.

    We can have fine control over integer formatting with the following options:

    - digit grouping separators: options to enable/disable digit separators and provide a choice of
    separator symbol
    - scaling: we can choose to scale targeted values by a multiplier value
    - large-number suffixing: larger figures (thousands, millions, etc.) can be autoscaled and
    decorated with the appropriate suffixes
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: providing a locale ID will result in number formatting specific to
    the chosen locale

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    use_seps
        The `use_seps` option allows for the use of digit group separators. The type of digit group
        separator is set by `sep_mark` and overridden if a locale ID is provided to `locale`. This
        setting is `True` by default.
    scale_by
        All numeric values will be multiplied by the `scale_by` value before undergoing formatting.
        Since the `default` value is `1`, no values will be changed unless a different multiplier
        value is supplied.
    accounting
        Whether to use accounting style, which wraps negative numbers in parentheses instead of
        using a minus sign.
    compact
        A boolean value that allows for compact formatting of numeric values. Values will be scaled
        and decorated with the appropriate suffixes (e.g., `1230` becomes `1K`, and `1230000`
        becomes `1M`). The `compact` option is `False` by default. With `system="ind"`, values are
        expressed in lakhs and crores instead (e.g., `1234567` becomes `12 Lac`).
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    min_sep_threshold
        The minimum number of digits in the integer part of a number for digit grouping
        separators to be used. The default of `1` uses separators from 4-digit numbers onward
        (e.g., `1,000`), `2` starts at 5-digit numbers (`10,000`), and `3` starts at 6-digit
        numbers (`100,000`). When a locale is in effect (through `locale=` or a locale set in
        `GT()`), the locale's own minimum grouping digits value is used instead (it's `2` for
        locales like `"es"` and `"pl"`).
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).
    system
        The numbering system to use for digit grouping. The international numbering system
        (`"intl"`, the default) always separates groups of three digits (e.g., `"1,234,567"`). The
        Indian numbering system (`"ind"`) separates the last three digits and then groups of two,
        which correspond to thousands, lakhs, crores, and higher quantities (e.g., `"12,34,567"`).
        The separator itself is still set by `sep_mark=` (or the locale) and can be turned off with
        `use_seps=False`.


    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator marks will be correct for the given locale. Should any value be
    provided in `sep_mark`, it will be overridden by the locale's preferred value.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    For this example, we'll use the `exibble` dataset as the input table. With the
    [`fmt_integer()`](`great_tables.GT.fmt_integer`) method, we'll format the `num` column as
    integer values having no digit separators (with the `use_seps=False` option).

    ```{python}
    from great_tables import GT, exibble

    (
        GT(exibble)
        .fmt_integer(columns="num", use_seps=False)
    )
    ```
    """

    _validate_number_system(system)

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=min_sep_threshold, locale=locale)

    pf_format = partial(
        fmt_integer_context,
        data=self,
        use_seps=use_seps,
        scale_by=scale_by,
        accounting=accounting,
        compact=compact,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        force_sign=force_sign,
        pattern=pattern,
        system=system,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_integer_context(
    x: float | None,
    data: PFrameData,
    use_seps: bool,
    scale_by: float,
    accounting: bool,
    compact: bool,
    sep_mark: str,
    min_sep_threshold: int,
    force_sign: bool,
    pattern: str,
    context: str,
    system: NumberSystem = "intl",
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by a defined `scale_by` value
    x = _scale_value(x, scale_by=scale_by)

    # Determine whether the value is positive
    is_negative = _has_negative_value(value=x)

    if compact:
        x_formatted = _format_number_compactly(
            value=x,
            decimals=0,
            n_sigfig=None,
            drop_trailing_zeros=False,
            drop_trailing_dec_mark=True,
            use_seps=use_seps,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
            dec_mark="not used",
            force_sign=force_sign,
            system=system,
        )

    else:
        x_formatted = _value_to_decimal_notation(
            value=x,
            decimals=0,
            n_sigfig=None,
            drop_trailing_zeros=False,
            drop_trailing_dec_mark=True,
            use_seps=use_seps,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
            dec_mark="not used",
            force_sign=force_sign,
            system=system,
        )

    # A value that rounds to zero is shown as zero, so it gets no minus sign or accounting style
    if _rounds_to_zero(x_formatted):
        is_negative = False

    # Implement minus sign replacement for `x_formatted` or use accounting style
    if is_negative:
        if accounting:
            x_formatted = f"({_remove_minus(x_formatted)})"

        else:
            minus_mark = _context_minus_mark(context=context)
            x_formatted = _replace_minus(x_formatted, minus_mark=minus_mark)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_scientific(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    decimals: int = 2,
    n_sigfig: int | None = None,
    drop_trailing_zeros: bool = False,
    drop_trailing_dec_mark: bool = True,
    scale_by: float = 1,
    exp_style: str = "x10n",
    pattern: str = "{x}",
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign_m: bool = False,
    force_sign_n: bool = False,
    locale: str | None = None,
) -> GTSelf:
    """
    Format values to scientific notation.

    With numeric values in a table, we can perform formatting so that the targeted values are
    rendered in scientific notation, where extremely large or very small numbers can be expressed in
    a more practical fashion. Here, numbers are written in the form of a mantissa (`m`) and an
    exponent (`n`) with the construction *m* x 10^*n* or *m*E*n*. The mantissa component is a number
    between `1` and `10`. For instance, `2.5 x 10^9` can be used to represent the value
    2,500,000,000 in scientific notation. In a similar way, 0.00000012 can be expressed as
    `1.2 x 10^-7`. Due to its ability to describe numbers more succinctly and its ease of
    calculation, scientific notation is widely employed in scientific and technical domains.

    We have fine control over the formatting task, with the following options:

    - decimals: choice of the number of decimal places, option to drop trailing zeros, and a choice
    of the decimal symbol
    - scaling: we can choose to scale targeted values by a multiplier value
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: providing a locale ID will result in formatting specific to the
    chosen locale

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    decimals
        The `decimals` values corresponds to the exact number of decimal places to use. A value such
        as `2.34` can, for example, be formatted with `0` decimal places and it would result in
        `"2"`. With `4` decimal places, the formatted value becomes `"2.3400"`. The trailing zeros
        can be removed with `drop_trailing_zeros=True`.
    n_sigfig
        A option to format numbers to *n* significant figures. By default, this is `None` and thus
        number values will be formatted according to the number of decimal places set via
        `decimals`. If opting to format according to the rules of significant figures, `n_sigfig`
        must be a number greater than or equal to `1`. Any values passed to the `decimals` and
        `drop_trailing_zeros` arguments will be ignored.
    drop_trailing_zeros
        A boolean value that allows for removal of trailing zeros (those redundant zeros after the
        decimal mark).
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    scale_by
        All numeric values will be multiplied by the `scale_by` value before undergoing formatting.
        Since the `default` value is `1`, no values will be changed unless a different multiplier
        value is supplied.
    exp_style
        Style of formatting to use for the scientific notation formatting. By default this is
        `"x10n"` but other options include using a single letter (e.g., `"e"`, `"E"`, etc.), a
        letter followed by a `"1"` to signal a minimum digit width of one, or `"low-ten"` for using
        a stylized `"10"` marker.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign_m
        Should the plus sign be shown for positive values of the mantissa (first component)? This
        would effectively show a sign for all values except zero on the first numeric component of
        the notation. If so, use `True` (the default for this is `False`), where only negative
        numbers will display a sign.
    force_sign_n
        Should the plus sign be shown for positive values of the exponent (second component)? This
        would effectively show a sign for all values except zero on the second numeric component of
        the notation. If so, use `True` (the default for this is `False`), where only negative
        numbers will display a sign.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator and decimal marks will be correct for the given locale. Should
    a value be provided in `dec_mark` it will be overridden by the locale's preferred values.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    For this example, we'll use the `exibble` dataset as the input table. With the
    [`fmt_scientific()`](`great_tables.GT.fmt_scientific`) method, we'll format the `num` column to
    contain values in scientific formatting.

    ```{python}
    from great_tables import GT, exibble

    (
        GT(exibble)
        .fmt_scientific(columns="num")
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Use a locale-based decimal mark if a locale ID is provided
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)

    pf_format = partial(
        fmt_scientific_context,
        data=self,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        scale_by=scale_by,
        exp_style=exp_style,
        dec_mark=dec_mark,
        force_sign_m=force_sign_m,
        force_sign_n=force_sign_n,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


# Generate a function that will operate on single `x` values in the table body
def fmt_scientific_context(
    x: float | None,
    data: GTData,
    decimals: int,
    n_sigfig: int | None,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    scale_by: float,
    exp_style: str,
    dec_mark: str,
    force_sign_m: bool,
    force_sign_n: bool,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by a defined `scale_by` value
    x = _scale_value(x, scale_by=scale_by)

    # Infinite values (and NaN, e.g., from `inf * 0` with `scale_by=0`) have no mantissa or exponent
    if not math.isfinite(x):
        return _format_nonfinite_value(x, force_sign=force_sign_m, pattern=pattern, context=context)

    # Determine whether the value is positive
    is_positive = _has_positive_value(value=x)

    minus_mark = _context_minus_mark(context=context)

    x_sci_notn = _value_to_scientific_notation(
        value=x,
        decimals=decimals,
        n_sigfig=n_sigfig,
        dec_mark=dec_mark,
    )

    sci_parts = x_sci_notn.split("E")

    m_part, n_part = sci_parts

    # Remove trailing zeros (from the decimal part only) and decimal marks from the `m_part`; the
    # zeros are significant digits when formatting to `n_sigfig`, so they're kept then (as in gt)
    if drop_trailing_zeros and not n_sigfig and dec_mark and dec_mark in m_part:
        m_part = m_part.rstrip("0")
    if drop_trailing_dec_mark and dec_mark:
        m_part = m_part.rstrip(dec_mark)

    # Force the positive sign to be present if the `force_sign_m` option is taken
    if is_positive and force_sign_m:
        m_part = "+" + m_part

    if exp_style == "x10n":
        # Define the exponent string based on the `exp_style` that is the default
        # ('x10n'); this is styled as 'x 10^n' instead of using a fixed symbol like 'E'

        # Determine which values don't require the (x 10^n) for scientific formatting
        # since their order would be zero (this uses the exponent of the rounded value
        # so that, e.g., 9.9999 rounding to 1.00 x 10^1 still gets its exponent)
        small_pos = n_part == "0"

        # Force the positive sign to be present if the `force_sign_n` option is taken
        if force_sign_n and not _str_detect(n_part, "-"):
            n_part = "+" + n_part

        # Implement minus sign replacement for `m_part` and `n_part`
        m_part = _replace_minus(m_part, minus_mark=minus_mark)
        n_part = _replace_minus(n_part, minus_mark=minus_mark)

        if small_pos:
            # If the value is small enough to not require the (x 10^n) notation, then
            # the formatted value is based on only the `m_part`
            x_formatted = m_part
        else:
            # Get the set of exponent marks, which are used to decorate the `n_part`
            exp_marks = _context_exp_marks(context=context)

            # Create the formatted string based on `exp_marks` and the two `sci_parts`
            x_formatted = m_part + exp_marks[0] + n_part + exp_marks[1]

    else:
        # Define the exponent string based on the `exp_style` that's not the default
        # value of 'x10n'

        exp_str = _context_exp_str(exp_style=exp_style, context=context)

        n_min_width = 1 if _str_detect(exp_style, r"^[a-zA-Z]1$") else 2

        # The `n_part` will be extracted here and it must be padded to
        # the defined minimum number of decimal places
        if _str_detect(n_part, "-"):
            n_part = _str_replace(n_part, "-", "")
            n_part = n_part.rjust(n_min_width, "0")
            n_part = "-" + n_part
        else:
            n_part = n_part.rjust(n_min_width, "0")
            if force_sign_n:
                n_part = "+" + n_part

        # Implement minus sign replacement for `m_part` and `n_part`
        m_part = _replace_minus(m_part, minus_mark=minus_mark)
        n_part = _replace_minus(n_part, minus_mark=minus_mark)

        x_formatted = m_part + exp_str + n_part

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_engineering(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    decimals: int = 2,
    n_sigfig: int | None = None,
    drop_trailing_zeros: bool = False,
    drop_trailing_dec_mark: bool = True,
    scale_by: float = 1,
    exp_style: str = "x10n",
    pattern: str = "{x}",
    dec_mark: str = ".",
    force_sign_m: bool = False,
    force_sign_n: bool = False,
    locale: str | None = None,
) -> GTSelf:
    """
    Format values to engineering notation.

    With numeric values in a table, we can perform formatting so that the targeted values are
    rendered in engineering notation, where numbers are written in the form of a mantissa (`m`) and
    an exponent (`n`). When combined the construction is either of the form *m* x 10^*n* or *m*E*n*.
    The mantissa is a number between `1` and `1000` and the exponent is a multiple of `3`. For
    example, the number `0.0000345` can be written in engineering notation as `34.50 x 10^-6`. This
    notation helps to simplify calculations and make it easier to compare numbers that are on very
    different scales.

    Engineering notation is particularly useful as it aligns with SI prefixes (e.g., *milli-*,
    *micro-*, *kilo-*, *mega-*). For instance, numbers in engineering notation with exponent `-3`
    correspond to milli-units, while those with exponent `6` correspond to mega-units.

    We have fine control over the formatting task, with the following options:

    - decimals: choice of the number of decimal places, option to drop trailing zeros, and a choice
    of the decimal symbol
    - scaling: we can choose to scale targeted values by a multiplier value
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: providing a locale ID will result in formatting specific to the
    chosen locale

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    decimals
        The `decimals` values corresponds to the exact number of decimal places to use. A value such
        as `2.34` can, for example, be formatted with `0` decimal places and it would result in
        `"2"`. With `4` decimal places, the formatted value becomes `"2.3400"`. The trailing zeros
        can be removed with `drop_trailing_zeros=True`.
    n_sigfig
        A option to format numbers to *n* significant figures. By default, this is `None` and thus
        number values will be formatted according to the number of decimal places set via
        `decimals`. If opting to format according to the rules of significant figures, `n_sigfig`
        must be a number greater than or equal to `1`. Any values passed to the `decimals` and
        `drop_trailing_zeros` arguments will be ignored.
    drop_trailing_zeros
        A boolean value that allows for removal of trailing zeros (those redundant zeros after the
        decimal mark).
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    scale_by
        All numeric values will be multiplied by the `scale_by` value before undergoing formatting.
        Since the `default` value is `1`, no values will be changed unless a different multiplier
        value is supplied.
    exp_style
        Style of formatting to use for the engineering notation formatting. By default this is
        `"x10n"` but other options include using a single letter (e.g., `"e"`, `"E"`, etc.), a
        letter followed by a `"1"` to signal a minimum digit width of one, or `"low-ten"` for using
        a stylized `"10"` marker.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign_m
        Should the plus sign be shown for positive values of the mantissa (first component)? This
        would effectively show a sign for all values except zero on the first numeric component of
        the notation. If so, use `True` (the default for this is `False`), where only negative
        numbers will display a sign.
    force_sign_n
        Should the plus sign be shown for positive values of the exponent (second component)? This
        would effectively show a sign for all values except zero on the second numeric component of
        the notation. If so, use `True` (the default for this is `False`), where only negative
        numbers will display a sign.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means decimal marks will be correct for the given locale. Should a value be
    provided in `dec_mark` it will be overridden by the locale's preferred values.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    With numeric values in a table, we can perform formatting so that the targeted values are
    rendered in engineering notation. For example, the number `0.0000345` can be written in
    engineering notation as `34.50 x 10^-6`.

    ```{python}
    import polars as pl
    from great_tables import GT

    numbers_df = pl.DataFrame({
        "numbers": [0.0000345, 3450, 3450000]
    })

    GT(numbers_df).fmt_engineering()
    ```

    Notice that in each case, the exponent is a multiple of `3`.

    Let's define a DataFrame that contains two columns of values (one small and one large). After
    creating a simple table with `GT()`, we'll call
    [`fmt_engineering()`](`great_tables.GT.fmt_engineering`) on both columns.

    ```{python}
    small_large_df = pl.DataFrame({
        "small": [10**-i for i in range(12, 0, -1)],
        "large": [10**i for i in range(1, 13)]
    })

    GT(small_large_df).fmt_engineering()
    ```

    Notice that within the form of *m* x 10^*n*, the *n* values move in steps of 3 (away from 0),
    and *m* values can have 1-3 digits before the decimal. Further to this, any values where *n* is
    0 results in a display of only *m* (the first two values in the `large` column demonstrates
    this).

    Engineering notation expresses values so that they align to certain SI prefixes. Here is a table
    that compares select SI prefixes and their symbols to decimal and engineering-notation
    representations of the key numbers.

    ```{python}
    import polars as pl
    from great_tables import GT

    prefixes_df = pl.DataFrame({
        "name": [
            "peta", "tera", "giga", "mega", "kilo",
            None,
            "milli", "micro", "nano", "pico", "femto"
        ],
        "symbol": [
            "P", "T", "G", "M", "k",
            None,
            "m", "μ", "n", "p", "f"
        ],
        "decimal": [float(10**i) for i in range(15, -18, -3)],
    })

    prefixes_df = prefixes_df.with_columns(
        engineering=pl.col("decimal")
    )

    (
        GT(prefixes_df)
        .fmt_number(columns="decimal", n_sigfig=1)
        .fmt_engineering(columns="engineering")
        .sub_missing()
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Use a locale-based decimal mark if a locale ID is provided
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)

    pf_format = partial(
        fmt_engineering_context,
        data=self,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        scale_by=scale_by,
        exp_style=exp_style,
        dec_mark=dec_mark,
        force_sign_m=force_sign_m,
        force_sign_n=force_sign_n,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


# Generate a function that will operate on single `x` values in the table body
def fmt_engineering_context(
    x: float | None,
    data: GTData,
    decimals: int,
    n_sigfig: int | None,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    scale_by: float,
    exp_style: str,
    dec_mark: str,
    force_sign_m: bool,
    force_sign_n: bool,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by a defined `scale_by` value
    x = _scale_value(x, scale_by=scale_by)

    # Infinite values (and NaN, e.g., from `inf * 0` with `scale_by=0`) have no mantissa or exponent
    if not math.isfinite(x):
        return _format_nonfinite_value(x, force_sign=force_sign_m, pattern=pattern, context=context)

    # Determine whether the value is positive
    is_positive = _has_positive_value(value=x)

    minus_mark = _context_minus_mark(context=context)

    # For engineering notation, we need to calculate the exponent that is a multiple of 3
    # (zero, which has no logarithm, gets an exponent of 0) and adjust the mantissa accordingly
    power_3 = 0 if x == 0 else _decimal_exponent(x) // 3 * 3

    # Calculate the mantissa by shifting the decimal point (exactly, so that it's rounded once,
    # from the stored value, as in `fmt_scientific()`)
    m_value = _shift_decimal_point(x, -power_3)

    # If rounding carries the mantissa up to 1000 (e.g., 999,999.5 with two decimals
    # would give `1000.00 x 10^3`), use the next power of 1000 instead (`1.00 x 10^6`); the
    # mantissa is then exactly 1
    if _rounds_up_to(m_value, threshold=1000, decimals=decimals, n_sigfig=n_sigfig):
        power_3 += 3
        m_value = math.copysign(1.0, x)

    m_part = _value_to_decimal_notation(
        value=m_value,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=False,
        sep_mark=",",
        dec_mark=dec_mark,
        force_sign=False,
    )
    n_part = str(power_3)

    # Force the positive sign to be present if the `force_sign_m` option is taken
    if is_positive and force_sign_m:
        m_part = "+" + m_part

    if exp_style == "x10n":
        # Define the exponent string based on the `exp_style` that is the default
        # ('x10n'); this is styled as 'x 10^n' instead of using a fixed symbol like 'E'

        # Determine which values don't require the (x 10^n) for engineering formatting
        # since their exponent would be zero
        small_pos = power_3 == 0

        # Force the positive sign to be present if the `force_sign_n` option is taken
        if force_sign_n and not _str_detect(n_part, "-"):
            n_part = "+" + n_part

        # Implement minus sign replacement for `m_part` and `n_part`
        m_part = _replace_minus(m_part, minus_mark=minus_mark)
        n_part = _replace_minus(n_part, minus_mark=minus_mark)

        if small_pos:
            # If the exponent is zero, then the formatted value is based on only the `m_part`
            x_formatted = m_part
        else:
            # Get the set of exponent marks, which are used to decorate the `n_part`
            exp_marks = _context_exp_marks(context=context)

            # Create the formatted string based on `exp_marks` and the two parts
            x_formatted = m_part + exp_marks[0] + n_part + exp_marks[1]

    else:
        # Define the exponent string based on the `exp_style` that's not the default
        # value of 'x10n'

        exp_str = _context_exp_str(exp_style=exp_style, context=context)

        n_min_width = 1 if _str_detect(exp_style, r"^[a-zA-Z]1$") else 2

        # The `n_part` will be extracted here and it must be padded to
        # the defined minimum number of decimal places
        if _str_detect(n_part, "-"):
            n_part = _str_replace(n_part, "-", "")
            n_part = n_part.rjust(n_min_width, "0")
            n_part = "-" + n_part
        else:
            n_part = n_part.rjust(n_min_width, "0")
            if force_sign_n:
                n_part = "+" + n_part

        # Implement minus sign replacement for `m_part` and `n_part`
        m_part = _replace_minus(m_part, minus_mark=minus_mark)
        n_part = _replace_minus(n_part, minus_mark=minus_mark)

        x_formatted = m_part + exp_str + n_part

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_number_si(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    unit: str | None = None,
    decimals: int = 2,
    n_sigfig: int | None = None,
    drop_trailing_zeros: bool = False,
    drop_trailing_dec_mark: bool = True,
    scale_by: float = 1,
    prefix_mode: str = "engineering",
    pattern: str = "{x}",
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign: bool = False,
    incl_space: bool = True,
    locale: str | None = None,
) -> GTSelf:
    """
    Format values with SI (metric) prefixes.

    Format numeric values with SI (International System of Units) prefixes, automatically selecting
    the appropriate prefix to keep the mantissa in a readable range. SI prefixes range from quetta
    (Q, 10^30) to quecto (q, 10^-30) and are commonly used in scientific and engineering contexts
    to represent very large or very small quantities with units (e.g., `"5.2 kW"`, `"3.8 ng"`,
    `"1.2 GHz"`, etc.).

    This function provides fine control over SI prefix formatting with the following options:

    - unit specification: define a unit to append after the SI prefix (e.g., `"g"` for grams,
    `"W"` for watts, `"Hz"` for hertz, `"m"` for meters)
    - prefix selection: choose between all SI prefixes or only engineering prefixes (powers of
    1000)
    - precision control: specify decimal places for consistent formatting
    - spacing: customize the separator between number, prefix, and unit
    - scaling: we can choose to scale targeted values by a multiplier value (useful for unit
    conversions)
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: use locale-specific decimal and thousands separators

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    unit
        A character string specifying the unit to append after the SI prefix (e.g., `"g"` for
        grams, `"W"` for watts, `"Hz"` for hertz, `"m"` for meters). If `None`, only the prefix
        will be shown.
    decimals
        The `decimals=` values corresponds to the exact number of decimal places to use. A value such
        as `2.34` can, for example, be formatted with `0` decimal places and it would result in
        `"2"`. With `4` decimal places, the formatted value becomes `"2.3400"`. The trailing zeros
        can be removed with `drop_trailing_zeros=True`. If `n_sigfig` is provided, `decimals` is
        ignored.
    n_sigfig
        A option to format numbers to *n* significant figures. By default, this is `None` and thus
        number values will be formatted according to the number of decimal places set via
        `decimals=`. If opting to format according to the rules of significant figures, `n_sigfig=`
        must be a number greater than or equal to `1`. Any values passed to the `decimals=` and
        `drop_trailing_zeros=` arguments will be ignored.
    drop_trailing_zeros
        A boolean value that allows for removal of trailing zeros (those redundant zeros after the
        decimal mark).
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    scale_by
        All numeric values will be multiplied by the `scale_by` value before undergoing formatting.
        Since the `default` value is `1`, no values will be changed unless a different multiplier
        value is supplied. This is useful for unit conversions (e.g., converting metric tons to
        grams by using `scale_by=1_000_000`).
    prefix_mode
        The type of SI prefixes to use. Use `"engineering"` (the default) for prefixes that
        correspond to powers of 1000 only. Use `"decimal"` to include all SI prefixes (also those
        for powers of 10 and 100). See the *SI Prefix Modes* section for details.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    incl_space
        An option for whether to include a space between the numerical value and the SI prefix +
        unit (e.g., `True` for `"1.5 kW"`, `False` for `"1.5kW"`). Per SI convention, there should
        be a space between the value and the unit symbol. The default is `True`.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).
        When provided, overrides `sep_mark` and `dec_mark` with locale-appropriate values.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    SI Prefix Modes
    ---------------
    The `prefix_mode=` argument controls which SI prefixes are used:

    - `"engineering"`: Uses only prefixes for powers of 1000. This includes:

      - greater than 1: k (kilo), M (mega), G (giga), T (tera), P (peta), E (exa), Z (zetta),
        Y (yotta), R (ronna), Q (quetta)
      - less than 1: m (milli), µ (micro), n (nano), p (pico), f (femto), a (atto), z (zepto),
        y (yocto), r (ronto), q (quecto)
      - this is the most common convention in scientific and engineering contexts

    - `"decimal"`: Uses all SI prefixes including those for powers of 10 and 100:

      - additional prefixes for greater-than-1 values: da (deca), h (hecto)
      - additional prefixes for less-than-1 values: d (deci), c (centi)
      - this mode is less commonly used but follows the complete SI standard

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator and decimal marks will be correct for the given locale. Should
    any values be provided in `sep_mark` or `dec_mark`, they will be overridden by the locale's
    preferred values.

    Note that a `locale=` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale=` argument (it is settable there as a value received
    by all other methods that have a `locale=` argument).

    Examples
    --------
    Create a table showing the masses of obelisks located in Rome. The masses are initially in
    metric tons, which we'll convert to grams using `scale_by=1_000_000`. The resulting values are
    then formatted with SI prefixes, which are all here as `M` (mega).

    ```{python}
    import polars as pl
    from great_tables import GT

    obelisks_df = pl.DataFrame(
        {
            "obelisk": [
                "Lateran Obelisk",
                "Vatican Obelisk",
                "Flaminio Obelisk",
                "Pantheon Obelisk",
            ],
            "mass_ton": [455, 331, 235, 30],
        }
    )

    (
        GT(obelisks_df)
        .fmt_number_si(
            columns="mass_ton",
            unit="g",
            decimals=0,
            scale_by=1_000_000,
        )
        .cols_label(obelisk="Obelisk", mass_ton="Mass")
    )
    ```

    Create a table showing measurements of different substances. Each value is formatted with the
    appropriate SI prefix and unit.

    ```{python}
    substances_df = pl.DataFrame(
        {
            "substance": ["Glucose", "Vitamin C", "Caffeine"],
            "amount": [0.0051, 0.000075, 0.0002],
        }
    )

    (
        GT(substances_df)
        .fmt_number_si(columns="amount", unit="g", n_sigfig=2)
    )
    ```

    You can combine [`fmt_number_si()`](`great_tables.GT.fmt_number_si`) with `fmt_units()` and
    `cols_merge()` to format measurements with SI prefixes on units that need special typesetting.

    ```{python}
    measurements_df = pl.DataFrame(
        {
            "measurement": ["Power", "Resistance", "Energy", "Fall Velocity"],
            "value": [1500.0, 2400000.0, 3600000.0, 0.033],
            "unit": ["W", "Ω", "J", "m/s"],
        }
    )

    (
        GT(measurements_df)
        .fmt_number_si(columns="value", decimals=1)
    )
    ```

    We can control the space between the number and prefix/unit with `incl_space`.

    ```{python}
    freqs_df = pl.DataFrame({"frequency": [2.4e9, 5.0e9, 900e6]})

    (
        GT(freqs_df)
        .fmt_number_si(columns="frequency", unit="Hz", incl_space=False, decimals=1)
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=True, locale=locale)
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=1, locale=locale)

    # Stop if `n_sigfig` does not have a valid value
    if n_sigfig is not None:
        _validate_n_sigfig(n_sigfig=n_sigfig)

    pf_format = partial(
        fmt_number_si_context,
        data=self,
        unit=unit,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        scale_by=scale_by,
        prefix_mode=prefix_mode,
        sep_mark=sep_mark,
        dec_mark=dec_mark,
        min_sep_threshold=min_sep_threshold,
        force_sign=force_sign,
        incl_space=incl_space,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


# SI prefix definitions
# Engineering mode: only powers of 1000 (exponents that are multiples of 3)
_SI_PREFIXES_ENGINEERING: list[tuple[int, str]] = [
    (30, "Q"),
    (27, "R"),
    (24, "Y"),
    (21, "Z"),
    (18, "E"),
    (15, "P"),
    (12, "T"),
    (9, "G"),
    (6, "M"),
    (3, "k"),
    (-3, "m"),
    (-6, "\u00b5"),
    (-9, "n"),
    (-12, "p"),
    (-15, "f"),
    (-18, "a"),
    (-21, "z"),
    (-24, "y"),
    (-27, "r"),
    (-30, "q"),
]

# Decimal mode: includes all SI prefixes (adds centi, deci, deca, hecto)
_SI_PREFIXES_DECIMAL: list[tuple[int, str]] = [
    (30, "Q"),
    (27, "R"),
    (24, "Y"),
    (21, "Z"),
    (18, "E"),
    (15, "P"),
    (12, "T"),
    (9, "G"),
    (6, "M"),
    (3, "k"),
    (2, "h"),
    (1, "da"),
    (-1, "d"),
    (-2, "c"),
    (-3, "m"),
    (-6, "\u00b5"),
    (-9, "n"),
    (-12, "p"),
    (-15, "f"),
    (-18, "a"),
    (-21, "z"),
    (-24, "y"),
    (-27, "r"),
    (-30, "q"),
]


def _get_si_prefix(
    abs_x: float, si_table: list[tuple[int, str]], prefix_mode: str
) -> tuple[int, str]:
    """Get the exponent and symbol of the SI prefix to use for an absolute value."""

    if abs_x == 0 or not math.isfinite(abs_x):
        # Zero, infinity and NaN get no prefix
        return 0, ""

    if abs_x >= 1 and abs_x < 1000 and (prefix_mode != "decimal" or abs_x < 10):
        # Values in [1, 1000) need no prefix in engineering mode
        # In decimal mode, values in [1, 10) need no prefix
        return 0, ""

    # Find the best SI prefix: the largest exponent where mantissa >= 1 (the exponent is compared
    # exactly, while a float `10.0**exp` isn't exactly a power of ten)
    x_exp = _decimal_exponent(abs_x)
    for exp, symbol in si_table:
        if exp <= x_exp:
            return exp, symbol

    return 0, ""


def _get_next_si_prefix(exp: int, si_table: list[tuple[int, str]]) -> tuple[int, str] | None:
    """
    Get the exponent and symbol of the next larger SI prefix.

    Having no prefix counts as a step (`(0, "")`); `None` is returned above the largest prefix.
    """

    # The table is ordered from largest to smallest exponent, and has no entry for exponent 0
    larger = [(e, symbol) for e, symbol in si_table if e > exp]

    if exp < 0 and (not larger or larger[-1][0] > 0):
        # Below the smallest positive prefix, the next step up is having no prefix at all
        return 0, ""

    return larger[-1] if larger else None


def fmt_number_si_context(
    x: float | None,
    data: GTData,
    unit: str | None,
    decimals: int,
    n_sigfig: int | None,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    scale_by: float,
    prefix_mode: str,
    sep_mark: str,
    dec_mark: str,
    min_sep_threshold: int,
    force_sign: bool,
    incl_space: bool,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by a defined `scale_by` value
    x = _scale_value(x, scale_by=scale_by)

    # Determine whether the value is negative
    is_negative = _has_negative_value(value=x)

    # Select the appropriate SI prefix table
    si_table = _SI_PREFIXES_DECIMAL if prefix_mode == "decimal" else _SI_PREFIXES_ENGINEERING

    # Determine the appropriate SI prefix
    exp, si_symbol = _get_si_prefix(_exact_abs(x), si_table=si_table, prefix_mode=prefix_mode)

    # Scale the value to the prefix exactly (this is the value itself when there is no prefix)
    scaled_value = _shift_decimal_point(x, -exp) if si_symbol else x

    # If rounding the scaled value carries it up to the next prefix (e.g., 999.96 with one
    # decimal would give `1,000.0`), use the next prefix instead (`1.0 k`); the value is then
    # exactly 1 of the next prefix
    next_prefix = _get_next_si_prefix(exp, si_table=si_table)
    if (
        math.isfinite(x)
        and next_prefix is not None
        and _rounds_up_to(
            scaled_value,
            threshold=10.0 ** (next_prefix[0] - exp),
            decimals=decimals,
            n_sigfig=n_sigfig,
        )
    ):
        exp, si_symbol = next_prefix
        scaled_value = math.copysign(1.0, x)

    # Format the value to decimal notation
    x_formatted = _value_to_decimal_notation(
        value=scaled_value,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=True,
        sep_mark=sep_mark,
        dec_mark=dec_mark,
        force_sign=force_sign,
        min_sep_threshold=min_sep_threshold,
    )

    # A value that rounds to zero is shown as zero, so it gets no minus sign
    if _rounds_to_zero(x_formatted):
        is_negative = False

    # Build the suffix string (space + prefix + unit)
    space_character = " " if incl_space else ""
    suffix = si_symbol + (unit if unit is not None else "")

    if suffix:
        x_formatted = f"{x_formatted}{space_character}{suffix}"

    # Implement minus sign replacement
    if is_negative:
        minus_mark = _context_minus_mark(context=context)
        x_formatted = _replace_minus(x_formatted, minus_mark=minus_mark)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_percent(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    decimals: int = 2,
    drop_trailing_zeros: bool = False,
    drop_trailing_dec_mark: bool = True,
    scale_values: bool = True,
    use_seps: bool = True,
    min_sep_threshold: int = 1,
    accounting: bool = False,
    pattern: str = "{x}",
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign: bool = False,
    placement: str = "right",
    incl_space: bool = False,
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as a percentage.

    With numeric values in a **gt** table, we can perform percentage-based formatting. It is assumed
    the input numeric values are proportional values and, in this case, the values will be
    automatically multiplied by `100` before decorating with a percent sign (the other case is
    accommodated though setting `scale_values` to `False`). For more control over percentage
    formatting, we can use the following options:

    - percent sign placement: the percent sign can be placed after or before the values and a space
    can be inserted between the symbol and the value.
    - decimals: choice of the number of decimal places, option to drop trailing zeros, and a choice
    of the decimal symbol
    - digit grouping separators: options to enable/disable digit separators and provide a choice of
    separator symbol
    - value scaling toggle: choose to disable automatic value scaling in the situation that values
    are already scaled coming in (and just require the percent symbol)
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: providing a locale ID will result in number formatting specific to
    the chosen locale

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    decimals
        The `decimals` values corresponds to the exact number of decimal places to use. A value such
        as `2.34` can, for example, be formatted with `0` decimal places and it would result in
        `"2"`. With `4` decimal places, the formatted value becomes `"2.3400"`. The trailing zeros
        can be removed with `drop_trailing_zeros=True`.
    drop_trailing_zeros
        A boolean value that allows for removal of trailing zeros (those redundant zeros after the
        decimal mark).
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    scale_values
        Should the values be scaled through multiplication by 100? By default this scaling is
        performed since the expectation is that incoming values are usually proportional. Setting to
        `False` signifies that the values are already scaled and require only the percent sign when
        formatted.
    use_seps
        The `use_seps` option allows for the use of digit group separators. The type of digit group
        separator is set by `sep_mark` and overridden if a locale ID is provided to `locale`. This
        setting is `True` by default.
    min_sep_threshold
        The minimum number of digits in the integer part of a number for digit grouping
        separators to be used. The default of `1` uses separators from 4-digit numbers onward
        (e.g., `1,000`), `2` starts at 5-digit numbers (`10,000`), and `3` starts at 6-digit
        numbers (`100,000`). When a locale is in effect (through `locale=` or a locale set in
        `GT()`), the locale's own minimum grouping digits value is used instead (it's `2` for
        locales like `"es"` and `"pl"`).
    accounting
        Whether to use accounting style, which wraps negative numbers in parentheses instead of
        using a minus sign.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    placement
        This option governs the placement of the percent sign. This can be either be `"right"` (the
        default) or `"left"`.
    incl_space
        An option for whether to include a space between the value and the percent sign. The default
        is to not introduce a space character.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).


    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator and decimal marks will be correct for the given locale. Should
    any values be provided in `sep_mark` or `dec_mark`, they will be overridden by the locale's
    preferred values.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    Let’s use the `towny` dataset as the input table. With the
    [`fmt_percent()`](`great_tables.GT.fmt_percent`) method, we'll format the
    `pop_change_2016_2021_pct` column to to display values as percentages (to two decimal places).

    ```{python}
    from great_tables import GT
    from great_tables.data import towny

    towny_mini = (
        towny[["name", "pop_change_2016_2021_pct"]]
        .head(10)
    )

    (GT(towny_mini).fmt_percent("pop_change_2016_2021_pct", decimals=2))
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=min_sep_threshold, locale=locale)
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)

    scale_by = 100 if scale_values else 1

    pf_format = partial(
        fmt_percent_context,
        data=self,
        decimals=decimals,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        accounting=accounting,
        scale_by=scale_by,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
        placement=placement,
        incl_space=incl_space,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_percent_context(
    x: float | None,
    data: GTData,
    decimals: int,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    use_seps: bool,
    accounting: bool,
    scale_by: float,
    sep_mark: str,
    min_sep_threshold: int,
    dec_mark: str,
    force_sign: bool,
    placement: str,
    incl_space: bool,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by a defined `scale_by` value
    x = _scale_value(x, scale_by=scale_by)

    # Determine properties of the value
    is_negative = _has_negative_value(value=x)
    is_positive = _has_positive_value(value=x)

    x_formatted = _value_to_decimal_notation(
        value=x,
        decimals=decimals,
        n_sigfig=None,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
    )

    # Get the context-specific percent mark
    percent_mark = _context_percent_mark(context=context)

    # Create a percent pattern for affixing the percent sign
    space_character = " " if incl_space else ""
    percent_pattern = (
        f"{{x}}{space_character}{percent_mark}"
        if placement == "right"
        else f"{percent_mark}{space_character}{{x}}"
    )

    # A value that rounds to zero is shown as zero, so it gets no sign
    if _rounds_to_zero(x_formatted):
        is_negative = is_positive = False

    if is_negative and placement == "left":
        x_formatted = x_formatted.replace("-", "")
        x_formatted = percent_pattern.replace("{x}", x_formatted)
        x_formatted = "-" + x_formatted
    elif is_positive and force_sign and placement == "left":
        x_formatted = x_formatted.replace("+", "")
        x_formatted = percent_pattern.replace("{x}", x_formatted)
        x_formatted = "+" + x_formatted
    else:
        x_formatted = percent_pattern.replace("{x}", x_formatted)

    # Implement minus sign replacement for `x_formatted` or use accounting style
    if is_negative:
        if accounting:
            x_formatted = f"({_remove_minus(x_formatted)})"

        else:
            minus_mark = _context_minus_mark(context=context)
            x_formatted = _replace_minus(x_formatted, minus_mark=minus_mark)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


# Scale factors for parts-per units (multiply proportion by this value)
_PARTSPER_UNITS: dict[str, dict[str, Any]] = {
    "per-mille": {"factor": 1_000, "symbol": "\u2030"},
    "per-myriad": {"factor": 10_000, "symbol": "\u2031"},
    "pcm": {"factor": 100_000, "symbol": "pcm"},
    "ppm": {"factor": 1_000_000, "symbol": "ppm"},
    "ppb": {"factor": 1_000_000_000, "symbol": "ppb"},
    "ppt": {"factor": 1_000_000_000_000, "symbol": "ppt"},
    "ppq": {"factor": 1_000_000_000_000_000, "symbol": "ppq"},
}


def fmt_partsper(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    to_units: str = "per-mille",
    symbol: str = "auto",
    decimals: int = 2,
    drop_trailing_zeros: bool = False,
    drop_trailing_dec_mark: bool = True,
    scale_values: bool = True,
    use_seps: bool = True,
    pattern: str = "{x}",
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign: bool = False,
    incl_space: str | bool = "auto",
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as parts-per quantities.

    With numeric values in a **gt** table, we can format the values so that they are rendered as
    parts-per quantities (per mille, ppm, ppb, etc.). The following keywords are available for
    the `to_units` parameter:

    - `"per-mille"`: Per mille (1 part in 1,000)
    - `"per-myriad"`: Per myriad (1 part in 10,000)
    - `"pcm"`: Per cent mille (1 part in 100,000)
    - `"ppm"`: Parts per million (1 part in 1,000,000)
    - `"ppb"`: Parts per billion (1 part in 1,000,000,000)
    - `"ppt"`: Parts per trillion (1 part in 1,000,000,000,000)
    - `"ppq"`: Parts per quadrillion (1 part in 1,000,000,000,000,000)

    The function provides a lot of formatting control and we can use the following options:

    - custom symbol/units: override the automatic symbol or units display with a custom choice
    - decimals: choice of the number of decimal places, option to drop trailing zeros, and a choice
      of the decimal symbol
    - digit grouping separators: options to enable/disable digit separators and provide a choice of
      separator symbol
    - value scaling toggle: choose to disable automatic value scaling in the situation that values
      are already scaled coming in (and just require the appropriate symbol or unit display)
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: providing a locale ID will result in number formatting specific to
      the chosen locale

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    to_units
        A keyword that signifies the desired output quantity. This can be any from the following
        set: `"per-mille"`, `"per-myriad"`, `"pcm"`, `"ppm"`, `"ppb"`, `"ppt"`, or `"ppq"`.
    symbol
        The symbol/units to use for the quantity. By default, this is set to `"auto"` and the
        appropriate symbol will be chosen based on the `to_units` keyword and the output context.
        This can be changed by supplying a string (e.g., using `symbol="ppbV"` when
        `to_units="ppb"`).
    decimals
        The `decimals` values corresponds to the exact number of decimal places to use. A value such
        as `2.34` can, for example, be formatted with `0` decimal places and it would result in
        `"2"`. With `4` decimal places, the formatted value becomes `"2.3400"`. The trailing zeros
        can be removed with `drop_trailing_zeros=True`.
    drop_trailing_zeros
        A boolean value that allows for removal of trailing zeros (those redundant zeros after the
        decimal mark).
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    scale_values
        Should the values be scaled through multiplication according to the keyword set in
        `to_units`? By default this is `True` since the expectation is that normally values are
        proportions. Setting to `False` signifies that the values are already scaled and require
        only the appropriate symbol/units when formatted.
    use_seps
        The `use_seps` option allows for the use of digit group separators. The type of digit group
        separator is set by `sep_mark` and overridden if a locale ID is provided to `locale`. This
        setting is `True` by default.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    incl_space
        An option for whether to include a space between the value and the symbol/units. The default
        is `"auto"` which provides spacing dependent on the mark itself (symbols like `‰` get no
        space; text abbreviations like `ppm` get a space). This can be directly controlled by using
        either `True` or `False`.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator and decimal marks will be correct for the given locale. Should
    any values be provided in `sep_mark` or `dec_mark`, they will be overridden by the locale's
    preferred values.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    Let's use a small dataset with proportional values and format them as parts-per-mille values.

    ```{python}
    from great_tables import GT
    import pandas as pd

    df = pd.DataFrame({"x": [0.001, 0.0001, 0.00001, 0.5, -0.005]})

    GT(df).fmt_partsper(columns="x", to_units="per-mille")
    ```

    We can also format values as parts per million (ppm) using a Polars DataFrame:

    ```{python}
    import polars as pl
    from great_tables import GT

    df = pl.DataFrame({"x": [0.0000015, 0.00035, 0.0001]})

    GT(df).fmt_partsper(columns="x", to_units="ppm")
    ```

    If the values are already scaled (not proportions), set `scale_values=False` and use a custom
    symbol:

    ```{python}
    import polars as pl
    from great_tables import GT

    concentrations = pl.DataFrame({"gas": ["CO", "NO2", "O3"], "conc": [1.5, 35.0, 120.0]})

    GT(concentrations).fmt_partsper(columns="conc", to_units="ppb", scale_values=False, symbol="ppbV")
    ```
    """

    # Validate the `to_units` parameter
    if to_units not in _PARTSPER_UNITS:
        raise ValueError(
            f"Invalid `to_units` value: '{to_units}'. "
            f"Must be one of: {', '.join(_PARTSPER_UNITS.keys())}."
        )

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=1, locale=locale)

    # Determine the scale factor
    scale_by = _PARTSPER_UNITS[to_units]["factor"] if scale_values else 1

    # Determine the symbol to use
    resolved_symbol = _PARTSPER_UNITS[to_units]["symbol"] if symbol == "auto" else symbol

    # Determine spacing: "auto" means no space for Unicode symbols (‰, ‱), space for text
    if incl_space == "auto":
        resolved_incl_space = to_units not in ("per-mille", "per-myriad")
    else:
        resolved_incl_space = bool(incl_space)

    pf_format = partial(
        fmt_partsper_context,
        data=self,
        decimals=decimals,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        scale_by=scale_by,
        sep_mark=sep_mark,
        dec_mark=dec_mark,
        min_sep_threshold=min_sep_threshold,
        force_sign=force_sign,
        symbol=resolved_symbol,
        incl_space=resolved_incl_space,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_partsper_context(
    x: float | None,
    data: GTData,
    decimals: int,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    use_seps: bool,
    scale_by: float,
    sep_mark: str,
    dec_mark: str,
    min_sep_threshold: int,
    force_sign: bool,
    symbol: str,
    incl_space: bool,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by the defined scale factor
    x = _scale_value(x, scale_by=scale_by)

    # Determine properties of the value
    is_negative = _has_negative_value(value=x)
    is_positive = _has_positive_value(value=x)

    x_formatted = _value_to_decimal_notation(
        value=x,
        decimals=decimals,
        n_sigfig=None,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        sep_mark=sep_mark,
        dec_mark=dec_mark,
        force_sign=force_sign,
        min_sep_threshold=min_sep_threshold,
    )

    # A value that rounds to zero is shown as zero, so it gets no sign
    if _rounds_to_zero(x_formatted):
        is_negative = is_positive = False

    # Get the context-specific symbol (escape for LaTeX if needed)
    if context == "latex":
        # Escape the per-mille/per-myriad Unicode symbols for LaTeX
        if symbol == "\u2030":
            display_symbol = "\\textperthousand{}"
        elif symbol == "\u2031":
            display_symbol = "\\textpertenthousand{}"
        else:
            display_symbol = symbol
    else:
        display_symbol = symbol

    # Create a pattern for affixing the symbol
    space_character = " " if incl_space else ""
    symbol_pattern = f"{{x}}{space_character}{display_symbol}"

    if is_negative:
        x_formatted = x_formatted.replace("-", "")
        x_formatted = symbol_pattern.replace("{x}", x_formatted)
        x_formatted = "-" + x_formatted
    elif is_positive and force_sign:
        x_formatted = x_formatted.replace("+", "")
        x_formatted = symbol_pattern.replace("{x}", x_formatted)
        x_formatted = "+" + x_formatted
    else:
        x_formatted = symbol_pattern.replace("{x}", x_formatted)

    # Implement minus sign replacement for `x_formatted`
    if is_negative:
        minus_mark = _context_minus_mark(context=context)
        x_formatted = _replace_minus(x_formatted, minus_mark=minus_mark)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_currency(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    currency: str | None = None,
    use_subunits: bool = True,
    decimals: int | None = None,
    drop_trailing_dec_mark: bool = True,
    use_seps: bool = True,
    min_sep_threshold: int = 1,
    accounting: bool = False,
    scale_by: float = 1,
    compact: bool = False,
    pattern: str = "{x}",
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign: bool = False,
    placement: str = "left",
    incl_space: bool = False,
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as currencies.

    With numeric values in a **gt** table, we can perform currency-based formatting with the
    [`fmt_currency()`](`great_tables.GT.fmt_currency`) method. This supports both automatic
    formatting with a three-letter currency code. We have fine control over the conversion from
    numeric values to currency values, where we could take advantage of the following options:

    - the currency: providing a currency code will procure the correct currency symbol and number of
    currency subunits
    - currency symbol placement: the currency symbol can be placed before or after the values
    - decimals/subunits: choice of the number of decimal places, and a choice of the decimal symbol,
    and an option on whether to include or exclude the currency subunits (the decimal portion)
    - digit grouping separators: options to enable/disable digit separators and provide a choice of
    separator symbol
    - scaling: we can choose to scale targeted values by a multiplier value
    - pattern: option to use a text pattern for decoration of the formatted currency values
    - locale-based formatting: providing a locale ID will result in currency formatting specific to
    the chosen locale; it will also retrieve the locale's currency if none is explicitly given

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    currency
        The currency to use for the numeric value. This input can be supplied as a 3-letter currency
        code (e.g., `"USD"` for U.S. Dollars, `"EUR"` for the Euro currency). In LaTeX output,
        currency symbols are written as Unicode characters. Some of them (e.g., `"₹"` for `"INR"`,
        `"₪"` for `"ILS"`, `"₽"` for `"RUB"`, or `"₺"` for `"TRY"`) aren't available in pdfLaTeX, so
        tables using these currencies need to be compiled with XeLaTeX or LuaLaTeX.
    use_subunits
        An option for whether the subunits portion of a currency value should be displayed. For
        example, with an input value of `273.81`, the default formatting will produce `"$273.81"`.
        Removing the subunits (with `use_subunits = False`) will give us `"$273"`.
    decimals
        The `decimals` values corresponds to the exact number of decimal places to use. This value
        is optional as a currency has an intrinsic number of decimal places (i.e., the subunits).
        A value such as `2.34` can, for example, be formatted with `0` decimal places and if the
        currency used is `"USD"` it would result in `"$2"`. With `4` decimal places, the formatted
        value becomes `"$2.3400"`.
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    use_seps
        The `use_seps` option allows for the use of digit group separators. The type of digit group
        separator is set by `sep_mark` and overridden if a locale ID is provided to `locale`. This
        setting is `True` by default.
    min_sep_threshold
        The minimum number of digits in the integer part of a number for digit grouping
        separators to be used. The default of `1` uses separators from 4-digit numbers onward
        (e.g., `1,000`), `2` starts at 5-digit numbers (`10,000`), and `3` starts at 6-digit
        numbers (`100,000`). When a locale is in effect (through `locale=` or a locale set in
        `GT()`), the locale's own minimum grouping digits value is used instead (it's `2` for
        locales like `"es"` and `"pl"`).
    accounting
        Whether to use accounting style, which wraps negative numbers in parentheses instead of
        using a minus sign.
    scale_by
        All numeric values will be multiplied by the `scale_by` value before undergoing formatting.
        Since the `default` value is `1`, no values will be changed unless a different multiplier
        value is supplied.
    compact
        Whether to use compact formatting. This is a boolean value that, when set to `True`, will
        format large numbers in a more compact form (e.g., `1,000,000` becomes `1M`). This is
        `False` by default.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    placement
        The placement of the currency symbol. This can be either be `"left"` (as in `"$450"`) or
        `"right"` (which yields `"450$"`).
    incl_space
        An option for whether to include a space between the value and the currency symbol. The
        default is to not introduce a space character.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).


    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator and decimal marks will be correct for the given locale. Should
    any values be provided in `sep_mark` or `dec_mark`, they will be overridden by the locale's
    preferred values. In addition to number formatting, providing a `locale` value and not providing
    a `currency` allows **Great Tables** to obtain the currency code from the locale's territory.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    Let's use the `exibble` dataset to create a table. With the
    [`fmt_currency()`](`great_tables.GT.fmt_currency`) method, we'll format the `currency` column to
    display monetary values.

    ```{python}
    from great_tables import GT, exibble

    (
        GT(exibble)
        .fmt_currency(
            columns="currency",
            decimals=3,
            use_seps=False
        )
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=min_sep_threshold, locale=locale)
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)

    # Resolve the currency either from direct input in `currency` or through a locale
    if currency is None:
        # If not providing a `currency` code, we can obtain the currency code from the locale
        currency_resolved = _get_locale_currency_code(locale=locale)
    else:
        # Cast the `currency` value to a string
        currency_resolved = str(currency)
        # Stop if `currency_resolved` does not have a valid value
        _validate_currency(currency=currency_resolved)

    # Get the number of decimal places for the currency; this takes into account whether
    # the currency uses subunits or not and whether decimals are explicitly set
    decimals = _get_currency_decimals(
        currency=currency_resolved, decimals=decimals, use_subunits=use_subunits
    )

    pf_format = partial(
        fmt_currency_context,
        data=self,
        currency=currency_resolved,
        decimals=decimals,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        accounting=accounting,
        scale_by=scale_by,
        compact=compact,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
        placement=placement,
        incl_space=incl_space,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_currency_context(
    x: float | None,
    data: GTData,
    currency: str,
    decimals: int,
    drop_trailing_dec_mark: bool,
    use_seps: bool,
    accounting: bool,
    scale_by: float,
    compact: bool,
    sep_mark: str,
    min_sep_threshold: int,
    dec_mark: str,
    force_sign: bool,
    placement: str,
    incl_space: bool,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Scale `x` value by a defined `scale_by` value
    x = _scale_value(x, scale_by=scale_by)

    # Determine properties of the value
    is_negative = _has_negative_value(value=x)
    is_positive = _has_positive_value(value=x)

    # Get the currency symbol on the basis of a valid currency code
    currency_symbol = _get_currency_str(currency=currency)

    if currency_symbol == "$":
        currency_symbol = _context_dollar_mark(context=context)
    elif context == "latex":
        # Symbols are stored for HTML (e.g., `&#8364;` for EUR), so write them as characters and
        # escape any LaTeX special characters (e.g., the `$` in `R$` for BRL)
        currency_symbol = _latex_escape(html.unescape(currency_symbol))

    # Choose the appropriate formatting function based on the `compact=` option
    f_formatter = _format_number_compactly if compact else _value_to_decimal_notation

    # Perform formatting to decimal notation
    x_formatted = f_formatter(
        value=x,
        decimals=decimals,
        n_sigfig=None,
        drop_trailing_zeros=False,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
    )

    # Create a currency pattern for affixing the currency symbol
    space_character = " " if incl_space else ""
    currency_pattern = (
        f"{{x}}{space_character}{currency_symbol}"
        if placement == "right"
        else f"{currency_symbol}{space_character}{{x}}"
    )

    # A value that rounds to zero is shown as zero, so it gets no sign
    if _rounds_to_zero(x_formatted):
        is_negative = is_positive = False

    if is_negative and placement == "left":
        x_formatted = x_formatted.replace("-", "")
        x_formatted = currency_pattern.replace("{x}", x_formatted)
        x_formatted = "-" + x_formatted
    elif is_positive and force_sign and placement == "left":
        x_formatted = x_formatted.replace("+", "")
        x_formatted = currency_pattern.replace("{x}", x_formatted)
        x_formatted = "+" + x_formatted
    else:
        x_formatted = currency_pattern.replace("{x}", x_formatted)

    # Implement minus sign replacement for `x_formatted` or use accounting style
    if is_negative:
        if accounting:
            x_formatted = f"({_remove_minus(x_formatted)})"

        else:
            minus_mark = _context_minus_mark(context=context)
            x_formatted = _replace_minus(x_formatted, minus_mark=minus_mark)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_roman(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    case: str = "upper",
    pattern: str = "{x}",
) -> GTSelf:
    """
    Format values as Roman numerals.

    With numeric values in a **gt** table we can transform those to Roman numerals, rounding values
    as necessary.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    case
        Should Roman numerals should be rendered as uppercase (`"upper"`) or lowercase (`"lower"`)
        letters? By default, this is set to `"upper"`.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Let's first create a DataFrame containing small numeric values and then introduce that to
    [`GT()`](`great_tables.GT`). We'll then format the `roman` column to appear as Roman numerals
    with the [`fmt_roman()`](`great_tables.GT.fmt_roman`) method.

    ```{python}
    import pandas as pd
    from great_tables import GT

    numbers_tbl = pd.DataFrame({"arabic": [1, 8, 24, 85], "roman": [1, 8, 24, 85]})

    (
        GT(numbers_tbl, rowname_col="arabic")
        .fmt_roman(columns="roman")
    )
    ```
    """

    # Check that the `case` value is valid and only consists of the string 'upper' or 'lower'
    _validate_case(case=case)

    pf_format = partial(
        fmt_roman_context,
        data=self,
        case=case,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_roman_context(
    x: float,
    data: GTData,
    case: str,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # Get the absolute value of `x` so that negative values are handled
    x = abs(x)

    # Round x to 0 digits with the R-H-U method of rounding (for reproducibility purposes);
    # infinity is left as is since, like other values that are too large, it can't be a
    # roman numeral
    if not math.isinf(x):
        x = _round_rhu(x, 0)

    # Determine if `x` is in the range of 1 to 3899 and if it is zero
    x_is_in_range = x > 0 and x < 3900
    x_is_zero = x == 0

    if not x_is_in_range and not x_is_zero:
        # We cannot format a 'large' integer to roman numerals, so we use a string that
        # indicates this (it is still decorated by `pattern=` below)
        x_formatted = "ex terminis"
    elif x_is_zero:
        # Zero is a special case and is handled separately with the character 'N'
        # which stands for 'nulla' (i.e., 'nothing')
        x_formatted = "N"
    else:
        # All other values are formatted with the `_as_roman()` utility function
        x_formatted = _as_roman(x)

    # Transform the case of the formatted value
    if case == "upper":
        pass
    else:
        x_formatted = x_formatted.lower()

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_fraction(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    accuracy: str | int = "low",
    simplify: bool = True,
    layout: str = "inline",
    use_seps: bool = True,
    pattern: str = "{x}",
    sep_mark: str = ",",
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as mixed fractions.

    With numeric values in a **gt** table, we can perform mixed-fraction-based formatting. There are
    several options for setting the accuracy of the fractions. Furthermore, there is an option for
    choosing a layout (i.e., typesetting style) for the mixed-fraction output.

    The `accuracy=` parameter controls the type of fractions generated. It can be one of the
    keywords `"low"`, `"med"`, or `"high"` (to generate fractions with denominators of up to 1, 2,
    or 3 digits, respectively) or an integer value greater than zero to obtain fractions with a
    fixed denominator (`2` yields halves, `3` is for thirds, `4` is quarters, etc.). If choosing to
    provide a numeric value for `accuracy=`, the option to simplify the fraction (where possible)
    can be taken with `simplify=True` (the default for this is `True`).

    For HTML output, the `"inline"` layout (the default) places the numerals of the fraction on the
    baseline and uses a standard slash character. The `"diagonal"` layout will generate fractions
    that are typeset with raised and lowered numerals and a virgule (i.e., a fraction slash).

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    accuracy
        The accuracy of the fraction. Use `"low"` for denominators up to 1 digit (e.g., halves,
        thirds, quarters, etc.), `"med"` for up to 2-digit denominators, and `"high"` for up to
        3-digit denominators. Alternatively, supply a positive integer to fix the denominator to
        that value (e.g., `accuracy=8` gives eighths). The default is `"low"`.
    simplify
        When `accuracy=` is an integer, should the fraction be simplified via GCD reduction? For
        while `simplify=False` yields `"2/4"`. Has no effect when `accuracy=` is a keyword example,
        with `accuracy=4` and a value of `0.5`, `simplify=True` yields a `"1/2"` string
        representation. The default is `True`.
    layout
        The layout of the fraction. `"inline"` renders the fraction on the baseline with a standard
        slash (e.g., `3/4`). `"diagonal"` renders a diagonal fraction with a raised numerator,
        lowered denominator, and a fraction slash character (HTML only and falls back to inline in
        other contexts). The default is `"inline"`.
    use_seps
        Whether to use digit grouping separators in the whole-number part. The default is `True`.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The mark to use as a thousands separator. The default is `","` and can be overridden by a
        locale setting.
    locale
        An optional locale ID that can be used for applying a locale-specific thousands separator.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Let's format the `num` column of the `exibble` dataset as fractions with the default `"low"`
    accuracy.

    ```{python}
    from great_tables import GT
    from great_tables.data import exibble

    (
        GT(exibble[["num", "char"]])
        .fmt_fraction(columns="num")
    )
    ```

    We can increase the accuracy to `"med"` or `"high"` for more precise fractions. We can also use
    a fixed denominator (here, tenths) to get uniform fractions. With `simplify=False`, the
    denominator stays fixed even when the fraction could be reduced, and `layout="diagonal"` gives
    us a typeset diagonal-fraction style.

    ```{python}
    import polars as pl

    df = pl.DataFrame({
        "item": ["Icate", "Octyl", "Sepal", "Unkel"],
        "frac_sales": [0.3, 0.1, 0.8, 0.5],
        "frac_revenue": [0.2, 0.4, 0.7, 0.9],
    })

    (
        GT(df, rowname_col="item")
        .fmt_fraction(
            columns=["frac_sales", "frac_revenue"],
            accuracy=10,
            simplify=False,
            layout="diagonal",
        )
    )
    ```

    The `pizzaplace` dataset has a full year of sales data. We can summarize the sell count and
    revenue by pizza size within each type, then express those as fractions. Using
    `layout="diagonal"` with `accuracy=10` and `simplify=False` gives uniform tenths in a typeset
    style, and `text_transform()` replaces any zero-fraction values with *nil*.

    ```{python}
    import polars as pl
    import polars.selectors as cs
    from great_tables import md, loc, data

    grouped = (
        data.pl.pizzaplace
        .group_by("type", "size")
        .agg(
            pl.col("id").count().alias("sold"),
            pl.col("price").sum().alias("income"),
        )
        .with_columns(
            (pl.col("sold") / pl.col("sold").sum().over("type")).alias("f_sold"),
            (pl.col("income") / pl.col("income").sum().over("type")).alias("f_income"),
        )
        .sort(["type", "income"], descending=[False, True])
    )

    (
        GT(grouped, rowname_col="size", groupname_col="type")
        .tab_header(
            title="Pizzas Sold in 2015",
            subtitle="Fraction of Sell Count and Revenue by Size per Type",
        )
        .fmt_integer(columns="sold")
        .fmt_currency(columns="income")
        .fmt_fraction(
            columns=cs.starts_with("f_"),
            accuracy=10,
            simplify=False,
            layout="diagonal",
        )
        .sub_missing(missing_text="")
        .tab_spanner(label="Sold", columns=cs.contains("sold"))
        .tab_spanner(label="Revenue", columns=cs.contains("income"))
        .text_transform(
            locations=loc.body(),
            fn=lambda x: "<em>nil</em>" if x == "0" else x,
        )
        .cols_label(
            sold="Amount",
            income="Amount",
            f_sold=md("_f_"),
            f_income=md("_f_"),
        )
        .cols_align(align="center", columns=cs.starts_with("f"))
        .tab_options(
            table_width="400px",
            row_group_as_column=True,
        )
    )
    ```
    """
    if isinstance(accuracy, str) and accuracy not in ("low", "med", "high"):
        raise ValueError(
            f"accuracy must be 'low', 'med', 'high', or a positive integer, got {accuracy!r}"
        )
    if isinstance(accuracy, int) and accuracy < 1:
        raise ValueError(f"accuracy must be a positive integer when numeric, got {accuracy}")
    if layout not in ("inline", "diagonal"):
        raise ValueError(f"layout must be 'inline' or 'diagonal', got {layout!r}")

    locale = _resolve_locale(self, locale=locale)
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=1, locale=locale)

    pf_format = partial(
        fmt_fraction_context,
        data=self,
        accuracy=accuracy,
        simplify=simplify,
        layout=layout,
        use_seps=use_seps,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def _gcd(a: int, b: int) -> int:
    while b:
        a, b = b, a % b
    return a


def _format_whole_number(
    value: int, use_seps: bool, sep_mark: str, min_sep_threshold: int = 1
) -> str:
    s = str(value)
    # Grouping starts at `min_sep_threshold + 3` digits (four with the default of `1`)
    if not use_seps or not sep_mark or len(s) < min_sep_threshold + 3:
        return s
    result = ""
    for count, digit in enumerate(reversed(s)):
        if count and count % 3 == 0:
            result = sep_mark + result
        result = digit + result
    return result


def _make_diagonal_fraction_html(numerator: str, denominator: str) -> str:
    return (
        f'<span style="font-size:0.6em;line-height:0.6em;vertical-align:0.45em;">{numerator}</span>'
        f'<span style="font-size:0.7em;line-height:0.7em;vertical-align:0.15em;">&#x2044;</span>'
        f'<span style="font-size:0.6em;line-height:0.6em;vertical-align:-0.05em;">{denominator}</span>'
    )


def fmt_fraction_context(
    x: float,
    data: GTData,
    accuracy: str | int,
    simplify: bool,
    layout: str,
    use_seps: bool,
    sep_mark: str,
    min_sep_threshold: int,
    pattern: str,
    context: str,
) -> str:
    from ._fractions_data import _lookup_fraction

    if is_na(data._tbl_data, x):
        return x

    if not math.isfinite(x):
        return _format_nonfinite_value(x, force_sign=False, pattern=pattern, context=context)

    is_negative = x < 0
    x_abs = abs(x)

    # `int()` and `float()` are used so that NumPy scalars (e.g., from a pandas `int64` column) are
    # handled too: NumPy integers don't support `math.trunc()` and can overflow when scaled below
    big_x = int(x_abs)
    small_x = float(x_abs - big_x)

    # Round fractional part to 3 decimal places (Round-Half-Up for consistency with gt R)
    small_x = _round_rhu(small_x * 1000, 0) / 1000

    if isinstance(accuracy, str):
        fraction_str = _lookup_fraction(small_x, accuracy)
    else:
        numerator = int(_round_rhu(small_x * accuracy, 0))
        if numerator == 0:
            fraction_str = "0"
        elif numerator == accuracy:
            fraction_str = "1"
        else:
            if simplify:
                g = _gcd(numerator, accuracy)
                numerator //= g
                denominator = accuracy // g
            else:
                denominator = accuracy
            fraction_str = f"{numerator}/{denominator}"

    # Handle sentinel "1" (fractional part rounds up to next integer)
    if fraction_str == "1":
        big_x += 1
        fraction_str = ""
    elif fraction_str == "0":
        fraction_str = ""

    # Format the whole-number part
    big_x_str = (
        _format_whole_number(big_x, use_seps, sep_mark, min_sep_threshold) if big_x != 0 else ""
    )

    # Build the diagonal fraction HTML if needed
    if fraction_str and layout == "diagonal" and context == "html" and "/" in fraction_str:
        num_str, den_str = fraction_str.split("/")
        fraction_str = _make_diagonal_fraction_html(num_str, den_str)

    # Combine whole number and fraction
    if big_x_str and fraction_str:
        if layout == "diagonal" and context == "html":
            x_formatted = big_x_str + " " + fraction_str
        else:
            x_formatted = big_x_str + " " + fraction_str
    elif big_x_str:
        x_formatted = big_x_str
    elif fraction_str:
        x_formatted = fraction_str
    else:
        x_formatted = "0"

    if is_negative and x_formatted != "0":
        minus_mark = _context_minus_mark(context=context)
        x_formatted = minus_mark + x_formatted

    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_chem(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
) -> GTSelf:
    """
    Format chemical formulas.

    With [`fmt_chem()`](`great_tables.GT.fmt_chem`) you can format chemical formulas and reactions
    in the table body. Often the input text will be in a common form representing single compounds
    (like `"C2H4O"` for acetaldehyde) but chemical reactions can also be used (e.g., `"2 CH3OH ->
    CH3OCH3 + H2O"`). So long as the text within the targeted cells conforms to the specialized
    chemistry notation, the appropriate conversions will occur. Details on chemistry notation can be
    found in the section entitled *How to use chemistry notation*.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    How to use chemistry notation
    -----------------------------
    The chemistry notation involves a shorthand for writing chemical formulas and reactions. It
    should feel familiar in its basic usage and the more advanced typesetting tries to limit the
    amount of syntax needed. Here are examples of the supported features:

    - `"CH3O2"` and `"(NH4)2S"` will render with subscripted numerals

    - Charges can be expressed with terminating `"+"` or `"-"`, as in `"H+"` and `"[AgCl2]-"`;
      numbered charges use: `"CrO4^2-"`, `"Fe^n+"`, `"Y^99+"`, or `"Y^{99+}"`

    - Stoichiometric values can prepend formulas: `"2H2O2"`, `"2 H2O2"`, `"0.5 H2O"`,
      `"1/2 H2O"`, `"(1/2) H2O"`

    - Certain standalone lowercase letters are automatically italicized: `"NO_x"` and
      `"x Na(NH4)HPO4"` will have italic *x* characters; you can always italicize with `"*"`
      (as in `"*n* H2O"`)

    - Chemical isotopes can be rendered as: `"^{227}_{90}Th"` or `"^227_90Th"`; nuclides are
      similar: `"^{0}_{-1}n^{-}"`, `"^0_-1n-"`

    - Chemical reactions can use `"+"` signs and a variety of reaction arrows:
      `"->"`, `"<-"`, `"<->"`, `"<-->"`, `"<=>"`, `"<=>>"`, `"<<=>"`

    - Center dots (for addition compounds) use a single `"."` or `"*"` surrounded by spaces:
      `"KCr(SO4)2 . 12 H2O"` or `"KCr(SO4)2 * 12 H2O"`

    - Single and double bonds between adjacent characters use `"-"` or `"="`:
      `"C6H5-CHO"`, `"CH3CH=CH2"`

    - Greek letters can be inserted using colon notation: `":delta: ^13C"`

    Examples
    --------
    Let's use the `reactions` dataset and create a table of gas-phase reaction rate constants for
    selected terminal alkenes. The `cmpd_formula` column contains chemical formulas and
    [`fmt_chem()`](`great_tables.GT.fmt_chem`) will render them with properly subscripted numerals.
    Notice that the column labels for O₃ and NO₃ use the `{{%...%}}` chemistry notation within
    `cols_label()`.

    ```{python}
    import polars as pl
    import polars.selectors as cs
    from great_tables import GT, data

    reactions_mini = (
        data.pl.reactions
        .filter(
            (pl.col("cmpd_type") == "terminal monoalkene")
            & pl.col("cmpd_name").str.starts_with("1-")
        )
        .select("cmpd_name", "cmpd_formula", cs.ends_with("k298"))
    )

    (
        GT(reactions_mini)
        .tab_header(title="Gas-Phase Reactions of Selected Terminal Alkenes")
        .tab_spanner(
            label="Reaction Rate Constant at 298 K",
            columns=cs.ends_with("k298"),
        )
        .fmt_chem(columns="cmpd_formula")
        .fmt_scientific(columns=cs.ends_with("k298"))
        .sub_missing()
        .cols_label(
            cmpd_name="Alkene",
            cmpd_formula="Formula",
            OH_k298="OH",
            O3_k298="{{%O3%}}",
            NO3_k298="{{%NO3%}}",
            Cl_k298="Cl",
        )
        .opt_align_table_header(align="left")
    )
    ```

    The `photolysis` dataset contains photolysis pathways where both the `cmpd_formula` and
    `products` columns hold chemistry notation. We can format both columns with
    [`fmt_chem()`](`great_tables.GT.fmt_chem`) and use `cols_merge()` to combine the compound name
    with its formatted formula.

    ```{python}
    photolysis_mini = (
        data.pl.photolysis
        .filter(pl.col("cmpd_name").is_in([
            "hydrogen peroxide", "nitrous acid",
            "nitric acid", "acetaldehyde",
            "methyl peroxide", "methyl nitrate",
            "ethyl nitrate", "isopropyl nitrate",
        ]))
        .select(pl.exclude("l", "m", "n", "quantum_yield", "type"))
    )

    (
        GT(photolysis_mini)
        .tab_header(title="Photolysis Pathways of Selected VOCs")
        .fmt_chem(columns=["cmpd_formula", "products"])
        .cols_merge(
            columns=["cmpd_name", "cmpd_formula"],
            pattern="{0}, {1}",
        )
        .cols_label(cmpd_name="Compound", products="Products")
        .cols_hide(columns=["wavelength_nm", "sigma_298_cm2"])
        .opt_align_table_header(align="left")
    )
    ```

    The `nuclides` dataset contains isotope data with nuclide notation (e.g., `"^{12}_{6}C"`) that
    [`fmt_chem()`](`great_tables.GT.fmt_chem`) renders with properly overstruck mass and atomic
    numbers. Here we show isotopes of hydrogen and carbon.

    ```{python}
    from great_tables import md

    nuclides_mini = (
        data.pl.nuclides
        .filter(pl.col("element").is_in(["H", "C"]))
        .with_columns(pl.col("nuclide").str.replace(r"[0-9]+$", ""))
        .select("nuclide", "atomic_mass", "half_life", "decay_1", "is_stable")
    )

    stable = (
        nuclides_mini.with_row_index()
        .filter(pl.col("is_stable") == "TRUE")["index"].to_list()
    )
    unstable = (
        nuclides_mini.with_row_index()
        .filter(pl.col("is_stable") == "FALSE")["index"].to_list()
    )

    (
        GT(nuclides_mini, rowname_col="nuclide")
        .tab_header(title="Isotopes of Hydrogen and Carbon")
        .tab_stubhead(label="Isotope")
        .fmt_chem(columns="nuclide")
        .fmt_scientific(columns="half_life")
        .fmt_number(columns="atomic_mass", decimals=4, scale_by=1 / 1e6)
        .sub_missing(
            columns="half_life", rows=stable, missing_text=md("**STABLE**")
        )
        .sub_missing(columns="half_life", rows=unstable)
        .sub_missing(columns="decay_1")
        .cols_hide(columns="is_stable")
        .cols_align(align="center", columns="decay_1")
        .cols_label(decay_1="Decay Mode")
        .opt_align_table_header(align="left")
        .opt_vertical_padding(scale=0.5)
    )
    ```
    """

    def fmt_chem_fn(x: str, context: str = "html"):
        if is_na(self._tbl_data, x):
            return x

        return _chem_to_latex(x) if context == "latex" else _chem_to_html(x)

    return fmt_by_context(self, pf_format=fmt_chem_fn, columns=columns, rows=rows)


# Reaction arrows, longest first so that `<-->` isn't read as `<-` and `->`; the HTML and LaTeX
# forms are the same characters (LaTeX's are math symbols from its base fonts)
_REACTION_ARROWS = [
    ("<-->", "&#8596;", "\\ensuremath{\\leftrightarrow}"),
    ("<=>>", "&#8640;", "\\ensuremath{\\rightharpoonup}"),
    ("<<=>", "&#8637;", "\\ensuremath{\\leftharpoondown}"),
    ("<=>", "&#8652;", "\\ensuremath{\\rightleftharpoons}"),
    ("<->", "&#8596;", "\\ensuremath{\\leftrightarrow}"),
    ("->", "&#8594;", "\\ensuremath{\\rightarrow}"),
    ("<-", "&#8592;", "\\ensuremath{\\leftarrow}"),
]


@dataclass(frozen=True)
class _ChemMarkup:
    """The output-specific pieces of a formatted chemical formula (see `_chem_to_html()`)."""

    arrows: dict[str, str]
    thin_space: str
    middot: str
    minus: str
    escape: Callable[[str], str]
    em: Callable[[str], str]
    sub: Callable[[str], str]
    sup: Callable[[str], str]
    # The mass number (superscript) and atomic number (subscript, may be "") of a nuclide
    nuclide: Callable[[str, str], str]
    # A `:name:` symbol (e.g., `:alpha:`)
    symbol: Callable[[str], str]


def _chem_html_nuclide(mass: str, atomic: str) -> str:
    from great_tables._helpers import _units_html_sub_super

    return _units_html_sub_super(content_sub=atomic or "&nbsp;", content_sup=mass)


def _chem_html_symbol(sym: str) -> str:
    from great_tables._helpers import _units_symbol_replacements

    return _units_symbol_replacements(sym)


def _chem_latex_symbol(sym: str) -> str:
    from great_tables._helpers import UNITS_SYMBOLS_LATEX

    return UNITS_SYMBOLS_LATEX.get(sym, _latex_escape(sym))


_CHEM_HTML = _ChemMarkup(
    arrows={text: html_arrow for text, html_arrow, _ in _REACTION_ARROWS},
    thin_space="&#8201;",
    middot="&middot;",
    minus="&minus;",
    escape=lambda text: text,
    em=lambda text: f"<em>{text}</em>",
    sub=lambda text: (
        f'<span style="white-space:nowrap;"><sub style="line-height:0;">{text}</sub></span>'
    ),
    sup=lambda text: (
        f'<span style="white-space:nowrap;"><sup style="line-height:0;">{text}</sup></span>'
    ),
    nuclide=_chem_html_nuclide,
    symbol=_chem_html_symbol,
)

# In LaTeX, a nuclide's mass and atomic numbers are stacked as math pre-scripts (`{}^{14}_{6}`)
_CHEM_LATEX = _ChemMarkup(
    arrows={text: latex_arrow for text, _, latex_arrow in _REACTION_ARROWS},
    thin_space="\\,",
    middot="\\ensuremath{\\cdot}",
    minus="\\ensuremath{-}",
    escape=_latex_escape,
    em=lambda text: f"\\emph{{{text}}}",
    sub=lambda text: f"\\textsubscript{{{text}}}",
    sup=lambda text: f"\\textsuperscript{{{text}}}",
    nuclide=lambda mass, atomic: (
        f"\\ensuremath{{{{}}^{{{mass}}}_{{{atomic}}}}}"
        if atomic
        else f"\\ensuremath{{{{}}^{{{mass}}}}}"
    ),
    symbol=_chem_latex_symbol,
)


def _chem_to_html(formula: str) -> str:
    return _chem_render(formula, _CHEM_HTML)


def _chem_to_latex(formula: str) -> str:
    return _chem_render(formula, _CHEM_LATEX)


def _chem_render(formula: str, markup: _ChemMarkup) -> str:
    # Arrows are swapped for placeholders holding their index (their text would be matched by a
    # later, shorter arrow)
    for i, (arrow_text, _, _) in enumerate(_REACTION_ARROWS):
        formula = formula.replace(arrow_text, f" \x00ARROW{i}\x00 ")

    tokens = formula.split()
    parts: list[str] = []
    pending_coeff: str | None = None

    for token in tokens:
        if token.startswith("\x00ARROW") and token.endswith("\x00"):
            if pending_coeff is not None:
                parts.append(pending_coeff)
                pending_coeff = None
            arrow = markup.arrows[_REACTION_ARROWS[int(token[6:-1])][0]]
            parts.append(f" {arrow} ")
            continue

        if token == "+" and parts:
            if pending_coeff is not None:
                parts.append(pending_coeff)
                pending_coeff = None
            parts.append(" + ")
            continue

        if token in (".", "*"):
            if pending_coeff is not None:
                parts.append(pending_coeff)
                pending_coeff = None
            parts.append(f" {markup.middot} ")
            continue

        if pending_coeff is not None:
            part = _chem_token(token, markup)
            parts.append(pending_coeff + markup.thin_space + part)
            pending_coeff = None
            continue

        if re.match(r"^[0-9]+(?:\.[0-9]+)?$|^[0-9]+/[0-9]+$|^\([0-9]+/[0-9]+\)$", token):
            pending_coeff = token
            continue

        if token in ("x", "n"):
            pending_coeff = markup.em(token)
            continue

        star_m = re.match(r"^\*([a-zA-Z])\*$", token)
        if star_m:
            pending_coeff = markup.em(star_m.group(1))
            continue

        part = _chem_token(token, markup)
        parts.append(part)

    if pending_coeff is not None:
        parts.append(pending_coeff)

    return "".join(parts)


def _chem_token(token: str, markup: _ChemMarkup) -> str:
    isotope_m = re.match(
        r"^\^(?:\{([0-9+-]+)\}|([0-9+-]+))(?:_(?:\{([0-9+-]+)\}|([0-9+-]+)))?(.+)$",
        token,
    )
    if isotope_m:
        mass = isotope_m.group(1) or isotope_m.group(2)
        atomic = isotope_m.group(3) or isotope_m.group(4) or ""
        rest = isotope_m.group(5)
        return markup.nuclide(mass, atomic) + _chem_token(rest, markup)

    colon_m = re.match(r"^(:[a-zA-Z]+:)(.*)$", token)
    if colon_m:
        sym = markup.symbol(colon_m.group(1))
        rest = colon_m.group(2)
        if rest:
            return sym + _chem_token(rest, markup)
        return sym

    stoich_m = re.match(r"^([0-9]+(?:\.[0-9]+)?|[0-9]+/[0-9]+|\([0-9]+/[0-9]+\))([A-Z].*)$", token)
    if stoich_m:
        coeff = stoich_m.group(1)
        rest = stoich_m.group(2)
        return coeff + markup.thin_space + _chem_simple_formula(rest, markup)

    bond_m = re.match(r"^([^-=]+)([-=])([^-=]+)$", token)
    if bond_m and re.search(r"[A-Z]", bond_m.group(1)) and re.search(r"[A-Z]", bond_m.group(3)):
        left = _chem_simple_formula(bond_m.group(1), markup)
        bond = bond_m.group(2)
        right = _chem_simple_formula(bond_m.group(3), markup)
        return f"{left}{bond}{right}"

    italic_m = re.match(r"^\*([a-zA-Z])\*(.*)$", token)
    if italic_m:
        letter = italic_m.group(1)
        rest = italic_m.group(2)
        result = markup.em(letter)
        if rest:
            if rest.startswith(("-", "=")):
                result += rest[0]
                rest = rest[1:]
            if rest:
                result += _chem_simple_formula(rest, markup)
        return result

    if token == "x" or token == "n":
        return markup.em(token)

    return _chem_simple_formula(token, markup)


def _chem_simple_formula(token: str, markup: _ChemMarkup) -> str:
    charge_m = re.match(r"^(.*?)(?:\^(?:\{([^}]+)\}|([0-9]*[+-]|n[+-]?)))$", token)
    charge = None
    if charge_m:
        token = charge_m.group(1)
        charge = charge_m.group(2) or charge_m.group(3)

    if not charge:
        single_charge_m = re.match(r"^(.*[A-Za-z\])])([+-])$", token)
        if single_charge_m:
            token = single_charge_m.group(1)
            charge = single_charge_m.group(2)

    italic_sub_m = re.match(r"^(.+)_([a-z])$", token)
    if italic_sub_m:
        base = _chem_subscript_numbers(italic_sub_m.group(1), markup)
        result = base + markup.sub(markup.em(italic_sub_m.group(2)))
    else:
        result = _chem_subscript_numbers(token, markup)

    if charge is not None:
        charge_text = markup.escape(charge).replace("-", markup.minus)
        if re.match(r"^[a-z]", charge):
            charge_text = markup.em(charge_text[0]) + charge_text[1:]
        result += markup.sup(charge_text)

    return result


def _chem_subscript_numbers(text: str, markup: _ChemMarkup) -> str:
    # Text is escaped first; LaTeX's escapes end in `}` or a symbol, so no digit follows a letter
    return re.sub(
        r"(?<=[A-Za-z)\]])(\d+)",
        lambda m: markup.sub(m.group(1)),
        markup.escape(text),
    )


_INDEX_LETTERS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")


def fmt_index(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    case: str = "upper",
    index_algo: str = "repeat",
    pattern: str = "{x}",
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as index characters.

    With numeric values in a **gt** table, we can transform those to index values, usually based
    on letters. These characters can be derived from a specified locale and they are intended for
    ordering (often leaving out characters with diacritical marks). For example, the value `1` would
    map to `"A"`, `2` to `"B"`, and so on. When the value exceeds the number of characters in the
    index set, the algorithm set by `index_algo` determines how to proceed: with `"repeat"`,
    characters are repeated (e.g., 27 becomes `"AA"`, 28 becomes `"BB"`); with `"excel"`,
    Excel-style column naming is used (e.g., 27 becomes `"AA"`, 28 becomes `"AB"`).

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    case
        The case of the resulting index characters. Use `"upper"` (the default) for uppercase
        letters or `"lower"` for lowercase.
    index_algo
        The algorithm to use when values exceed the index character set size. `"repeat"` (the
        default) repeats characters (1→A, ..., 27→AA, 28→BB). `"excel"` uses Excel-style column
        naming (1→A, ..., 27→AA, 28→AB).
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by `{x}` and all other characters are interpreted as string literals.
    locale
        An optional locale ID. Currently reserved for future use; index characters default to the
        English A–Z set regardless of locale.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Let's use the `towny` dataset to create a table of the five smallest census subdivisions by
    population. The ranking column is formatted as index characters (A through E) and merged with
    the subdivision name.

    ```{python}
    import polars as pl
    from great_tables import GT, md, data

    towny_mini = (
        data.pl.towny
        .select("name", "census_div", "population_2021")
        .group_by("census_div")
        .agg(pl.col("population_2021").sum().alias("population"))
        .sort("population")
        .head(5)
        .with_row_index("ranking", offset=1)
        .select("ranking", "census_div", "population")
    )

    (
        GT(towny_mini)
        .fmt_integer(columns="population")
        .fmt_index(columns="ranking", pattern="{x}.")
        .cols_merge(columns=["ranking", "census_div"])
        .cols_align(align="left", columns="ranking")
        .cols_label(
            ranking=md("Census<br>Subdivision"),
            population=md("Population<br>in 2021"),
        )
        .tab_header(title=md("The Smallest<br>Census Subdivisions"))
        .tab_options(table_width="325px")
    )
    ```

    Using `index_algo="excel"` produces Excel-style column naming when values exceed 26. Here we
    show both algorithms side by side.

    ```{python}
    import polars as pl
    from great_tables import GT

    df = pl.DataFrame({
        "value": [1, 5, 13, 26, 27, 28, 52, 53, 100],
    })

    (
        GT(
            df.with_columns(
                repeat=pl.col("value"),
                excel=pl.col("value"),
            )
        )
        .fmt_index(columns="repeat", index_algo="repeat")
        .fmt_index(columns="excel", index_algo="excel")
        .cols_label(value="Value", repeat="Repeat", excel="Excel")
    )
    ```
    """
    if case not in ("upper", "lower"):
        raise ValueError(f"case must be 'upper' or 'lower', got {case!r}")
    if index_algo not in ("repeat", "excel"):
        raise ValueError(f"index_algo must be 'repeat' or 'excel', got {index_algo!r}")

    locale = _resolve_locale(self, locale=locale)

    pf_format = partial(
        fmt_index_context,
        data=self,
        case=case,
        index_algo=index_algo,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def _index_repeat(x: int, idx_set: list[str]) -> str:
    if x <= 0:
        return ""
    n = len(idx_set)
    reps = (x - 1) // n + 1
    char = idx_set[(x - 1) % n]
    return char * reps


def _index_excel(x: int, idx_set: list[str]) -> str:
    if x <= 0:
        return ""
    n = len(idx_set)
    result: list[str] = []
    while x > 0:
        remainder = (x - 1) % n
        result.append(idx_set[remainder])
        x = (x - 1) // n
    return "".join(reversed(result))


def fmt_index_context(
    x: float,
    data: GTSelf,
    case: str,
    index_algo: str,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    if not math.isfinite(x):
        return _format_nonfinite_value(x, force_sign=False, pattern=pattern, context=context)

    x_int = int(abs(_round_rhu(x, 0)))

    idx_set = _INDEX_LETTERS

    if index_algo == "excel":
        x_formatted = _index_excel(x_int, idx_set)
    else:
        x_formatted = _index_repeat(x_int, idx_set)

    if case == "lower":
        x_formatted = x_formatted.lower()

    if x_formatted:
        x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


# ==============================================================================
# fmt_url / fmt_email helpers
# ==============================================================================

_URL_DEFAULT_COLOR = "#008B8B"
_URL_DEFAULT_BUTTON_FILL = "#4682B4"


def _is_light_color(hex_color: str) -> bool:
    from ._data_color.base import _relative_luminance
    from ._data_color.utils import _hex_to_rgb

    rgb = _hex_to_rgb(hex_color=hex_color)
    lum = _relative_luminance(rgb=rgb)
    return lum > 0.85


def _normalize_color(color: str) -> str:
    from ._data_color.utils import _html_color

    return _html_color(colors=[color])[0]


def _build_link_html(
    href: str,
    label: str,
    color: str,
    show_underline: bool,
    as_button: bool,
    button_fill: str | None,
    button_width: str | None,
    button_outline: str | None,
    target: str | None,
    extra_attrs: str = "",
) -> str:
    styles: list[str] = [f"color:{color}"]

    if show_underline:
        styles.append("text-decoration:underline;text-underline-position:under")
    else:
        styles.append("text-decoration:none")

    styles.append("display:inline-block")

    if as_button:
        fill = button_fill or _URL_DEFAULT_BUTTON_FILL
        styles.append(f"background-color:{fill}")
        styles.append("padding:8px 12px")
        styles.append("border-radius:4px")

        if button_width is not None:
            styles.append(f"width:{button_width}")
            styles.append("text-align:center")

        if button_outline is not None:
            styles.append(f"outline:{button_outline}")
        elif _is_light_color(fill):
            styles.append("outline:2px solid #DFDFDF")
        else:
            styles.append("outline-style:none")

    style_str = ";".join(styles)

    target_attr = f' target="{target}"' if target else ""

    return (
        f'<span style="white-space:pre;">'
        f'<a href="{href}"{target_attr}{extra_attrs} style="{style_str}">'
        f"{label}</a></span>"
    )


def _build_link_latex(href: str, label: str) -> str:
    # `%`, `#` and `&` would otherwise start a comment, a macro parameter or a new cell;
    # hyperref drops the backslashes again when writing the link target
    href = re.sub(r"([%#&])", r"\\\1", href)

    return f"\\href{{{href}}}{{{_latex_escape(label)}}}"


def fmt_url(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    label: str | Callable[[str], str] | None = None,
    as_button: bool = False,
    color: str = "auto",
    show_underline: str | bool = "auto",
    button_fill: str = "auto",
    button_width: str | None = None,
    button_outline: str | None = None,
    target: str | None = "_blank",
) -> GTSelf:
    """
    Format values as URL links.

    With [`fmt_url()`](`great_tables.GT.fmt_url`), input URL strings in the table body are
    transformed into HTML anchor elements (`<a>` tags). The URLs can be displayed as-is, with a
    static label, or with a label generated by a function. The links can also be styled as buttons
    with customizable colors and dimensions.

    In LaTeX output, the links are written with the `href` command (so the **hyperref** package
    needs to be loaded) and the styling options only apply to HTML output.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    label
        An optional label to use for the link. If a string is provided, it will be used as the
        visible text for all links. If a callable is provided, it will be called with the URL string
        and should return the display label.
    as_button
        Should the link be styled as a button? By default this is `False`.
    color
        The color of the link text. The default `"auto"` uses `"#008B8B"` (dark cyan) for regular
        links and `"#FFFFFF"` (white) for buttons. Any CSS color name or hex value can be used.
    show_underline
        Should the link be underlined? The default `"auto"` uses `True` for regular links and
        `False` for buttons. Set explicitly to `True` or `False` to override.
    button_fill
        The background color for button-style links. The default `"auto"` uses `"#4682B4"` (steel
        blue). Only used when `as_button=True`.
    button_width
        The width of the button. Should be a CSS width string (e.g., `"150px"`). By default buttons
        size to their content.
    button_outline
        The CSS outline for the button (e.g., `"2px solid #ccc"`). By default, a light gray outline
        is automatically added when the button fill color is very light, and hidden otherwise.
    target
        The `target` attribute for the anchor element. Defaults to `"_blank"` to open links in a new
        tab. Set to `None` to open in the same tab.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Using a subset of the `towny` dataset, let's format the `website` column as URL links.

    ```{python}
    import polars as pl
    from great_tables import GT, md, data

    towny_top = (
        data.pl.towny
        .filter(pl.col("csd_type") == "city")
        .select("name", "website", "population_2021")
        .sort("population_2021", descending=True)
        .head(10)
    )

    (
        GT(towny_top)
        .tab_header(
            title=md("The 10 Largest Municipalities in `towny`"),
            subtitle="Population values taken from the 2021 census.",
        )
        .fmt_integer(columns="population_2021")
        .fmt_url(columns="website")
        .cols_label(
            name="Name",
            website="Site",
            population_2021="Population",
        )
    )
    ```

    We can use a static label and disable underlines for a cleaner look, merging the URL column into
    the name column.

    ```{python}
    (
        GT(towny_top)
        .tab_header(
            title=md("The 10 Largest Municipalities in `towny`"),
            subtitle="Population values taken from the 2021 census.",
        )
        .fmt_integer(columns="population_2021")
        .fmt_url(columns="website", label="site", show_underline=False)
        .cols_merge(columns=["name", "website"], pattern="{0} ({1})")
        .cols_label(name="Name", population_2021="Population")
    )
    ```

    Button-styled links can be created with `as_button=True`.

    ```{python}
    (
        GT(towny_top)
        .fmt_integer(columns="population_2021")
        .fmt_url(
            columns="website",
            label=lambda x: x.replace("https://", "").replace("www.", ""),
            as_button=True,
            button_fill="steelblue",
            button_width="150px",
        )
        .cols_label(
            name="Name",
            website="Website",
            population_2021="Population",
        )
    )
    ```
    """

    # Resolve color settings
    if color == "auto":
        resolved_color = "#FFFFFF" if as_button else _URL_DEFAULT_COLOR
    else:
        resolved_color = _normalize_color(color)

    resolved_underline = not as_button if show_underline == "auto" else bool(show_underline)

    resolved_fill: str | None = None
    if as_button:
        if button_fill == "auto":
            resolved_fill = _URL_DEFAULT_BUTTON_FILL
        else:
            resolved_fill = _normalize_color(button_fill)

            if color == "auto":
                from ._data_color.base import _ideal_fgnd_color

                resolved_color = _ideal_fgnd_color(bgnd_color=resolved_fill)

    def fmt_url_fn(x: str, context: str):
        if is_na(self._tbl_data, x):
            return x

        url = str(x).strip()

        # Handle Markdown-style links: [label](url)
        md_match = re.match(r"^\[(.+?)\]\((.+?)\)$", url)
        if md_match:
            display = md_match.group(1)
            href = md_match.group(2)
        else:
            href = url
            if label is None:
                display = url
            elif callable(label):
                display = label(url)
            else:
                display = label

        if context == "latex":
            return _build_link_latex(href=href, label=display)

        return _build_link_html(
            href=href,
            label=display,
            color=resolved_color,
            show_underline=resolved_underline,
            as_button=as_button,
            button_fill=resolved_fill,
            button_width=button_width,
            button_outline=button_outline,
            target=target,
        )

    return fmt_by_context(self, pf_format=fmt_url_fn, columns=columns, rows=rows)


def fmt_email(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    display_name: str | Callable[[str], str] | None = None,
    as_button: bool = False,
    color: str = "auto",
    show_underline: str | bool = "auto",
    button_fill: str = "auto",
    button_width: str | None = None,
    button_outline: str | None = None,
    target: str | None = "_blank",
) -> GTSelf:
    """
    Format values as email links.

    The [`fmt_email()`](`great_tables.GT.fmt_email`) method transforms email addresses in the table
    body into clickable `mailto:` links. Like [`fmt_url()`](`great_tables.GT.fmt_url`), the links
    can be styled as buttons or as plain underlined text, with customizable colors.

    In LaTeX output, the links are written with the `href` command (so the **hyperref** package
    needs to be loaded) and the styling options only apply to HTML output.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    display_name
        An optional display name to use instead of the raw email address. If a string is
        provided, it will be used as the visible text for all links. If a callable is provided, it
        will be called with the email address and should return the display text.
    as_button
        Should the link be styled as a button? By default this is `False`.
    color
        The color of the link text. The default `"auto"` uses `"#008B8B"` (dark cyan) for regular
        links and `"#FFFFFF"` (white) for buttons. Any CSS color name or hex value can be used.
    show_underline
        Should the link be underlined? The default `"auto"` uses `True` for regular links and
        `False` for buttons. Set explicitly to `True` or `False` to override.
    button_fill
        The background color for button-style links. The default `"auto"` uses `"#4682B4"` (steel
        blue). Only used when `as_button=True`.
    button_width
        The width of the button. Should be a CSS width string (e.g., `"150px"`). By default buttons
        size to their content.
    button_outline
        The CSS outline for the button (e.g., `"2px solid #ccc"`). By default, a light gray outline
        is automatically added when the button fill color is very light, and hidden otherwise.
    target
        The `target` attribute for the anchor element. Defaults to `"_blank"` to open links in a new
        tab. Set to `None` to open in the same tab.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Using a subset of the `peeps` dataset filtered to contacts in Australia, let's format the
    `email_addr` column as email links.

    ```{python}
    import polars as pl
    from great_tables import GT, md, data

    peeps_aus = (
        data.pl.peeps
        .filter(pl.col("country") == "AUS")
        .select(
            "name_given", "name_family", "address", "city",
            "state_prov", "postcode", "country", "email_addr",
        )
    )

    (
        GT(peeps_aus, rowname_col="name_family")
        .tab_header(title="Our Contacts in Australia")
        .fmt_email(columns="email_addr")
        .cols_label(
            name_given="First Name",
            address="Address",
            city="City",
            state_prov="State",
            postcode="Postcode",
            country="Country",
            email_addr="Email",
        )
    )
    ```

    We can use `display_name=` with a callable to show just the local part of the email address
    before the `@` sign.

    ```{python}
    (
        GT(peeps_aus, rowname_col="name_family")
        .tab_header(title="Our Contacts in Australia")
        .fmt_email(
            columns="email_addr",
            display_name=lambda x: x.split("@")[0],
            color="gray25",
        )
        .cols_label(
            name_given="First Name",
            address="Address",
            city="City",
            state_prov="State",
            postcode="Postcode",
            country="Country",
            email_addr="Email",
        )
    )
    ```

    Button-styled email links are also supported.

    ```{python}
    (
        GT(peeps_aus.head(5), rowname_col="name_family")
        .tab_header(title="Contact Us")
        .fmt_email(
            columns="email_addr",
            display_name="Send Email",
            as_button=True,
            button_fill="#228B22",
        )
        .cols_label(
            name_given="First Name",
            address="Address",
            city="City",
            state_prov="State",
            postcode="Postcode",
            country="Country",
            email_addr="Email",
        )
    )
    ```
    """

    # Resolve color settings (same logic as fmt_url)
    if color == "auto":
        resolved_color = "#FFFFFF" if as_button else _URL_DEFAULT_COLOR
    else:
        resolved_color = _normalize_color(color)

    resolved_underline = not as_button if show_underline == "auto" else bool(show_underline)

    resolved_fill: str | None = None
    if as_button:
        if button_fill == "auto":
            resolved_fill = _URL_DEFAULT_BUTTON_FILL
        else:
            resolved_fill = _normalize_color(button_fill)

            if color == "auto":
                from ._data_color.base import _ideal_fgnd_color

                resolved_color = _ideal_fgnd_color(bgnd_color=resolved_fill)

    def fmt_email_fn(x: str, context: str):
        if is_na(self._tbl_data, x):
            return x

        email = str(x).strip()

        if display_name is None:
            display = email
        elif callable(display_name):
            display = display_name(email)
        else:
            display = display_name

        if context == "latex":
            return _build_link_latex(href=f"mailto:{email}", label=display)

        extra_attrs = ""
        if target == "_blank":
            extra_attrs = ' rel="noopener noreferrer"'

        return _build_link_html(
            href=f"mailto:{email}",
            label=display,
            color=resolved_color,
            show_underline=resolved_underline,
            as_button=as_button,
            button_fill=resolved_fill,
            button_width=button_width,
            button_outline=button_outline,
            target=target,
            extra_attrs=extra_attrs,
        )

    return fmt_by_context(self, pf_format=fmt_email_fn, columns=columns, rows=rows)


def fmt_bytes(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    standard: str = "decimal",
    decimals: int = 1,
    n_sigfig: int | None = None,
    drop_trailing_zeros: bool = True,
    drop_trailing_dec_mark: bool = True,
    use_seps: bool = True,
    min_sep_threshold: int = 1,
    pattern: str = "{x}",
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign: bool = False,
    incl_space: bool = True,
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as bytes.

    With numeric values in a table, we can transform those to values of bytes with human readable
    units. The [`fmt_bytes()`](`great_tables.GT.fmt_bytes`) method allows for the formatting of byte
    sizes to either of two common representations: (1) with decimal units (powers of 1000, examples
    being `"kB"` and `"MB"`), and (2) with binary units (powers of 1024, examples being `"KiB"` and
    `"MiB"`). It is assumed the input numeric values represent the number of bytes and automatic
    truncation of values will occur. The numeric values will be scaled to be in the range of 1 to
    <1000 and then decorated with the correct unit symbol according to the standard chosen. For more
    control over the formatting of byte sizes, we can use the following options:

    - decimals: choice of the number of decimal places, option to drop trailing zeros, and a choice
    of the decimal symbol
    - digit grouping separators: options to enable/disable digit separators and provide a choice of
    separator symbol
    - pattern: option to use a text pattern for decoration of the formatted values
    - locale-based formatting: providing a locale ID will result in number formatting specific to
    the chosen locale

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    standard
        The form of expressing large byte sizes is divided between: (1) decimal units (powers of
        1000; e.g., `"kB"` and `"MB"`), and (2) binary units (powers of 1024; e.g., `"KiB"` and
        `"MiB"`). The default is to use decimal units with the `"decimal"` option. The alternative
        is to use binary units with the `"binary"` option.
    decimals
        This corresponds to the exact number of decimal places to use. A value such as `2.34` can,
        for example, be formatted with `0` decimal places and it would result in `"2"`. With `4`
        decimal places, the formatted value becomes `"2.3400"`. The trailing zeros can be removed
        with `drop_trailing_zeros=True`.
    drop_trailing_zeros
        A boolean value that allows for removal of trailing zeros (those redundant zeros after the
        decimal mark).
    drop_trailing_dec_mark
        A boolean value that determines whether decimal marks should always appear even if there are
        no decimal digits to display after formatting (e.g., `23` becomes `23.` if `False`). By
        default trailing decimal marks are not shown.
    use_seps
        The `use_seps` option allows for the use of digit group separators. The type of digit group
        separator is set by `sep_mark` and overridden if a locale ID is provided to `locale`. This
        setting is `True` by default.
    min_sep_threshold
        The minimum number of digits in the integer part of a number for digit grouping
        separators to be used. The default of `1` uses separators from 4-digit numbers onward
        (e.g., `1,000`), `2` starts at 5-digit numbers (`10,000`), and `3` starts at 6-digit
        numbers (`100,000`). When a locale is in effect (through `locale=` or a locale set in
        `GT()`), the locale's own minimum grouping digits value is used instead (it's `2` for
        locales like `"es"` and `"pl"`).
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    dec_mark
        The string to be used as the decimal mark. For example, using `dec_mark=","` with the value
        `0.152` would result in a formatted value of `"0,152"`). This argument is ignored if a
        `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    incl_space
        An option for whether to include a space between the value and the currency symbol. The
        default is to not introduce a space character.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).


    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). The use of a valid
    locale ID here means separator and decimal marks will be correct for the given locale. Should
    any values be provided in `sep_mark` or `dec_mark`, they will be overridden by the locale's
    preferred values.

    Note that a `locale` value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    Let's use a single column from the `exibble` dataset and create a new table. We'll format the
    `num` column to display as byte sizes in the decimal standard through use of the
    [`fmt_bytes()`](`great_tables.GT.fmt_bytes`) method.

    ```{python}
    from great_tables import GT, exibble

    (
        GT(exibble[["num"]])
        .fmt_bytes(columns="num", standard="decimal")
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=min_sep_threshold, locale=locale)
    dec_mark = _get_locale_dec_mark(default=dec_mark, locale=locale)

    # Stop if `n_sigfig` does not have a valid value
    if n_sigfig is not None:
        _validate_n_sigfig(n_sigfig=n_sigfig)

    # Get the `base` value and the `byte_units` list based on the `standard` value
    if standard == "decimal":
        # This is the 'decimal' standard (the default)
        base = 1000
        byte_units = ["B", "kB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]
    else:
        # This is the 'binary' standard
        base = 1024
        byte_units = ["B", "KiB", "MiB", "GiB", "TiB", "PiB", "EiB", "ZiB", "YiB"]

    pf_format = partial(
        fmt_bytes_context,
        data=self,
        base=base,
        byte_units=byte_units,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
        incl_space=incl_space,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_bytes_context(
    x: float,
    data: GTData,
    base: int,
    byte_units: list[str],
    decimals: int,
    n_sigfig: int | None,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    use_seps: bool,
    sep_mark: str,
    min_sep_threshold: int,
    dec_mark: str,
    force_sign: bool,
    incl_space: bool,
    pattern: str,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    if not math.isfinite(x):
        return _format_nonfinite_value(x, force_sign=force_sign, pattern=pattern, context=context)

    # Truncate all byte values by casting to an integer; this is done because bytes
    # are always whole numbers
    x = int(x)

    # Determine properties of the value
    is_negative = _has_negative_value(value=x)

    # Determine the power index for the value: the exponent of the largest power of `base` that
    # is at most the absolute value, plus 1 (the power index is 1-based, i.e., the first element
    # in the `byte_units` list is at index 0), and 1 for zero; the integers are compared exactly,
    # while `math.log()` can round up just below a power of the base (e.g.,
    # `math.log(10**15 - 1, 1000)` gives `5.0`)
    num_power_idx = 1
    while num_power_idx < len(byte_units) and abs(x) >= base**num_power_idx:
        num_power_idx += 1

    # If rounding the scaled value carries it up to `base` (e.g., 999,999 bytes
    # would give `1,000 kB`), use the next unit instead (`1 MB`)
    if num_power_idx < len(byte_units) and _rounds_up_to(
        _divide_by_power(x, base=base, power=num_power_idx - 1),
        threshold=base,
        decimals=decimals,
        n_sigfig=n_sigfig,
    ):
        num_power_idx += 1

    # The `units_str` is obtained by indexing the `byte_units` list with the `num_power_idx`
    # value; this is the string that will be affixed to the formatted value
    units_str = byte_units[num_power_idx - 1]

    # Scale `x` value by a defined `base` value, this is done by dividing by the
    # `base` value raised to the power index minus 1 (we subtract 1 because the
    # power index is 1-based); the division is exact, so the value is rounded only once,
    # when it's formatted
    x = _divide_by_power(x, base=base, power=num_power_idx - 1)

    # Format the value to decimal notation; this is done before the `byte_units` text
    # is affixed to the value
    x_formatted = _value_to_decimal_notation(
        value=x,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
    )

    # Create a `bytes_pattern` object for affixing the `units_str`, which is the
    # string that represents the byte units
    space_character = " " if incl_space else ""
    bytes_pattern = f"{{x}}{space_character}{units_str}"

    x_formatted = bytes_pattern.replace("{x}", x_formatted)

    # Implement minus sign replacement for `x_formatted`
    if is_negative:
        minus_mark = _context_minus_mark(context=context)
        x_formatted = _replace_minus(x_formatted, minus_mark=minus_mark)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


# Duration style type alias
DurationStyle: TypeAlias = Literal["narrow", "wide", "colon-sep", "iso"]

# Valid input/output units for durations
_DURATION_INPUT_UNITS = ("weeks", "days", "hours", "minutes", "seconds")
_DURATION_OUTPUT_UNITS = ("weeks", "days", "hours", "minutes", "seconds")

# Conversion factors to seconds
_SECONDS_CONVERSION = {
    "weeks": 604800,
    "days": 86400,
    "hours": 3600,
    "minutes": 60,
    "seconds": 1,
}

# Unit abbreviations for narrow style
_NARROW_UNITS = {
    "weeks": "w",
    "days": "d",
    "hours": "h",
    "minutes": "m",
    "seconds": "s",
}

# Unit labels for wide style (singular/plural)
_WIDE_UNITS = {
    "weeks": ("week", "weeks"),
    "days": ("day", "days"),
    "hours": ("hour", "hours"),
    "minutes": ("minute", "minutes"),
    "seconds": ("second", "seconds"),
}

# ISO 8601 duration unit letters
_ISO_UNITS = {
    "weeks": "W",
    "days": "D",
    "hours": "H",
    "minutes": "M",
    "seconds": "S",
}

# Mapping from output_units keys to CLDR duration unit names
_UNIT_TO_CLDR = {
    "weeks": "week",
    "days": "day",
    "hours": "hour",
    "minutes": "minute",
    "seconds": "second",
}

# Cache for duration locale data (loaded once)
_DURATIONS_DATA_CACHE: list[dict[str, str]] | None = None


def _get_duration_patterns(locale: str | None, style: str) -> dict[str, dict[str, str]] | None:
    """Get locale-specific duration unit patterns.

    Parameters
    ----------
    locale
        Locale identifier (e.g., "fr", "de", "en").
    style
        Either "narrow" or "wide".

    Returns
    -------
    A dict mapping unit names (weeks, days, hours, minutes, seconds) to a dict of
    plural form patterns (e.g., {"one": "{0} semaine", "other": "{0} semaines"}).
    Returns None if locale is "en" or None (use hardcoded defaults).
    """
    if locale is None or locale == "en":
        return None

    global _DURATIONS_DATA_CACHE
    if _DURATIONS_DATA_CACHE is None:
        from great_tables._locale import _get_durations_data

        _DURATIONS_DATA_CACHE = _get_durations_data()

    # Map "wide" -> "wide", "narrow" -> "narrow" in CSV type column
    cldr_type = style

    # Try exact locale match first, then base locale
    locale_candidates = [locale]
    if "-" in locale:
        locale_candidates.append(locale.split("-")[0])

    for loc_candidate in locale_candidates:
        for row in _DURATIONS_DATA_CACHE:
            if row["locale"] == loc_candidate and row["type"] == cldr_type:
                # Build the patterns dict
                patterns: dict[str, dict[str, str]] = {}
                for unit_key in ("weeks", "days", "hours", "minutes", "seconds"):
                    cldr_unit = _UNIT_TO_CLDR[unit_key]
                    unit_patterns: dict[str, str] = {}
                    for plural in ("zero", "one", "two", "few", "many", "other"):
                        col = f"{cldr_unit}_{plural}"
                        val = row.get(col, "")
                        if val:
                            unit_patterns[plural] = val
                    if unit_patterns:
                        patterns[unit_key] = unit_patterns
                if patterns:
                    return patterns

    return None


def _get_plural_form(value: int) -> str:
    """Determine the CLDR plural category for a numeric value.

    This implements basic plural rules. For most languages, "one" applies to
    the value 1 and "other" applies to everything else. Some languages have
    additional forms (zero, two, few, many) which are handled by checking
    if the pattern exists for the locale.
    """
    if value == 0:
        return "zero"
    elif value == 1:
        return "one"
    elif value == 2:
        return "two"
    else:
        return "other"


def _apply_duration_pattern(patterns: dict[str, str], value: int, formatted_value: str) -> str:
    """Apply a CLDR duration pattern with the correct plural form.

    Parameters
    ----------
    patterns
        Dict of plural form -> pattern string (e.g., {"one": "{0} jour", "other": "{0} jours"}).
    value
        The raw integer value (for plural selection).
    formatted_value
        The formatted value string (with separators applied).

    Returns
    -------
    The formatted duration part string.
    """
    plural = _get_plural_form(value)

    # Try the specific plural form, then fall back to "other"
    if plural in patterns:
        pattern = patterns[plural]
    elif (plural == "zero" and "other" in patterns) or (plural == "two" and "other" in patterns):
        pattern = patterns["other"]
    else:
        pattern = patterns.get("other", "{0}")

    return pattern.replace("{0}", formatted_value)


def fmt_duration(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    input_units: str | None = None,
    output_units: str | list[str] | None = None,
    duration_style: DurationStyle = "narrow",
    trim_zero_units: bool | str | list[str] = True,
    max_output_units: int | None = None,
    pattern: str = "{x}",
    use_seps: bool = True,
    sep_mark: str = ",",
    force_sign: bool = False,
    locale: str | None = None,
) -> GTSelf:
    """
    Format numeric or duration values as styled time duration strings.

    Format input values to time duration values whether those input values are numbers or of the
    `timedelta` class. We can specify which time units any numeric input values have (as weeks,
    days, hours, minutes, or seconds) and the output can be customized with a duration style
    (corresponding to narrow, wide, colon-separated, and ISO forms) and a choice of output units
    ranging from weeks to seconds.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    input_units
        If one or more selected columns contains numeric values (not `timedelta` values, which
        contain the duration units), a keyword must be provided for `input_units` for the values to
        be interpreted in terms of duration. The accepted units are: `"seconds"`, `"minutes"`,
        `"hours"`, `"days"`, and `"weeks"`. This is required for numeric columns and ignored for
        `timedelta` columns.
    output_units
        Controls the output time units. The default (`None`) means that output units will be
        automatically chosen based on the input duration value. To control which time units are to
        be considered for output (before trimming with `trim_zero_units=`) we can specify a list of
        one or more of the following keywords: `"weeks"`, `"days"`, `"hours"`, `"minutes"`, or
        `"seconds"`.
    duration_style
        A choice of four formatting styles for the output duration values. With `"narrow"` (the
        default style), duration values will be formatted with single-letter time-part units (e.g.,
        1.35 days will be styled as `"1d 8h 24m"`). With `"wide"`, this example value will be
        expanded to `"1 day 8 hours 24 minutes"` after formatting. The `"colon-sep"` style will put
        days, hours, minutes, and seconds in the `"([D]/)[HH]:[MM]:[SS]"` format. The `"iso"` style
        will produce a value that conforms to the ISO 8601 rules for duration values (e.g., 1.35
        days will become `"P1DT8H24M"`).
    trim_zero_units
        Provides methods to remove output time units that have zero values. By default this is
        `True` and duration values that might otherwise be formatted as `"0w 1d 0h 4m 19s"` with
        `trim_zero_units=False` are instead displayed as `"1d 4m 19s"`. Aside from using
        `True`/`False` we could provide a keyword or a list of keywords for more precise control.
        These keywords are: (1) `"leading"`, to omit all leading zero-value time units (e.g.,
        `"0w 1d"` -> `"1d"`), (2) `"trailing"`, to omit all trailing zero-value time units (e.g.,
        `"3d 5h 0s"` -> `"3d 5h"`), and (3) `"internal"`, which removes all internal zero-value
        time units (e.g., `"5d 0h 33m"` -> `"5d 33m"`). With `duration_style="colon-sep"`, only
        `"leading"` has an effect (omitting zero hours, as in `"02:05"`).
    max_output_units
        If `output_units` is `None`, where the output time units are unspecified and left to be
        handled automatically, a numeric value provided for `max_output_units=` will be taken as the
        maximum number of time units to display in all output time duration values. By default, this
        is `None` and all possible time units will be displayed. This option has no effect when
        `duration_style="colon-sep"` (only `output_units` can be used to customize that type of
        duration output).
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    use_seps
        The `use_seps` option allows for the use of digit group separators. The type of digit group
        separator is set by `sep_mark` and overridden if a locale ID is provided to `locale`. This
        setting is `True` by default.
    sep_mark
        The string to use as a separator between groups of digits. For example, using `sep_mark=","`
        with a value of `1000` would result in a formatted value of `"1,000"`. This argument is
        ignored if a `locale` is supplied (i.e., is not `None`).
    force_sign
        Should the positive sign be shown for positive values (effectively showing a sign for all
        values except zero)? If so, use `True` for this option. The default is `False`, where only
        negative numbers will display a minus sign.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Output units for the colon-separated duration style
    ---------------------------------------------------
    The colon-separated duration style (enabled when `duration_style="colon-sep"`) is essentially a
    clock-based output format which uses the display logic of chronograph watch functionality. It
    will, by default, display duration values in the `(D/)HH:MM:SS` format. Any duration values
    greater than or equal to 24 hours will have the number of days prepended with an adjoining slash
    mark. While this output format is versatile, it can be changed somewhat with the `output_units=`
    option. The following combinations of output units are permitted:

    - `["minutes", "seconds"]` -> `MM:SS`
    - `["hours", "minutes"]` -> `HH:MM`
    - `["hours", "minutes", "seconds"]` -> `HH:MM:SS`
    - `["days", "hours", "minutes"]` -> `(D/)HH:MM`

    Any other specialized combinations will result in the default set being used, which is
    `["days", "hours", "minutes", "seconds"]`. The largest unit carries any larger ones that
    aren't shown, so with `["hours", "minutes", "seconds"]` a duration of 1 day, 8 hours, and 24
    minutes is displayed as `32:24:00`.

    Compatibility of formatting function with data values
    -----------------------------------------------------
    [`fmt_duration()`](`great_tables.GT.fmt_duration`) is compatible with body cells that are of
    `int`, `float`, or `datetime.timedelta` types. Any other types of body cells are ignored during
    formatting.

    Examples
    --------
    Let's create a table with duration values in seconds and format them using the default narrow
    style. This produces compact output with single-letter unit abbreviations, ideal for
    space-constrained displays.

    ```{python}
    import pandas as pd
    from great_tables import GT

    df = pd.DataFrame({"duration_s": [3661, 86400, 172800, 60, 0]})

    (
        GT(df)
        .fmt_duration(columns="duration_s", input_units="seconds")
    )
    ```

    Notice that zero-valued time units are automatically trimmed from the output, keeping the
    display clean. A value of `86400` seconds (exactly 1 day) simply shows `"1d"` rather than
    `"0w 1d 0h 0m 0s"`.

    For reporting contexts where readability is more important than compactness, the wide style
    spells out the full unit names with proper singular/plural forms.

    ```{python}
    df = pd.DataFrame({"hours": [1.5, 24.0, 0.5, 100.75]})

    (
        GT(df)
        .fmt_duration(columns="hours", input_units="hours", duration_style="wide")
    )
    ```

    The colon-separated style is useful for timing data, race results, or any context where a
    clock-like display is expected. Days are shown with a slash prefix when the duration is 24 hours
    or more.

    ```{python}
    df = pd.DataFrame({
        "event": ["Marathon", "Half Marathon", "10K", "Mile"],
        "winning_time_s": [7377, 3542, 1620, 233],
    })

    (
        GT(df)
        .fmt_duration(
            columns="winning_time_s",
            input_units="seconds",
            duration_style="colon-sep",
            output_units=["hours", "minutes", "seconds"],
        )
    )
    ```

    The output is zero-padded in the familiar `HH:MM:SS` format. By specifying `output_units` we
    control exactly which components appear in the colon-separated output.

    When working with `timedelta` columns (common in Pandas when computing differences between
    timestamps), [`fmt_duration()`](`great_tables.GT.fmt_duration`) automatically detects the
    units—no `input_units` argument is needed.

    ```{python}
    from datetime import datetime

    events = pd.DataFrame({
        "task": ["Build", "Test suite", "Deploy", "Full pipeline"],
        "elapsed": [
            datetime(2024, 1, 1, 0, 12, 45) - datetime(2024, 1, 1, 0, 0, 0),
            datetime(2024, 1, 1, 1, 5, 30) - datetime(2024, 1, 1, 0, 0, 0),
            datetime(2024, 1, 1, 0, 3, 15) - datetime(2024, 1, 1, 0, 0, 0),
            datetime(2024, 1, 1, 1, 21, 30) - datetime(2024, 1, 1, 0, 0, 0),
        ],
    })

    (
        GT(events, rowname_col="task")
        .fmt_duration(columns="elapsed", duration_style="narrow")
    )
    ```

    Polars DataFrames work the same way. Here we format numeric duration values using the ISO 8601
    duration style, which is useful for machine-readable output or standards-compliant reporting.

    ```{python}
    import polars as pl
    from great_tables import GT

    df = pl.DataFrame({"activity": ["Flight", "Layover", "Drive"], "seconds": [14400, 5400, 1830]})

    (
        GT(df)
        .fmt_duration(columns="seconds", input_units="seconds", duration_style="iso")
    )
    ```

    Polars also has native `Duration` dtype columns (created via temporal arithmetic or
    `timedelta` values). These are handled automatically without needing to specify `input_units`.

    ```{python}
    from datetime import timedelta

    df = pl.DataFrame({
        "segment": ["Warm-up", "Main set", "Cool-down"],
        "duration": [timedelta(minutes=10), timedelta(minutes=45, seconds=30), timedelta(minutes=5)],
    })

    (
        GT(df)
        .fmt_duration(columns="duration", duration_style="wide")
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Use locale-based marks if a locale ID is provided
    sep_mark = _get_locale_sep_mark(default=sep_mark, use_seps=use_seps, locale=locale)
    min_sep_threshold = _get_locale_min_sep_threshold(default=1, locale=locale)

    # Validate input_units
    if input_units is not None and input_units not in _DURATION_INPUT_UNITS:
        raise ValueError(
            f"`input_units` must be one of {_DURATION_INPUT_UNITS}, got '{input_units}'."
        )

    # Validate duration_style
    if duration_style not in ("narrow", "wide", "colon-sep", "iso"):
        raise ValueError(
            f"`duration_style` must be one of 'narrow', 'wide', 'colon-sep', or 'iso', "
            f"got '{duration_style}'."
        )

    # Resolve output_units
    if output_units is None:
        resolved_output_units = list(_DURATION_OUTPUT_UNITS)
    elif isinstance(output_units, str):
        resolved_output_units = [output_units]
    else:
        resolved_output_units = list(output_units)

    # Validate output_units entries
    for unit in resolved_output_units:
        if unit not in _DURATION_OUTPUT_UNITS:
            raise ValueError(
                f"Each entry in `output_units` must be one of {_DURATION_OUTPUT_UNITS}, "
                f"got '{unit}'."
            )

    # Validate max_output_units before the colon-sep and ISO styles set it aside
    if max_output_units is not None and (
        not isinstance(max_output_units, int) or max_output_units < 1
    ):
        raise ValueError("`max_output_units` must be an integer >= 1 or None.")

    # Resolve trim_zero_units to a list of keywords (also before the style overrides)
    if isinstance(trim_zero_units, str):
        trim_zero_units = [trim_zero_units]
    if isinstance(trim_zero_units, bool):
        resolved_trim = ["leading", "trailing", "internal"] if trim_zero_units else []
    elif isinstance(trim_zero_units, list):
        for kw in trim_zero_units:
            if kw not in ("leading", "trailing", "internal"):
                raise ValueError(
                    f"Each entry in `trim_zero_units` must be one of 'leading', 'trailing', "
                    f"or 'internal', got '{kw}'."
                )
        resolved_trim = trim_zero_units
    else:
        raise ValueError(
            "`trim_zero_units` must be a bool, a keyword, or a list of keywords "
            "('leading', 'trailing', 'internal')."
        )

    # Sort output_units from largest to smallest
    unit_order = list(_DURATION_OUTPUT_UNITS)
    resolved_output_units = sorted(resolved_output_units, key=lambda u: unit_order.index(u))

    # Handle colon-sep params
    colon_sep_output_units: list[str] | None = None
    colon_sep_trim_leading: bool = False

    if duration_style == "colon-sep":
        # Check for valid colon-sep output unit combinations
        valid_colon_combos = [
            ["minutes", "seconds"],
            ["hours", "minutes"],
            ["hours", "minutes", "seconds"],
            ["days", "hours", "minutes"],
        ]
        if resolved_output_units in valid_colon_combos:
            colon_sep_output_units = resolved_output_units
        else:
            colon_sep_output_units = ["days", "hours", "minutes", "seconds"]

        # Split values into the shown units only, so that the largest one carries the rest
        # (e.g., 1 day 8 hours is `32:00:00` as `HH:MM:SS`, not `08:00:00`)
        resolved_output_units = colon_sep_output_units

        # Every colon-sep field is always shown, so dropping time parts would only zero them out
        max_output_units = None

        # Only leading zero hours can be trimmed in the colon-sep style
        colon_sep_trim_leading = resolved_trim == ["leading"]
        resolved_trim = []

    if duration_style == "iso":
        resolved_output_units = ["days", "hours", "minutes", "seconds"]
        max_output_units = None
        # Zero-valued units are left out everywhere, giving the minimal form (`P7DT1M1S` rather
        # than R gt's `P7DT0H1M1S`); a zero duration keeps its smallest unit (`PT0S`)
        resolved_trim = ["leading", "trailing", "internal"]

    pf_format = partial(
        fmt_duration_context,
        data=self,
        input_units=input_units,
        output_units=resolved_output_units,
        duration_style=duration_style,
        trim_zero_units=resolved_trim,
        max_output_units=max_output_units,
        colon_sep_output_units=colon_sep_output_units,
        colon_sep_trim_leading=colon_sep_trim_leading,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        force_sign=force_sign,
        pattern=pattern,
        locale=locale,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_duration_context(
    x: float | None,
    data: GTData,
    input_units: str | None,
    output_units: list[str],
    duration_style: str,
    trim_zero_units: list[str],
    max_output_units: int | None,
    colon_sep_output_units: list[str] | None,
    colon_sep_trim_leading: bool,
    sep_mark: str,
    min_sep_threshold: int,
    force_sign: bool,
    pattern: str,
    locale: str | None,
    context: str,
) -> str:
    """Format a single value as a duration string."""

    if is_na(data._tbl_data, x):
        return x

    import numbers
    from datetime import timedelta

    # Handle timedelta input
    if isinstance(x, timedelta):
        # Convert timedelta to total seconds
        x_seconds = x.total_seconds()
    elif isinstance(x, numbers.Real):
        if input_units is None:
            raise ValueError(
                "`input_units` must be supplied when formatting numeric columns as durations. "
                "Use one of 'seconds', 'minutes', 'hours', 'days', or 'weeks'."
            )
        x_seconds = float(x) * _SECONDS_CONVERSION[input_units]
    else:
        return str(x)

    # An infinite (or NaN) duration can't be split into time parts
    if not math.isfinite(x_seconds):
        return _format_nonfinite_value(
            x_seconds, force_sign=force_sign, pattern=pattern, context=context
        )

    # Determine sign
    is_negative = x_seconds < 0
    x_seconds_abs = abs(x_seconds)

    # Decompose into time parts
    time_parts: list[tuple[str, int]] = []
    remainder = x_seconds_abs

    for unit in output_units:
        factor = _SECONDS_CONVERSION[unit]
        value = int(remainder // factor)
        remainder = remainder % factor
        time_parts.append((unit, value))

    # Apply trim_zero_units
    if trim_zero_units:
        time_parts = _trim_duration_parts(time_parts, trim_zero_units)

    # Ensure at least one unit remains (the smallest)
    if not time_parts:
        time_parts = [(output_units[-1], 0)]

    # If all values are zero but there was a remainder (value smaller than smallest unit)
    all_zero = all(v == 0 for _, v in time_parts)
    has_sub_unit_remainder = remainder > 0 and all_zero

    # Apply max_output_units
    if max_output_units is not None and len(time_parts) > max_output_units:
        time_parts = time_parts[:max_output_units]

    # Format based on style
    if duration_style == "colon-sep":
        x_formatted = _format_duration_colon_sep(
            time_parts=time_parts,
            output_units=output_units,
            colon_sep_output_units=colon_sep_output_units,
            colon_sep_trim_leading=colon_sep_trim_leading,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
        )
    elif duration_style == "iso":
        x_formatted = _format_duration_iso(time_parts=time_parts)
    elif duration_style == "narrow":
        x_formatted = _format_duration_narrow(
            time_parts=time_parts,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
            has_sub_unit_remainder=has_sub_unit_remainder,
            locale=locale,
        )
    elif duration_style == "wide":
        x_formatted = _format_duration_wide(
            time_parts=time_parts,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
            has_sub_unit_remainder=has_sub_unit_remainder,
            locale=locale,
        )
    else:
        x_formatted = _format_duration_narrow(
            time_parts=time_parts,
            sep_mark=sep_mark,
            min_sep_threshold=min_sep_threshold,
            has_sub_unit_remainder=has_sub_unit_remainder,
            locale=locale,
        )

    # Escape the `<` of values below the smallest output unit (e.g., `<1s`) for HTML and LaTeX
    if context == "html":
        x_formatted = _html_escape(x_formatted)
    elif context == "latex":
        x_formatted = _latex_escape(x_formatted)

    # A duration shown as zero in the colon and ISO styles (e.g., `00:00:00` for `-0.4` seconds)
    # gets no sign, as with numbers that round to zero; the narrow and wide styles show such a
    # duration as `<1s`, which keeps its sign
    if duration_style in ("colon-sep", "iso") and all(value == 0 for _, value in time_parts):
        is_negative = False
        x_seconds_abs = 0

    # Apply sign; the ISO style is machine-readable, so it always uses an ASCII hyphen (ISO 8601
    # parsers don't accept a typographic minus)
    if is_negative:
        minus_mark = "-" if duration_style == "iso" else _context_minus_mark(context=context)
        x_formatted = minus_mark + x_formatted

    if force_sign and not is_negative and x_seconds_abs > 0:
        x_formatted = "+" + x_formatted

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def _trim_duration_parts(
    time_parts: list[tuple[str, int]], trim_keywords: list[str]
) -> list[tuple[str, int]]:
    """Remove zero-valued time parts based on trim keywords."""

    if not time_parts:
        return time_parts

    # Find indices of non-zero parts
    non_zero_indices = [i for i, (_, v) in enumerate(time_parts) if v != 0]

    if not non_zero_indices:
        # All zeros - keep only the last part
        return [time_parts[-1]]

    first_non_zero = non_zero_indices[0]
    last_non_zero = non_zero_indices[-1]

    remove_indices: set[int] = set()

    if "leading" in trim_keywords:
        for i in range(first_non_zero):
            remove_indices.add(i)

    if "trailing" in trim_keywords:
        for i in range(last_non_zero + 1, len(time_parts)):
            remove_indices.add(i)

    if "internal" in trim_keywords:
        for i in range(first_non_zero, last_non_zero + 1):
            if time_parts[i][1] == 0:
                remove_indices.add(i)

    result = [part for i, part in enumerate(time_parts) if i not in remove_indices]
    return result


def _format_number_for_duration(value: int, sep_mark: str, min_sep_threshold: int = 1) -> str:
    """Format an integer with optional separator marks."""
    # Grouping starts at `min_sep_threshold + 3` digits (four with the default of `1`)
    if sep_mark and value >= 10 ** (min_sep_threshold + 2):
        # Apply thousands separator
        s = str(value)
        groups = []
        while s:
            groups.append(s[-3:])
            s = s[:-3]
        return sep_mark.join(reversed(groups))
    return str(value)


def _format_duration_narrow(
    time_parts: list[tuple[str, int]],
    sep_mark: str,
    min_sep_threshold: int,
    has_sub_unit_remainder: bool,
    locale: str | None = None,
) -> str:
    """Format duration in narrow style (e.g., '1d 8h 24m')."""
    locale_patterns = _get_duration_patterns(locale, "narrow")

    parts = []
    for unit, value in time_parts:
        formatted_value = _format_number_for_duration(value, sep_mark, min_sep_threshold)
        if locale_patterns and unit in locale_patterns:
            parts.append(_apply_duration_pattern(locale_patterns[unit], value, formatted_value))
        else:
            abbrev = _NARROW_UNITS[unit]
            parts.append(f"{formatted_value}{abbrev}")

    result = " ".join(parts)

    if has_sub_unit_remainder and len(time_parts) == 1 and time_parts[0][1] == 0:
        # Value is smaller than the smallest output unit
        unit_key = time_parts[0][0]
        if locale_patterns and unit_key in locale_patterns:
            result = _apply_duration_pattern(locale_patterns[unit_key], 1, "<1")
        else:
            abbrev = _NARROW_UNITS[unit_key]
            result = f"<1{abbrev}"

    return result


def _format_duration_wide(
    time_parts: list[tuple[str, int]],
    sep_mark: str,
    min_sep_threshold: int,
    has_sub_unit_remainder: bool,
    locale: str | None = None,
) -> str:
    """Format duration in wide style (e.g., '1 day 8 hours 24 minutes')."""
    locale_patterns = _get_duration_patterns(locale, "wide")

    parts = []
    for unit, value in time_parts:
        formatted_value = _format_number_for_duration(value, sep_mark, min_sep_threshold)
        if locale_patterns and unit in locale_patterns:
            parts.append(_apply_duration_pattern(locale_patterns[unit], value, formatted_value))
        else:
            singular, plural = _WIDE_UNITS[unit]
            label = singular if value == 1 else plural
            parts.append(f"{formatted_value} {label}")

    result = " ".join(parts)

    if has_sub_unit_remainder and len(time_parts) == 1 and time_parts[0][1] == 0:
        # Value is smaller than the smallest output unit
        unit_key = time_parts[0][0]
        if locale_patterns and unit_key in locale_patterns:
            result = _apply_duration_pattern(locale_patterns[unit_key], 1, "<1")
        else:
            singular, plural = _WIDE_UNITS[unit_key]
            result = f"<1 {singular}"

    return result


def _format_duration_iso(time_parts: list[tuple[str, int]]) -> str:
    """Format duration in ISO 8601 style (e.g., 'P1DT8H24M')."""
    date_parts = []
    time_parts_iso = []

    for unit, value in time_parts:
        letter = _ISO_UNITS[unit]
        if unit in ("weeks", "days"):
            date_parts.append(f"{value}{letter}")
        else:
            time_parts_iso.append(f"{value}{letter}")

    result = "P"
    result += "".join(date_parts)
    if time_parts_iso:
        # The T designator must precede any time parts (`PT1M` is one minute while `P1M` would
        # be one month) and is left out when there are no time parts
        result += "T"
        result += "".join(time_parts_iso)

    return result


def _format_duration_colon_sep(
    time_parts: list[tuple[str, int]],
    output_units: list[str],
    colon_sep_output_units: list[str] | None,
    colon_sep_trim_leading: bool,
    sep_mark: str,
    min_sep_threshold: int = 1,
) -> str:
    """Format duration in colon-separated style (e.g., '1/08:24:00')."""

    if colon_sep_output_units is None:
        colon_sep_output_units = ["days", "hours", "minutes", "seconds"]

    # Build a dict from the decomposed time_parts
    parts_dict = dict(time_parts)

    # Ensure all colon_sep_output_units are present
    for unit in colon_sep_output_units:
        if unit not in parts_dict:
            parts_dict[unit] = 0

    # Filter to only the colon_sep_output_units
    filtered_parts = [(unit, parts_dict.get(unit, 0)) for unit in colon_sep_output_units]

    # Handle days removal when zero
    has_days = "days" in colon_sep_output_units
    days_value = parts_dict.get("days", 0)

    if has_days and days_value == 0:
        filtered_parts = [(u, v) for u, v in filtered_parts if u != "days"]
        has_days = False

    # Handle leading trim for colon-sep
    if colon_sep_trim_leading:
        # Remove leading zero hours if present
        hms_units = [u for u, _ in filtered_parts if u in ("hours", "minutes", "seconds")]
        if hms_units and hms_units[0] == "hours":
            hours_val = parts_dict.get("hours", 0)
            if hours_val == 0 and not has_days:
                filtered_parts = [(u, v) for u, v in filtered_parts if u != "hours"]

    # Format: days get slash separator, rest get colon with zero-padding
    day_part = ""
    hms_parts = []

    for unit, value in filtered_parts:
        if unit == "days":
            day_part = _format_number_for_duration(value, sep_mark, min_sep_threshold) + "/"
        else:
            # Zero-pad hours, minutes, seconds to 2 digits; the largest field can be longer since
            # it carries any larger units that aren't shown (e.g., `1944:00` as `MM:SS`)
            hms_parts.append(f"{value:02d}")

    return day_part + ":".join(hms_parts)


def fmt_date(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    date_style: DateStyle = "iso",
    pattern: str = "{x}",
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as dates.

    Format input values to date values using one of 41 preset date styles. Input can be in the form
    of `date` type or as a ISO-8601 string (in the form of `YYYY-MM-DD HH:MM:SS` or `YYYY-MM-DD`).

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    date_style
        The date style to use. By default this is the short name `"iso"` which corresponds to
        ISO 8601 date formatting. There are 41 date styles in total.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).

    Formatting with the `date_style=` argument
    -----------------------------------------
    We need to supply a preset date style to the `date_style=` argument. The date styles are
    numerous and can handle localization to any supported locale. A large segment of date styles
    are termed flexible date formats and this means that their output will adapt to any `locale=`
    provided: the order of the fields, the punctuation, and even which fields are abbreviated
    follow the locale's conventions (e.g., `"yMMMd"` is `"Feb 29, 2000"` in English and
    `"29. Feb. 2000"` in German). That feature makes the flexible date formats a better option for
    locales other than `"en"` (the default locale).

    The following table provides a listing of all date styles and their output values
    (corresponding to an input date of `2000-02-29`).

    |    | Date Style             | Output                         | Notes    |
    |----|------------------------|--------------------------------|----------|
    | 1  | `"iso"`                | `"2000-02-29"`                 | ISO 8601 |
    | 2  | `"wday_month_day_year"`| `"Tuesday, February 29, 2000"` |          |
    | 3  | `"wd_m_day_year"`      | `"Tue, Feb 29, 2000"`          |          |
    | 4  | `"wday_day_month_year"`| `"Tuesday 29 February 2000"`   |          |
    | 5  | `"month_day_year"`     | `"February 29, 2000"`          |          |
    | 6  | `"m_day_year"`         | `"Feb 29, 2000"`               |          |
    | 7  | `"day_m_year"`         | `"29 Feb 2000"`                |          |
    | 8  | `"day_month_year"`     | `"29 February 2000"`           |          |
    | 9  | `"day_month"`          | `"29 February"`                |          |
    | 10 | `"day_m"`              | `"29 Feb"`                     |          |
    | 11 | `"year"`               | `"2000"`                       |          |
    | 12 | `"month"`              | `"February"`                   |          |
    | 13 | `"day"`                | `"29"`                         |          |
    | 14 | `"year.mn.day"`        | `"2000/02/29"`                 |          |
    | 15 | `"y.mn.day"`           | `"00/02/29"`                   |          |
    | 16 | `"year_week"`          | `"2000-W09"`                   | ISO 8601 |
    | 17 | `"year_quarter"`       | `"2000-Q1"`                    |          |
    | 18 | `"yMd"`                | `"2/29/2000"`                  | flexible |
    | 19 | `"yMEd"`               | `"Tue, 2/29/2000"`             | flexible |
    | 20 | `"yMMM"`               | `"Feb 2000"`                   | flexible |
    | 21 | `"yMMMM"`              | `"February 2000"`              | flexible |
    | 22 | `"yMMMd"`              | `"Feb 29, 2000"`               | flexible |
    | 23 | `"yMMMEd"`             | `"Tue, Feb 29, 2000"`          | flexible |
    | 24 | `"GyMd"`               | `"2/29/2000 AD"`               | flexible |
    | 25 | `"GyMMMd"`             | `"Feb 29, 2000 AD"`            | flexible |
    | 26 | `"GyMMMEd"`            | `"Tue, Feb 29, 2000 AD"`       | flexible |
    | 27 | `"yM"`                 | `"2/2000"`                     | flexible |
    | 28 | `"Md"`                 | `"2/29"`                       | flexible |
    | 29 | `"MEd"`                | `"Tue, 2/29"`                  | flexible |
    | 30 | `"MMMd"`               | `"Feb 29"`                     | flexible |
    | 31 | `"MMMEd"`              | `"Tue, Feb 29"`                | flexible |
    | 32 | `"MMMMd"`              | `"February 29"`                | flexible |
    | 33 | `"GyMMM"`              | `"Feb 2000 AD"`                | flexible |
    | 34 | `"yQQQ"`               | `"Q1 2000"`                    | flexible |
    | 35 | `"yQQQQ"`              | `"1st quarter 2000"`           | flexible |
    | 36 | `"Gy"`                 | `"2000 AD"`                    | flexible |
    | 37 | `"y"`                  | `"2000"`                       | flexible |
    | 38 | `"M"`                  | `"2"`                          | flexible |
    | 39 | `"MMM"`                | `"Feb"`                        | flexible |
    | 40 | `"d"`                  | `"29"`                         | flexible |
    | 41 | `"Ed"`                 | `"29 Tue"`                     | flexible |

    The `"year_week"` style gives the ISO 8601 week date in every locale: weeks start on Monday,
    week 1 is the week containing the first Thursday of the year, and the year shown is the one the
    week belongs to (so `2024-12-30` is `"2025-W01"`).

    The names of the flexible date styles are CLDR skeletons, where each letter stands for a field:
    `G` is the era, `y` the year, `Q` the quarter, `M` the month, `d` the day of the month, and `E`
    the day of the week. A longer run of `Q`, `M`, or `E` gives a longer form of that field.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). Note that a `locale`
    value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    Let's use the `exibble` dataset to create a simple, two-column table (keeping only the `date`
    and `time` columns). With the [`fmt_date()`](`great_tables.GT.fmt_date`) method, we'll format
    the `date` column to display dates formatted with the `"month_day_year"` date style.

    ```{python}
    from great_tables import GT, exibble

    exibble_mini = exibble[["date", "time"]]

    (
        GT(exibble_mini)
        .fmt_date(columns="date", date_style="month_day_year")
    )
    ```

    A flexible date style adapts to the locale. Here, the `"yMMMEd"` style is used to format the
    dates for a table in German.

    ```{python}
    (
        GT(exibble_mini, locale="de")
        .fmt_date(columns="date", date_style="yMMMEd")
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Get the date format string based on the `date_style` value
    date_format_str = _get_date_format(date_style=date_style, locale=locale)

    pf_format = partial(
        fmt_date_context,
        data=self,
        date_format_str=date_format_str,
        pattern=pattern,
        locale=locale,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_date_context(
    x: Any,
    data: GTData,
    date_format_str: str,
    pattern: str,
    locale: str | None,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # If `x` is a string, we assume it is an ISO date string and convert it to a date object
    if isinstance(x, str):
        # Convert the ISO date string to a date object
        x = _iso_str_to_date(x)

    else:
        # Stop if `x` is not a valid date object
        _validate_date_obj(x=x)

    # Format the date object to a string using Babel's `format_date()` function
    x_formatted = format_date(
        x, format=_resolve_iso_week(date_format_str, x), locale=_get_babel_locale(locale)
    )

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_time(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    time_style: TimeStyle = "iso",
    pattern: str = "{x}",
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as times.

    Format input values to time values using one of 25 preset time styles. Input can be in the form
    of `time` values, or strings in the ISO 8601 forms of `HH:MM:SS` or `YYYY-MM-DD HH:MM:SS`.
    For `datetime` values (and datetime strings), the time part is formatted. Dates without a time
    (e.g., `"2024-01-05"`) raise an error; use [`fmt_date()`](`great_tables.GT.fmt_date`) for
    those.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    time_style
        The time style to use. By default this is the short name `"iso"` which corresponds to how
        times are formatted within ISO 8601 datetime values. There are 25 time styles in total.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).

    Formatting with the `time_style=` argument
    -----------------------------------------
    We need to supply a preset time style to the `time_style=` argument. The time styles are
    numerous and can handle localization to any supported locale. Many of the time styles are
    termed flexible time formats and this means that their output will adapt to any `locale=`
    provided (e.g., `"hm"` is `"2:35 PM"` in English and `"午後2:35"` in Japanese). That feature
    makes the flexible time formats a better option for locales other than `"en"` (the default
    locale).

    The following table provides a listing of all time styles and their output values
    (corresponding to an input of `2000-02-29 14:35:00`). It is noted which of these represent 12-
    or 24-hour time.

    |    | Time Style    | Output                            | Notes         |
    |----|---------------|-----------------------------------|---------------|
    | 1  | `"iso"`       | `"14:35:00"`                      | ISO 8601, 24h |
    | 2  | `"iso-short"` | `"14:35"`                         | ISO 8601, 24h |
    | 3  | `"h_m_s_p"`   | `"2:35:00 PM"`                    | 12h           |
    | 4  | `"h_m_p"`     | `"2:35 PM"`                       | 12h           |
    | 5  | `"h_p"`       | `"2 PM"`                          | 12h           |
    | 6  | `"Hms"`       | `"14:35:00"`                      | flexible, 24h |
    | 7  | `"Hm"`        | `"14:35"`                         | flexible, 24h |
    | 8  | `"H"`         | `"14"`                            | flexible, 24h |
    | 9  | `"EHm"`       | `"Tue 14:35"`                     | flexible, 24h |
    | 10 | `"EHms"`      | `"Tue 14:35:00"`                  | flexible, 24h |
    | 11 | `"Hmsv"`      | `"14:35:00 UTC"`                  | flexible, 24h |
    | 12 | `"Hmv"`       | `"14:35 UTC"`                     | flexible, 24h |
    | 13 | `"hms"`       | `"2:35:00 PM"`                    | flexible, 12h |
    | 14 | `"hm"`        | `"2:35 PM"`                       | flexible, 12h |
    | 15 | `"h"`         | `"2 PM"`                          | flexible, 12h |
    | 16 | `"Ehm"`       | `"Tue 2:35 PM"`                   | flexible, 12h |
    | 17 | `"Ehms"`      | `"Tue 2:35:00 PM"`                | flexible, 12h |
    | 18 | `"EBhms"`     | `"Tue 2:35:00 in the afternoon"`  | flexible, 12h |
    | 19 | `"Bhms"`      | `"2:35:00 in the afternoon"`      | flexible, 12h |
    | 20 | `"EBhm"`      | `"Tue 2:35 in the afternoon"`     | flexible, 12h |
    | 21 | `"Bhm"`       | `"2:35 in the afternoon"`         | flexible, 12h |
    | 22 | `"Bh"`        | `"2 in the afternoon"`            | flexible, 12h |
    | 23 | `"hmsv"`      | `"2:35:00 PM UTC"`                | flexible, 12h |
    | 24 | `"hmv"`       | `"2:35 PM UTC"`                   | flexible, 12h |
    | 25 | `"ms"`        | `"35:00"`                         | flexible      |

    The names of the flexible time styles are CLDR skeletons, where each letter stands for a field:
    `H` is the hour (0-23), `h` the hour (1-12) with AM or PM, `B` the hour with a period of the day
    (e.g., "in the afternoon"), `m` the minute, `s` the second, `E` the day of the week, and `v` the
    time zone.

    The styles with the day of the week (`E`) need `datetime` values (or datetime strings); a `time`
    value without a date raises an error with them. The styles with the time zone (`v`) give its
    generic name for an aware value (e.g., `"ET"` for `America/New_York`), falling back to a name
    like `"UTC"` or an offset like `"-0500"` for a zone without one. A naive value is taken to be in
    UTC.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Adapting output to a specific `locale`
    --------------------------------------
    This formatting method can adapt outputs according to a provided `locale` value. Examples
    include `"en"` for English (United States) and `"fr"` for French (France). Note that a `locale`
    value provided here will override any global locale setting performed in
    [`GT()`](`great_tables.GT`)'s own `locale` argument (it is settable there as a value received by
    all other methods that have a `locale` argument).

    Examples
    --------
    Let's use the `exibble` dataset to create a simple, two-column table (keeping only the `date`
    and `time` columns). With the [`fmt_time()`](`great_tables.GT.fmt_time`) method, we'll format
    the `time` column to display times formatted with the `"h_m_s_p"` time style.

    ```{python}
    from great_tables import GT, exibble

    exibble_mini = exibble[["date", "time"]]

    (
        GT(exibble_mini)
        .fmt_time(columns="time", time_style="h_m_s_p")
    )
    ```

    A flexible time style adapts to the locale. Here, the `"hm"` style is used to format the times
    for a table in Japanese.

    ```{python}
    (
        GT(exibble_mini, locale="ja")
        .fmt_time(columns="time", time_style="hm")
    )
    ```
    """

    locale = _resolve_locale(self, locale=locale)

    # Get the time format pattern based on the `time_style` value
    time_pattern = _DatetimePattern.from_pattern(
        _get_time_format(time_style=time_style, locale=locale)
    )

    pf_format = partial(
        fmt_time_context,
        data=self,
        time_pattern=time_pattern,
        pattern=pattern,
        locale=locale,
        context=None,  # Ensure the 'context' parameter is explicitly handled
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_time_context(
    x: Any,
    data: GTData,
    time_pattern: _DatetimePattern,
    pattern: str,
    locale: str | None,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # If `x` is a string, assume it is an ISO time (or datetime) string and convert it
    if isinstance(x, str):
        x = _iso_str_to_time(x)

    elif not isinstance(x, datetime):
        # Stop if `x` is not a valid time object
        _validate_time_obj(x=x)

    babel_locale = _get_babel_locale(locale)

    if isinstance(x, datetime):
        # Babel's `format_time()` would drop the date, which a style showing the weekday needs
        x_formatted = format_datetime(
            x, format=time_pattern.for_value(x, locale), locale=babel_locale
        )

    elif time_pattern.has_date_fields:
        # Babel would take the date as today
        raise ValueError(
            f"Invalid time: '{x}' has no date, so it can't be formatted with a time style that "
            "shows the weekday. Use datetime values or a time style without the weekday."
        )

    else:
        # Format the time object to a string using Babel's `format_time()` function
        x_formatted = format_time(x, format=time_pattern.for_value(x, locale), locale=babel_locale)

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_datetime(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    date_style: DateStyle = "iso",
    time_style: TimeStyle = "iso",
    format_str: str | None = None,
    sep: str = " ",
    pattern: str = "{x}",
    locale: str | None = None,
) -> GTSelf:
    """
    Format values as datetimes.

    Format input values to datetime values using one of 41 preset date styles and one of 25 preset
    time styles, or with a format string. Input can be in the form of `datetime` values, or strings
    in the ISO 8601 forms of `YYYY-MM-DD HH:MM:SS` or `YYYY-MM-DD`.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    date_style
        The date style to use. By default this is the short name `"iso"` which corresponds to
        ISO 8601 date formatting. There are 41 date styles in total.
    time_style
        The time style to use. By default this is the short name `"iso"` which corresponds to how
        times are formatted within ISO 8601 datetime values. There are 25 time styles in total.
    format_str
        A format string to use instead of the preset styles. This can be a CLDR datetime pattern
        (e.g., `"EEEE, d MMMM y"`), which is localized using `locale=` (or the table locale), or a
        `strftime()` format string (any string containing `%`, e.g., `"%d.%m.%Y"`), which isn't
        localized. If `format_str=` is provided, the `date_style=`, `time_style=`, and `sep=`
        arguments are ignored.
    sep
        A string that separates the date and time components of the datetime string. The default is
        a space character (`" "`). This is ignored if `format_str=` is provided.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    locale
        An optional locale identifier that can be used for formatting values according the locale's
        rules. Examples include `"en"` for English (United States) and `"fr"` for French (France).
        This can't be used with a `strftime()` format string in `format_str=`, since that isn't
        localized (with one, a table locale set in [`GT()`](`great_tables.GT`) is ignored).

    Formatting with the `date_style=` and `time_style=` arguments
    -------------------------------------------------------------
    If not supplying a formatting string to `format_str=` we need to supply a preset date style to
    the `date_style=` argument and a preset time style to the `time_style=` argument. The date and
    time parts are formatted separately and joined by `sep=`. The styles are numerous and can
    handle localization to any supported locale. Those termed flexible adapt their output to any
    `locale=` provided: the order of the fields, the punctuation, and even which fields are
    abbreviated follow the locale's conventions. That feature makes the flexible formats a better
    option for locales other than `"en"` (the default locale).

    The following table provides a listing of all date styles and their output values
    (corresponding to an input of `2000-02-29 14:35:00`).

    |    | Date Style             | Output                         | Notes    |
    |----|------------------------|--------------------------------|----------|
    | 1  | `"iso"`                | `"2000-02-29"`                 | ISO 8601 |
    | 2  | `"wday_month_day_year"`| `"Tuesday, February 29, 2000"` |          |
    | 3  | `"wd_m_day_year"`      | `"Tue, Feb 29, 2000"`          |          |
    | 4  | `"wday_day_month_year"`| `"Tuesday 29 February 2000"`   |          |
    | 5  | `"month_day_year"`     | `"February 29, 2000"`          |          |
    | 6  | `"m_day_year"`         | `"Feb 29, 2000"`               |          |
    | 7  | `"day_m_year"`         | `"29 Feb 2000"`                |          |
    | 8  | `"day_month_year"`     | `"29 February 2000"`           |          |
    | 9  | `"day_month"`          | `"29 February"`                |          |
    | 10 | `"day_m"`              | `"29 Feb"`                     |          |
    | 11 | `"year"`               | `"2000"`                       |          |
    | 12 | `"month"`              | `"February"`                   |          |
    | 13 | `"day"`                | `"29"`                         |          |
    | 14 | `"year.mn.day"`        | `"2000/02/29"`                 |          |
    | 15 | `"y.mn.day"`           | `"00/02/29"`                   |          |
    | 16 | `"year_week"`          | `"2000-W09"`                   | ISO 8601 |
    | 17 | `"year_quarter"`       | `"2000-Q1"`                    |          |
    | 18 | `"yMd"`                | `"2/29/2000"`                  | flexible |
    | 19 | `"yMEd"`               | `"Tue, 2/29/2000"`             | flexible |
    | 20 | `"yMMM"`               | `"Feb 2000"`                   | flexible |
    | 21 | `"yMMMM"`              | `"February 2000"`              | flexible |
    | 22 | `"yMMMd"`              | `"Feb 29, 2000"`               | flexible |
    | 23 | `"yMMMEd"`             | `"Tue, Feb 29, 2000"`          | flexible |
    | 24 | `"GyMd"`               | `"2/29/2000 AD"`               | flexible |
    | 25 | `"GyMMMd"`             | `"Feb 29, 2000 AD"`            | flexible |
    | 26 | `"GyMMMEd"`            | `"Tue, Feb 29, 2000 AD"`       | flexible |
    | 27 | `"yM"`                 | `"2/2000"`                     | flexible |
    | 28 | `"Md"`                 | `"2/29"`                       | flexible |
    | 29 | `"MEd"`                | `"Tue, 2/29"`                  | flexible |
    | 30 | `"MMMd"`               | `"Feb 29"`                     | flexible |
    | 31 | `"MMMEd"`              | `"Tue, Feb 29"`                | flexible |
    | 32 | `"MMMMd"`              | `"February 29"`                | flexible |
    | 33 | `"GyMMM"`              | `"Feb 2000 AD"`                | flexible |
    | 34 | `"yQQQ"`               | `"Q1 2000"`                    | flexible |
    | 35 | `"yQQQQ"`              | `"1st quarter 2000"`           | flexible |
    | 36 | `"Gy"`                 | `"2000 AD"`                    | flexible |
    | 37 | `"y"`                  | `"2000"`                       | flexible |
    | 38 | `"M"`                  | `"2"`                          | flexible |
    | 39 | `"MMM"`                | `"Feb"`                        | flexible |
    | 40 | `"d"`                  | `"29"`                         | flexible |
    | 41 | `"Ed"`                 | `"29 Tue"`                     | flexible |

    The `"year_week"` style gives the ISO 8601 week date in every locale: weeks start on Monday,
    week 1 is the week containing the first Thursday of the year, and the year shown is the one the
    week belongs to (so `2024-12-30` is `"2025-W01"`).

    The following table provides a listing of all time styles and their output values
    (corresponding to an input of `2000-02-29 14:35:00`). It is noted which of these represent 12-
    or 24-hour time.

    |    | Time Style    | Output                            | Notes         |
    |----|---------------|-----------------------------------|---------------|
    | 1  | `"iso"`       | `"14:35:00"`                      | ISO 8601, 24h |
    | 2  | `"iso-short"` | `"14:35"`                         | ISO 8601, 24h |
    | 3  | `"h_m_s_p"`   | `"2:35:00 PM"`                    | 12h           |
    | 4  | `"h_m_p"`     | `"2:35 PM"`                       | 12h           |
    | 5  | `"h_p"`       | `"2 PM"`                          | 12h           |
    | 6  | `"Hms"`       | `"14:35:00"`                      | flexible, 24h |
    | 7  | `"Hm"`        | `"14:35"`                         | flexible, 24h |
    | 8  | `"H"`         | `"14"`                            | flexible, 24h |
    | 9  | `"EHm"`       | `"Tue 14:35"`                     | flexible, 24h |
    | 10 | `"EHms"`      | `"Tue 14:35:00"`                  | flexible, 24h |
    | 11 | `"Hmsv"`      | `"14:35:00 UTC"`                  | flexible, 24h |
    | 12 | `"Hmv"`       | `"14:35 UTC"`                     | flexible, 24h |
    | 13 | `"hms"`       | `"2:35:00 PM"`                    | flexible, 12h |
    | 14 | `"hm"`        | `"2:35 PM"`                       | flexible, 12h |
    | 15 | `"h"`         | `"2 PM"`                          | flexible, 12h |
    | 16 | `"Ehm"`       | `"Tue 2:35 PM"`                   | flexible, 12h |
    | 17 | `"Ehms"`      | `"Tue 2:35:00 PM"`                | flexible, 12h |
    | 18 | `"EBhms"`     | `"Tue 2:35:00 in the afternoon"`  | flexible, 12h |
    | 19 | `"Bhms"`      | `"2:35:00 in the afternoon"`      | flexible, 12h |
    | 20 | `"EBhm"`      | `"Tue 2:35 in the afternoon"`     | flexible, 12h |
    | 21 | `"Bhm"`       | `"2:35 in the afternoon"`         | flexible, 12h |
    | 22 | `"Bh"`        | `"2 in the afternoon"`            | flexible, 12h |
    | 23 | `"hmsv"`      | `"2:35:00 PM UTC"`                | flexible, 12h |
    | 24 | `"hmv"`       | `"2:35 PM UTC"`                   | flexible, 12h |
    | 25 | `"ms"`        | `"35:00"`                         | flexible      |

    The styles with the time zone (`v`) give its generic name for an aware value (e.g., `"ET"` for
    `America/New_York`), falling back to a name like `"UTC"` or an offset like `"-0500"` for a zone
    without one. A naive value is taken to be in UTC.

    Formatting with a pattern in `format_str=`
    ------------------------------------------
    For full control over the output, a CLDR datetime pattern can be given to `format_str=`. In a
    pattern, runs of letters are fields that are replaced with parts of the datetime, and the
    length of a run sets the form of that field. Literal text that has letters must be put in
    single quotes (e.g., `"h 'o''clock' a"`, where `''` is a single quote). Some of the fields are:

    | Field             | Letters                  | Output for `2000-02-29 14:35:07`              |
    |-------------------|--------------------------|-----------------------------------------------|
    | year              | `y`, `yy`                | `"2000"`, `"00"`                              |
    | quarter           | `Q`, `QQQ`, `QQQQ`       | `"1"`, `"Q1"`, `"1st quarter"`                |
    | month             | `M`, `MM`, `MMM`, `MMMM` | `"2"`, `"02"`, `"Feb"`, `"February"`          |
    | day of the month  | `d`, `dd`                | `"29"`, `"29"`                                |
    | day of the week   | `E`, `EEEE`              | `"Tue"`, `"Tuesday"`                          |
    | hour (1-12)       | `h`, `hh`                | `"2"`, `"02"`                                 |
    | hour (0-23)       | `H`, `HH`                | `"14"`, `"14"`                                |
    | AM or PM          | `a`                      | `"PM"`                                        |
    | period of the day | `B`                      | `"in the afternoon"`                          |
    | minute            | `mm`                     | `"35"`                                        |
    | second            | `ss`                     | `"07"`                                        |
    | time zone         | `z`, `zzzz`, `xxx`       | `"UTC"`, `"Coordinated Universal Time"`, `"+00:00"` |

    The full list of fields is in the [CLDR date field symbol
    table](https://unicode.org/reports/tr35/tr35-dates.html#Date_Field_Symbol_Table). The generic
    time zone fields (`v` and `vvvv`, e.g., `"ET"` and `"Eastern Time"` for `America/New_York`)
    and the location ones (`V` and `VVVV`) fall back to the `z` and `zzzz` forms for a zone
    without a generic name, as with the time styles. The short GMT offset `O` gives forms like
    `"GMT-5"`, `"GMT+5:30"` and `"GMT"`, and `g` is the modified Julian day (days since
    1858-11-17). The output of a pattern is localized (e.g., `"EEEE, d MMMM y"` gives
    `"Dienstag, 29 Februar 2000"` with `locale="de"`), though the pattern itself fixes the order of
    the fields and the punctuation.

    A `strftime()` format string can be used instead (any value with `%` is treated as one). Its
    output isn't localized, so it can't be used together with `locale=`.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Let's use the `exibble` dataset to create a simple, two-column table (keeping only the `date`
    and `time` columns). With the `fmt_datetime()` method, we'll format the `date` column to display
    dates formatted with the `"month_day_year"` date style and the `time` column to display times
    formatted with the `"h_m_s_p"` time style.

    ```{python}
    from great_tables import GT, exibble

    exibble_mini = exibble[["date", "time"]]

    (
        GT(exibble_mini)
        .fmt_datetime(
            columns="date",
            date_style="month_day_year",
            time_style="h_m_s_p"
        )
    )
    ```

    With a CLDR pattern in `format_str=`, we choose the fields and their order ourselves. The
    names of the weekdays and months are still localized, here for a table in French.

    ```{python}
    (
        GT(exibble_mini, locale="fr")
        .fmt_datetime(columns="date", format_str="EEEE d MMMM y")
    )
    ```
    """

    # A `format_str=` value with a `%` is a `strftime()` format string and any other is a CLDR pattern
    strftime_str = None
    format_pattern = None

    if format_str is not None and "%" in format_str:
        # A `strftime()` format string isn't localized, so it can't be combined with `locale=`;
        # this is checked before resolving the locale so that a table locale doesn't trigger it
        if locale is not None:
            raise ValueError(
                "A `strftime()` format string (one with `%`) given to `format_str=` isn't "
                "localized, so it cannot be used together with `locale=`. To format with a "
                'locale, use a CLDR pattern instead (e.g., `format_str="d MMMM y, HH:mm"`).'
            )

        strftime_str = format_str

    elif format_str is not None:
        _validate_cldr_pattern(format_str)
        format_pattern = _DatetimePattern.from_pattern(format_str)

    locale = _resolve_locale(self, locale=locale)

    # Get the date format string based on the `date_style` value
    date_format_str = _get_date_format(date_style=date_style, locale=locale)

    # Get the time format pattern based on the `time_style` value
    time_pattern = _DatetimePattern.from_pattern(
        _get_time_format(time_style=time_style, locale=locale)
    )

    pf_format = partial(
        fmt_datetime_context,
        data=self,
        date_format_str=date_format_str,
        time_pattern=time_pattern,
        strftime_str=strftime_str,
        format_pattern=format_pattern,
        sep=sep,
        pattern=pattern,
        locale=locale,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_datetime_context(
    x: Any,
    data: GTData,
    date_format_str: str,
    time_pattern: _DatetimePattern,
    strftime_str: str | None,
    format_pattern: _DatetimePattern | None,
    sep: str,
    pattern: str,
    locale: str | None,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    # If `x` is a string, assume it is an ISO datetime string and convert it to a datetime object
    if isinstance(x, str):
        # Convert the ISO datetime string to a datetime object
        x = _iso_str_to_datetime(x)

    else:
        # Stop if `x` is not a valid datetime object
        _validate_datetime_obj(x=x)

    babel_locale = _get_babel_locale(locale)

    if strftime_str is not None:
        x_formatted = x.strftime(strftime_str)

    elif format_pattern is not None:
        x_formatted = format_datetime(
            x, format=format_pattern.for_value(x, locale), locale=babel_locale
        )

    else:
        # Format the date and the time separately and join them with `sep` (which, as literal
        # text, can't safely be put into one CLDR pattern with them)
        date_str = format_date(x, format=_resolve_iso_week(date_format_str, x), locale=babel_locale)
        time_str = format_datetime(x, format=time_pattern.for_value(x, locale), locale=babel_locale)

        x_formatted = f"{date_str}{sep}{time_str}"

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_tf(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    tf_style: str = "true-false",
    pattern: str = "{x}",
    true_val: str | None = None,
    false_val: str | None = None,
    na_val: str | None = None,
    colors: list[str] | None = None,
) -> GTSelf:
    """
    Format True and False values

    There can be times where boolean values are useful in a display table. You might want to express
    a 'yes' or 'no', a 'true' or 'false', or, perhaps use pairings of complementary symbols that
    make sense in a table. The `fmt_tf()` method has a set of `tf_style=` presets that can be used
    to quickly map `True`/`False` values to strings, or, symbols like up/down or left/right arrows
    and open/closed shapes.

    While the presets are nice, you can provide your own mappings through the `true_val=` and
    `false_val=` arguments. For extra customization, you can also apply color to the individual
    `True`, `False`, and NA mappings. Just supply a list of colors (up to a length of 3) to the
    `colors=` argument.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    tf_style
        The `True`/`False` mapping style to use. By default this is the short name `"true-false"`
        which corresponds to the words `"true"` and `"false"`. Two other `tf_style=` values produce
        words: `"yes-no"` and `"up-down"`. The remaining options involve pairs of symbols (e.g.,
        `"check-mark"` displays a check mark for `True` and an ✗ symbol for `False`).
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.
    true_val
        While the choice of a `tf_style=` will typically supply the `true_val=` and `false_val=`
        text, we could override this and supply text for any `True` values. This doesn't need to be
        used in conjunction with `false_val=`.
    false_val
        While the choice of a `tf_style=` will typically supply the `true_val=` and `false_val=`
        text, we could override this and supply text for any `False` values. This doesn't need to be
        used in conjunction with `true_val=`.
    na_val
        None of the `tf_style` presets will replace any missing values encountered in the targeted
        cells. While we always have the option to use `sub_missing()` for NA replacement, we have
        the opportunity handle missing values here with the `na_val=` option. This is useful because
        we also have the means to add color to the `na_val=` text or symbol and doing that requires
        that a replacement value for NAs is specified here.
    colors
        Providing a list of color values to colors will progressively add color to the formatted
        result depending on the number of colors provided. With a single color, all formatted values
        will be in that color. Using two colors results in `True` values being the first color, and
        `False` values receiving the second. With the three-color option, the final color will be
        given to any missing values replaced through `na_val=`.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Formatting with the `tf_style=` argument
    ----------------------------------------
    We need to supply a preset `tf_style=` value. The following table provides a listing of all
    `tf_style=` values and their output `True` and `False` values.

    |    | TF Style        | Output                  |
    |----|-----------------|-------------------------|
    | 1  | `"true-false"`  | `"true" / `"false"`     |
    | 2  | `"yes-no"`      | `"yes" / `"no"`         |
    | 3  | `"up-down"`     | `"up" / `"down"`        |
    | 4  | `"check-mark"`  | `"✓" / `"✗"`            |
    | 5  | `"circles"`     | `"●" / `"○"`            |
    | 6  | `"squares"`     | `"■" / `"□"`            |
    | 7  | `"diamonds"`    | `"◆" / `"◇"`            |
    | 8  | `"arrows"`      | `"↑" / `"↓"`            |
    | 9  | `"triangles"`   | `"▲" / `"▼"`            |
    | 10 | `"triangles-lr"`| `"▶" / `"◀"`            |

    Examples
    --------
    Let's use a subset of the `sp500` dataset to create a small table containing opening and closing
    price data for the last few days in 2015. We added a boolean column (`dir`) where `True`
    indicates a price increase from opening to closing and `False` is the opposite. Using `fmt_tf()`
    generates up and down arrows in the `dir` column. We elect to use green upward arrows and red
    downward arrows (through the `colors=` option).

    ```{python}
    from great_tables import GT, data
    import polars as pl

    sp500_mini = (
        data.pl.sp500
        .slice(0, 5)
        .drop(["volume", "adj_close", "high", "low"])
        .with_columns(dir = pl.col("close") > pl.col("open"))
    )

    (
        GT(sp500_mini, rowname_col="date")
        .fmt_tf(columns="dir", tf_style="arrows", colors=["green", "red"])
        .fmt_currency(columns=["open", "close"])
        .cols_label(
            open="Opening",
            close="Closing",
            dir=""
        )
    )
    ```
    """
    # If colors is a string, convert it to a list
    if isinstance(colors, str):
        colors = [colors]

    pf_format = partial(
        fmt_tf_context,
        data=self,
        tf_style=tf_style,
        pattern=pattern,
        true_val=true_val,
        false_val=false_val,
        na_val=na_val,
        colors=colors,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_tf_context(
    x: Any,
    data: GTData,
    tf_style: str,
    pattern: str,
    true_val: str | None,
    false_val: str | None,
    na_val: str | None,
    colors: list[str] | None,
    context: str,
) -> str | FormatterSkipElement:
    if is_na(data._tbl_data, x):
        x = None
    elif isinstance(x, NpBool):
        # pandas gives NumPy booleans, which aren't instances of `bool`
        x = bool(x)
    elif not isinstance(x, bool):
        raise ValueError(f"Expected boolean value or NA, but got {type(x)}.")

    x = cast("bool | None", x)

    # Validate `tf_style=` value
    if tf_style not in TF_FORMATS:
        raise ValueError(
            f"Invalid `tf_style`: {tf_style}. Must be one of {list(TF_FORMATS.keys())}."
        )

    # Check type of `na_val=` and raise error if not a string or None
    if na_val is not None and not isinstance(na_val, str):
        raise ValueError("The `na_val` argument must be a string or None.")

    # If `x` is None and `na_val` is None, skip formatting entirely
    if x is None and na_val is None:
        return FormatterSkipElement()

    # Add warning in LaTeX context about `colors=` not being supported
    if context == "latex" and colors is not None:
        raise ValueError("The `colors=` argument is not currently supported for LaTeX tables.")

    # Obtain the list of `True`/`False` text values with overrides
    tf_vals_list = _get_tf_vals(tf_style=tf_style, true_val=true_val, false_val=false_val)

    tf_vals = TfMap(*tf_vals_list, na_color=na_val)

    x_formatted = tf_vals.get_color(x, data, strict=True)

    # Apply colors to the formatted value
    if context == "html" and colors is not None:
        # Ensure that the `colors=` value satisfies the requirements
        _check_colors(colors=colors)

        # Create color mapping
        color_map = TfMap.from_list(colors)

        # Get the appropriate color for this value
        color = color_map.get_color(x, data, strict=False)

        x_styled = f'<span style="color:{color}">{x_formatted}</span>'

    else:
        x_styled = x_formatted

    # Use a supplied pattern specification to decorate the formatted value
    return _apply_value_pattern(x_styled, pattern=pattern, context=context)


TF_FORMATS: dict[str, list[str]] = {
    "true-false": ["true", "false"],
    "yes-no": ["yes", "no"],
    "up-down": ["up", "down"],
    "check-mark": ["\u2714", "\u2718"],
    "circles": ["\u25cf", "\u2b58"],
    "squares": ["\u25a0", "\u25a1"],
    "diamonds": ["\u25c6", "\u25c7"],
    "arrows": ["\u2191", "\u2193"],
    "triangles": ["\u25b2", "\u25bc"],
    "triangles-lr": ["\u25b6", "\u25c0"],
}


def _check_colors(colors: list[str]):
    """
    Check if the provided colors are valid.

    Parameters
    ----------
    colors
        A list of colors to check.
    Raises
    ------
    ValueError
        If the colors are not valid.
    """
    if len(colors) > 3 or len(colors) < 1:
        raise ValueError("The `colors` argument must be a list of 1 to 3 colors.")
    for color in colors:
        if not isinstance(color, str):
            raise ValueError("Each color in the `colors` list must be a string.")


def _get_tf_vals(
    tf_style: str, true_val: str | None = None, false_val: str | None = None
) -> list[str]:
    """
    Get the `True`/`False` text values based on the `tf_style`, with optional overrides.

    Parameters
    ----------
    tf_style
        The `True`/`False` mapping style to use.
    true_val
        Optional override for the True value.
    false_val
        Optional override for the False value.

    Returns
    -------
    list[str]
        A list of two strings representing the `True` and `False` values.
    """
    # Get the base values from the TF_FORMATS dictionary
    tf_vals = TF_FORMATS[tf_style].copy()

    # Override with provided values if any
    if true_val is not None:
        tf_vals[0] = true_val
    if false_val is not None:
        tf_vals[1] = false_val

    return tf_vals


@dataclass
class TfMap:
    true_color: str | None = None
    false_color: str | None = None
    na_color: str | None = None

    @classmethod
    def from_list(cls, colors: list[str]) -> TfMap:
        if len(colors) == 1:
            return cls(true_color=colors[0], false_color=colors[0])
        elif len(colors) == 2:
            return cls(true_color=colors[0], false_color=colors[1])
        elif len(colors) == 3:
            return cls(true_color=colors[0], false_color=colors[1], na_color=colors[2])
        else:
            raise ValueError("Colors list must have 1-3 elements.")

    @overload
    def get_color(self, x: bool | None, data: GTData, strict: Literal[False]) -> str | None: ...

    @overload
    def get_color(self, x: bool | None, data: GTData, strict: Literal[True]) -> str: ...

    def get_color(self, x: bool | None, data: GTData, strict: bool = False) -> str | None:
        if x is True:
            res = self.true_color
        elif x is False:
            res = self.false_color
        elif is_na(data._tbl_data, x):
            res = self.na_color
        else:
            raise TypeError(f"Unexpected value type: {type(x)}")

        if strict and res is None:
            raise ValueError("No style defined for this value in TfMap.")

        return res


def fmt_markdown(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
) -> GTSelf:
    """
    Format Markdown text.

    Any Markdown-formatted text in the incoming cells will be transformed during render when using
    the [`fmt_markdown()`](`great_tables.GT.fmt_markdown`) method.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples:
    -------
    Let’s first create a DataFrame containing some text that is Markdown-formatted and then introduce
    that to [`GT()`](`great_tables.GT`). We’ll then transform the `md` column with the
    [`fmt_markdown()`](`great_tables.GT.fmt_markdown`) method.

    ```{python}
    import pandas as pd
    from great_tables import GT
    from great_tables.data import towny

    text_1 = \"""
    ### This is Markdown.

    Markdown’s syntax is comprised entirely of
    punctuation characters, which punctuation
    characters have been carefully chosen so as
    to look like what they mean... assuming
    you’ve ever used email.
    \"""

    text_2 = \"""
    Info on Markdown syntax can be found
    [here](https://daringfireball.net/projects/markdown/).
    \"""

    df = pd.DataFrame({"md": [text_1, text_2]})

    (GT(df).fmt_markdown("md"))
    ```
    """

    pf_format = partial(
        fmt_markdown_context,
        data=self,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_markdown_context(
    x: Any,
    data: GTData,
    context: str,
) -> str:
    if is_na(data._tbl_data, x):
        return x

    if context == "latex":
        return _md_latex(str(x))

    x_str: str = str(x)

    x_formatted = _md_html(x_str)

    return x_formatted


def fmt_units(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    pattern: str = "{x}",
) -> GTSelf:
    """
    Format measurement units.

    The `fmt_units()` method lets you better format measurement units in the table body. These must
    conform to the **Great Tables** *units notation*; as an example of this, `"J Hz^-1 mol^-1"` can
    be used to generate units for the *molar Planck constant*. The notation here provides several
    conveniences for defining units, so as long as the values to be formatted conform to this
    syntax, you'll obtain nicely-formatted inline units. Details pertaining to *units notation* can
    be found in the section entitled *How to use units notation*.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by the `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.

    How to use units notation
    -------------------------
    The **Great Tables** units notation involves a shorthand of writing units that feels familiar
    and is fine-tuned for the task at hand. Each unit is treated as a separate entity (parentheses
    and other symbols included) and the addition of subscript text and exponents is flexible and
    relatively easy to formulate. This is all best shown with examples:

    - `"m/s"` and `"m / s"` both render as `"m/s"`
    - `"m s^-1"` will appear with the `"-1"` exponent intact
    - `"m /s"` gives the the same result, as `"/<unit>"` is equivalent to `"<unit>^-1"`
    - `"E_h"` will render an `"E"` with the `"h"` subscript
    - `"t_i^2.5"` provides a `t` with an `"i"` subscript and a `"2.5"` exponent
    - `"m[_0^2]"` will use overstriking to set both scripts vertically
    - `"g/L %C6H12O6%"` uses a chemical formula (enclosed in a pair of `"%"` characters) as a unit
    partial, and the formula will render correctly with subscripted numbers
    - Common units that are difficult to write using ASCII text may be implicitly converted to the
    correct characters (e.g., the `"u"` in `"ug"`, `"um"`, `"uL"`, and `"umol"` will be converted to
    the Greek *mu* symbol; `"degC"` and `"degF"` will render a degree sign before the temperature
    unit)
    - We can transform shorthand symbol/unit names enclosed in `":"` (e.g., `":angstrom:"`,
    `":ohm:"`, etc.) into proper symbols
    - Greek letters can added by enclosing the letter name in `":"`; you can use lowercase letters
    (e.g., `":beta:"`, `":sigma:"`, etc.) and uppercase letters too (e.g., `":Alpha:"`, `":Zeta:"`,
    etc.)
    - The components of a unit (unit name, subscript, and exponent) can be fully or partially
    italicized/emboldened by surrounding text with `"*"` or `"**"`

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Let's use the `illness` dataset and create a new table. The `units` column happens to contain
    string values in *units notation* (e.g., `"x10^9 / L"`). Using the `fmt_units()` method here
    will improve the formatting of those measurement units.

    ```{python}
    from great_tables import GT, style, loc
    from great_tables.data import illness

    (
        GT(illness, rowname_col="test")
        .fmt_units(columns="units")
        .fmt_number(columns=lambda x: x.startswith("day"), decimals=2, drop_trailing_zeros=True)
        .tab_header(title="Laboratory Findings for the YF Patient")
        .tab_spanner(label="Day", columns=lambda x: x.startswith("day"))
        .tab_spanner(label="Normal Range", columns=lambda x: x.startswith("norm"))
        .cols_label(
          norm_l="Lower",
          norm_u="Upper",
          units="Units"
        )
        .opt_vertical_padding(scale=0.4)
        .opt_align_table_header(align="left")
        .tab_options(heading_padding="10px")
        .tab_style(
            locations=loc.body(columns="norm_l"),
            style=style.borders(sides="left")
        )
        .opt_vertical_padding(scale=0.5)
    )
    ```

    The `constants` dataset contains values for hundreds of fundamental physical constants. We'll
    take a subset of values that have some molar basis and generate a new display table from that.
    Like the `illness` dataset, this one has a `units` column so, again, the `fmt_units()` method
    will be used to format those units. Here, the preference for typesetting measurement units is to
    have positive and negative exponents (e.g., not `"<unit_1> / <unit_2>"` but rather
    `"<unit_1> <unit_2>^-1"`).

    ```{python}
    from great_tables import data
    import polars as pl
    import polars.selectors as cs

    constants_mini = (
        data.pl.constants
        .filter(pl.col("name").str.contains("molar")).sort("value")
        .with_columns(
            name=pl.col("name")
            .str.to_titlecase()
            .str.replace("Kpa", "kpa")
            .str.replace("Of", "of")
        )
    )

    (
        GT(constants_mini)
        .cols_hide(columns=["uncert", "sf_value", "sf_uncert"])
        .fmt_units(columns="units")
        .fmt_scientific(columns="value", decimals=3)
        .tab_header(title="Physical Constants Having a Molar Basis")
        .tab_options(column_labels_hidden=True)
    )
    ```
    """

    def fmt_units_fn(
        x: str,
        pattern: str = pattern,
        context: str = "html",
    ):
        # If the `x` value is a missing value, then return the same value
        if is_na(self._tbl_data, x):
            return x

        from great_tables._helpers import define_units

        units = define_units(x)
        x_formatted = units.to_latex() if context == "latex" else units.to_html()

        # Use a supplied pattern specification to decorate the formatted value
        x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

        return x_formatted

    return fmt_by_context(self, pf_format=fmt_units_fn, columns=columns, rows=rows)


def _apply_value_pattern(x_formatted: str, pattern: str, context: str) -> str:
    """
    Decorate a formatted value with a `pattern=` specification (e.g., `"({x})"`).

    In LaTeX, special characters in the pattern's literals are escaped (the `{x}` placeholder is
    left as is).
    """

    if pattern == "{x}":
        return x_formatted

    if context == "latex":
        pattern = escape_pattern_str_latex(pattern_str=pattern)

    return pattern.replace("{x}", x_formatted)


def _format_nonfinite_value(x: float, force_sign: bool, pattern: str, context: str) -> str:
    """
    Format an infinite or NaN value the way `fmt_number()` does.

    Non-finite values have no mantissa, exponent, unit or fraction, so formatters that need one of
    these use this instead.
    """

    x_formatted = _value_to_decimal_notation(value=x, force_sign=force_sign)
    x_formatted = _replace_minus(x_formatted, minus_mark=_context_minus_mark(context=context))

    # Use a supplied pattern specification to decorate the formatted value
    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def _value_to_decimal_notation(
    value: float,
    decimals: int = 2,
    n_sigfig: int | None = None,
    drop_trailing_zeros: bool = False,
    drop_trailing_dec_mark: bool = True,
    use_seps: bool = True,
    sep_mark: str = ",",
    dec_mark: str = ".",
    force_sign: bool = False,
    min_sep_threshold: int = 1,
    system: NumberSystem = "intl",
) -> str:
    """
    Decimal notation.

    Returns a string value with the correct precision or fixed number of decimal places (with
    optional formatting of the decimal part).
    """

    is_positive = value > 0

    # Infinity has no significant digits, so it always takes the conventional pathway
    if n_sigfig and not math.isinf(value):
        # If there is a value provided to `n_sigfig` then number formatting proceeds through the
        # significant digits pathway, which ignores `decimals` and any removal of trailing zero values
        # in the decimal portion of the value
        result = _format_number_n_sigfig(
            value=value,
            n_sigfig=n_sigfig,
            use_seps=use_seps,
            sep_mark=sep_mark,
            dec_mark=dec_mark,
            preserve_integer=False,
            min_sep_threshold=min_sep_threshold,
            system=system,
        )

    else:
        # If there is nothing provided to `n_sigfig` then the conventional decimal number formatting
        # pathway is taken; this formats to a specific number of decimal places and removal of
        # trailing zero values can be undertaken
        result = _format_number_fixed_decimals(
            value=value,
            decimals=decimals,
            drop_trailing_zeros=drop_trailing_zeros,
            use_seps=use_seps,
            sep_mark=sep_mark,
            dec_mark=dec_mark,
            min_sep_threshold=min_sep_threshold,
            system=system,
        )

    # Drop the trailing decimal mark if it is present
    if drop_trailing_dec_mark:
        result = result.rstrip(dec_mark)

    # Add in a trailing decimal mark under specific circumstances
    if drop_trailing_dec_mark is False and dec_mark not in result:
        result = result + dec_mark

    # A value that rounds to zero (e.g., `-0.001` with two decimals) is shown as zero, without a
    # sign; the sign is decided from the rounded value rather than the input
    if _rounds_to_zero(result):
        result = result.lstrip("-")
        is_positive = False

    # Force the positive sign to be present if the `force_sign` option is taken
    if is_positive and force_sign:
        result = "+" + result

    return result


def _value_to_scientific_notation(
    value: float,
    decimals: int = 2,
    n_sigfig: int | None = None,
    dec_mark: str = ".",
) -> str:
    """
    Scientific notation.

    Returns a string value with the correct precision and 10s exponent. An 'E' is placed between
    the decimal value and 10s exponent.
    """

    # Transform value of `decimals` to `n_sigfig`
    if n_sigfig:
        pass
    else:
        n_sigfig = decimals + 1

    is_negative, sig_digits, dot_power, ten_power = _get_sci_parts(value, n_sigfig)

    result = (
        ("-" if is_negative else "")
        + _insert_decimal_mark(digits=sig_digits, power=dot_power, dec_mark=dec_mark)
        + "E"
        + str(ten_power)
    )

    return result


def _format_number_n_sigfig(
    value: float,
    n_sigfig: int,
    use_seps: bool = True,
    sep_mark: str = ",",
    dec_mark: str = ".",
    preserve_integer: bool = False,
    min_sep_threshold: int = 1,
    system: NumberSystem = "intl",
) -> str:
    sig_digits, power, is_negative = _get_number_profile(value, n_sigfig)

    formatted_value = ("-" if is_negative else "") + _insert_decimal_mark(
        digits=sig_digits, power=power, dec_mark="."
    )

    # Get integer and decimal parts
    # Split number at `.` and obtain the integer and decimal parts
    number_parts = formatted_value.split(".")
    integer_part = number_parts[0].lstrip("-")
    decimal_part = number_parts[1] if len(number_parts) > 1 else ""

    # Initialize formatted representations of integer and decimal parts
    formatted_integer = ""
    formatted_decimal = dec_mark + decimal_part if decimal_part else ""

    if preserve_integer and "." not in formatted_value:
        formatted_value = f"{value:0.0f}"

    # Insert grouping separators within the integer part, but only when it has enough digits
    # for the `min_sep_threshold` (the default of `1` starts grouping at four digits)
    if use_seps and len(integer_part) >= min_sep_threshold + 3:
        formatted_integer = _group_integer_digits(integer_part, sep_mark=sep_mark, system=system)
    else:
        formatted_integer = integer_part

    # Add back the negative sign if the number is negative
    if is_negative:
        formatted_integer = "-" + formatted_integer

    # Combine the integer and decimal parts
    result = formatted_integer + formatted_decimal

    return result


def _format_number_fixed_decimals(
    value: float,
    decimals: int,
    drop_trailing_zeros: bool = False,
    use_seps: bool = True,
    sep_mark: str = ",",
    dec_mark: str = ".",
    min_sep_threshold: int = 1,
    system: NumberSystem = "intl",
) -> str:
    # If `number` is a string, cast it into a float
    if isinstance(value, str):
        value = float(value)

    is_negative = value < 0

    fmt_spec = f".{decimals}f"

    # Get the formatted `x` value; the `f` format converts an integer to a float, which changes
    # the digits of integers above 2^53 (e.g., 1234567890123456789 would give
    # 1234567890123456768), so integers are formatted as a `Decimal` to keep all of their digits
    if isinstance(value, numbers.Integral):
        value_str = format(Decimal(int(value)), fmt_spec)
    elif isinstance(value, Decimal):
        # A `Decimal` is rounded with the rounding mode of the active `decimal` context, which a
        # user may have changed, so round half to even here, as float formatting does
        with localcontext(Context(rounding=ROUND_HALF_EVEN)):
            value_str = format(value, fmt_spec)
    else:
        value_str = format(value, fmt_spec)

    # Very small or very large numbers can be represented in exponential
    # notation but we don't want that; we need the string value to be fully
    # expanded with zeros so if an 'e' is detected we'll use a helper function
    # to ensure it's back to a number
    if "e" in value_str or "E" in value_str:
        value_str = _expand_exponential_to_full_string(str_number=value_str)

    # Split number at `.` and obtain the integer and decimal parts
    number_parts = value_str.split(".")
    integer_part = number_parts[0].lstrip("-")
    decimal_part = number_parts[1] if len(number_parts) > 1 else ""

    # Drop any trailing zeros if option is taken; only the decimal part is stripped so that
    # zeros in the integer part (e.g., `100` with `decimals=0`) are kept (this purposefully
    # doesn't apply to numbers formatted to a specific number of significant digits)
    if drop_trailing_zeros:
        decimal_part = decimal_part.rstrip("0")

    # Initialize formatted representations of integer and decimal parts
    formatted_integer = ""
    formatted_decimal = dec_mark + decimal_part if decimal_part else ""

    # Insert grouping separators within the integer part, but only when it has enough digits
    # for the `min_sep_threshold` (the default of `1` starts grouping at four digits)
    if use_seps and len(integer_part) >= min_sep_threshold + 3:
        formatted_integer = _group_integer_digits(integer_part, sep_mark=sep_mark, system=system)
    else:
        formatted_integer = integer_part

    # Add back the negative sign if the number is negative
    if is_negative:
        formatted_integer = "-" + formatted_integer

    # Combine the integer and decimal parts
    result = formatted_integer + formatted_decimal

    return result


def _group_integer_digits(integer_part: str, sep_mark: str, system: NumberSystem = "intl") -> str:
    """
    Insert grouping separators into the digits of an integer part.

    The international system groups every three digits (`1,234,567`); the Indian system groups
    the last three digits and then every two (`12,34,567`), for thousands, lakhs and crores.
    """

    head, groups = integer_part[:-3], [integer_part[-3:]]
    size = 2 if system == "ind" else 3

    while head:
        groups.append(head[-size:])
        head = head[:-size]

    return sep_mark.join(reversed(groups))


def _validate_number_system(system: str) -> None:
    if system not in ("intl", "ind"):
        raise ValueError(f"`system` must be either 'intl' or 'ind', got {system!r}.")


def _rounds_up_to(
    scaled_value: float, threshold: float, decimals: int, n_sigfig: int | None
) -> bool:
    """
    Check whether formatting a scaled value carries it up to the next unit.

    Formatters that divide a value by a unit (a suffix, prefix, byte unit or power of 1000) pick
    the unit before formatting, so rounding can carry the scaled value up to `threshold` (e.g.,
    999,999 with two decimals would give `1,000.00K`). The check formats `scaled_value` exactly
    as the final output is formatted (with plain separators, so any `dec_mark=` or `sep_mark=`
    is irrelevant) and compares the formatted magnitude, so it can't disagree with the output.
    """

    formatted = _value_to_decimal_notation(
        value=_exact_abs(scaled_value),
        decimals=decimals,
        n_sigfig=n_sigfig,
        use_seps=False,
        dec_mark=".",
    )

    return float(formatted) >= threshold


# The power of ten and the suffix of each unit used by `compact=True`, for each number system
_COMPACT_SUFFIXES: dict[str, list[tuple[int, str]]] = {
    "intl": [(0, ""), (3, "K"), (6, "M"), (9, "B"), (12, "T"), (15, "Q")],
    "ind": [(0, ""), (5, " Lac"), (7, " Cr")],
}


def _format_number_compactly(
    value: float,
    decimals: int,
    n_sigfig: int | None,
    drop_trailing_zeros: bool,
    drop_trailing_dec_mark: bool,
    use_seps: bool,
    sep_mark: str,
    dec_mark: str,
    force_sign: bool,
    min_sep_threshold: int = 1,
    system: NumberSystem = "intl",
) -> str:
    # If the value is exactly zero, then we can return `0` immediately
    if value == 0:
        return "0"

    # Infinity (and NaN) has no suffix, so it is formatted the same as without `compact=True`
    if not math.isfinite(value):
        return _value_to_decimal_notation(value=value, force_sign=force_sign)

    # Stop if `n_sigfig` does not have a valid value
    if n_sigfig is not None:
        _validate_n_sigfig(n_sigfig=n_sigfig)

    # The powers of ten that each suffix stands for, from the smallest; as in gt, the Indian
    # system leaves thousands unsuffixed and expresses anything from a crore up in crores
    powers_and_suffixes = _COMPACT_SUFFIXES[system]

    # Use the largest power that doesn't exceed the value's own power of ten
    exponent = _decimal_exponent(value)
    num_power_idx = max(
        (i for i, (power, _) in enumerate(powers_and_suffixes) if power <= exponent), default=0
    )
    power = powers_and_suffixes[num_power_idx][0]

    # Scale `x` value by the power of ten, by shifting the decimal point exactly (so that the
    # value is rounded once, from the stored value)
    scaled_value = _shift_decimal_point(value, -power)

    # If rounding the scaled value carries it up to the next suffix (e.g., 999,999 with two
    # decimals would give `1,000.00K`), use the next suffix instead (`1.00M`); the value is
    # then exactly 1 of the next suffix
    if num_power_idx < len(powers_and_suffixes) - 1:
        next_power = powers_and_suffixes[num_power_idx + 1][0]

        if _rounds_up_to(
            scaled_value, threshold=10 ** (next_power - power), decimals=decimals, n_sigfig=n_sigfig
        ):
            num_power_idx += 1
            scaled_value = math.copysign(1.0, value)

    units_str = powers_and_suffixes[num_power_idx][1]

    # Format the value to decimal notation; this is done before the `byte_units` text
    # is affixed to the value
    x_formatted = _value_to_decimal_notation(
        value=scaled_value,
        decimals=decimals,
        n_sigfig=n_sigfig,
        drop_trailing_zeros=drop_trailing_zeros,
        drop_trailing_dec_mark=drop_trailing_dec_mark,
        use_seps=use_seps,
        sep_mark=sep_mark,
        min_sep_threshold=min_sep_threshold,
        dec_mark=dec_mark,
        force_sign=force_sign,
        system=system,
    )

    # Create a `suffix_pattern` object for affixing the `units_str`, which is the
    # string that represents the 'K', 'M', 'B', 'T', or 'Q' suffix (or 'Lac' or 'Cr')
    suffix_pattern = f"{{x}}{units_str}"

    x_formatted = suffix_pattern.replace("{x}", x_formatted)

    return x_formatted


def _expand_exponential_to_full_string(str_number: str) -> str:
    decimal_number = Decimal(str_number)
    formatted_number = f"{decimal_number:f}"
    return formatted_number


def _get_number_profile(value: float, n_sigfig: int) -> tuple[str, int, bool]:
    """
    Get key components of a number for decimal number formatting.

    Returns a tuple containing: (1) a string value of significant digits, (2) an
    exponent to get the decimal mark to the proper location, and (3) a boolean
    value that's True if the value is less than zero (i.e., negative).
    """
    # Integers and `Decimal` values are kept exact as a `Decimal` (a float can't hold all the digits
    # of an integer above 2^53, e.g., 1234567890123456789 would become 1234567890123456768, nor
    # those of a mantissa shifted by `_shift_decimal_point()`)
    if isinstance(value, (numbers.Integral, Decimal)):
        value = _exact_decimal(value)
    else:
        value = float(value)
    is_negative = value < 0
    value = _exact_abs(value)

    if value == 0:
        sig_digits = "0" * n_sigfig
        power = -(1 - n_sigfig)
    else:
        # Scientific notation with `n_sigfig - 1` decimals rounds the stored value itself, as
        # `decimals=` formatting does; scaling the value by a power of ten first rounds it twice
        # (32.85 is stored as 32.850000000000001, but 32.85 * 10 is exactly 328.5, which
        # `round()` takes to 328) and overflows for very small values. A rounding carry (e.g.,
        # 9.9999 to three significant digits) is reflected in the exponent ("1.00e+01")
        fmt_spec = f".{n_sigfig - 1}e"
        if isinstance(value, Decimal):
            # A `Decimal` is rounded with the rounding mode of the active `decimal` context, which
            # a user may have changed, so round half to even here, as float formatting does
            with localcontext(Context(rounding=ROUND_HALF_EVEN)):
                value_str = format(value, fmt_spec)
        else:
            value_str = format(value, fmt_spec)
        mantissa, exponent = value_str.split("e")
        sig_digits = mantissa.replace(".", "")
        power = n_sigfig - 1 - int(exponent)

    return sig_digits, -power, is_negative


def _get_sci_parts(value: float, n_sigfig: int) -> tuple[bool, str, int, int]:
    """
    Returns the properties for constructing a number in scientific notation.
    """

    sig_digits, power, is_negative = _get_number_profile(value, n_sigfig)

    dot_power = -(n_sigfig - 1)
    ten_power = power + n_sigfig - 1

    return is_negative, sig_digits, dot_power, ten_power


def _insert_decimal_mark(digits: str, power: int, dec_mark: str = ".") -> str:
    """
    Places the decimal mark in the correct location within the digits.

    Should the decimal mark be outside the numeric range, zeros will be added.
    If `drop_trailing_zeros` is True, trailing decimal zeros will be removed.

    Examples:
      _insert_decimal_mark("123",   2, False) => "12300"
      _insert_decimal_mark("123",  -2, False) => "1.23"
      _insert_decimal_mark("123",   3, False) => "0.123"
      _insert_decimal_mark("123",   5, False) => "0.00123"
      _insert_decimal_mark("120",   0, False) => "120."
      _insert_decimal_mark("1200", -2, False) => "12.00"
      _insert_decimal_mark("1200", -2, True ) => "12"
      _insert_decimal_mark("1200", -1, False) => "120.0"
      _insert_decimal_mark("1200", -1, True ) => "120"
    """

    if power > 0:
        out = digits + "0" * power

    elif power < 0:
        power = abs(power)
        n_sigfig = len(digits)

        if power < n_sigfig:
            out = digits[:-power] + dec_mark + digits[-power:]

        else:
            out = "0" + dec_mark + "0" * (power - n_sigfig) + digits

    else:
        out = digits + (dec_mark if digits[-1] == "0" and len(digits) > 1 else "")

    return out


def _listify(
    x: T | list[T] | None,
    default: Callable[[], list[T]],
) -> list[T]:
    """
    Convert the input into a list.

    Parameters
    ----------
    x
        The input value to be converted into a list. It can be a single value of type T, a list of
        values of type T, or None.
    default
        A callable that returns a default list when the input value is None.

    Returns
    -------

    list[T]: The converted list.

    Raises:
        None

    Examples:
        _listify(5, lambda: [1, 2, 3])  # Output: [5]
        _listify([1, 2, 3], lambda: [4, 5, 6])  # Output: [1, 2, 3]
        _listify(None, lambda: ['a', 'b', 'c'])  # Output: ['a', 'b', 'c']
    """
    if x is None:
        return default()
    elif not isinstance(x, list):
        return [x]
    else:
        return cast("Any", x)


def _scale_value(value: float, scale_by: float) -> float:
    """Multiply `value` by `scale_by`, exactly when both are integers.

    NumPy integers (e.g., the cells of a pandas `int64` column) are turned into Python integers
    first: NumPy integer arithmetic overflows and wraps around (`1234567890123456789 * 1000` gives
    `-1363962815083169272`), while Python integers have no size limit.

    A `Decimal` can't be multiplied by a float, so a float `scale_by` for a `Decimal` value (e.g., a
    cell of a polars `Decimal` column) is turned into the `Decimal` of its shortest repr (`2.5` stays
    exactly `2.5`), and a `Decimal` `scale_by` for a float value is turned into a float.
    """
    if isinstance(value, numbers.Integral):
        value = int(value)
    if isinstance(scale_by, numbers.Integral):
        scale_by = int(scale_by)
    if isinstance(value, Decimal) and not isinstance(scale_by, (int, Decimal)):
        scale_by = Decimal(repr(float(scale_by)))
    elif isinstance(scale_by, Decimal) and not isinstance(value, (int, Decimal)):
        scale_by = float(scale_by)
    return value * scale_by


def _exact_decimal(value: float | Decimal) -> Decimal:
    """Get a number's exact value as a `Decimal` (a float's stored value, an integer's digits)."""
    if isinstance(value, Decimal):
        return value
    if isinstance(value, numbers.Integral):
        return Decimal(int(value))
    return Decimal(float(value))


def _exact_abs(value: float | Decimal) -> float | Decimal:
    """Get a number's absolute value (`abs()` rounds a `Decimal` to the context's precision)."""
    return value.copy_abs() if isinstance(value, Decimal) else abs(value)


def _decimal_exponent(value: float | Decimal) -> int:
    """Get the exponent of a finite, nonzero number's leading digit (`floor(log10(abs(value)))`).

    The exponent is read from the exact value, so it's right where `math.log10()` rounds across
    an integer (e.g., `math.log10(999.9999999999999)` gives `3.0`).
    """
    return _exact_decimal(value).adjusted()


def _shift_decimal_point(value: float | Decimal, places: int) -> float | Decimal:
    """Multiply a finite number by `10**places` exactly, giving a `Decimal`.

    Dividing by a power of ten (`x / 10**3`) rounds the result to a float, so formatting it rounds
    the value a second time (6.7405e-05 is stored as 6.74049999...e-05, but `6.7405e-05 / 1e-06`
    gives 67.405, which then rounds to 67.41) and loses the last digits of integers above 2^53;
    `10**-324` is even `0.0`. The digits are moved by changing the exponent, which (unlike
    `Decimal.scaleb()`) doesn't round to the `decimal` context's precision. The value is
    returned as is for `places=0`.
    """
    if places == 0:
        return value
    sign, digits, exponent = _exact_decimal(value).as_tuple()
    return Decimal((sign, digits, exponent + places))


def _divide_by_power(value: int, base: int, power: int) -> float | Decimal:
    """Divide an integer by `base**power` exactly, giving a `Decimal` (`base` is 1000 or 1024).

    Dividing by a power of the base as a float rounds the result (`1150 / 1000` is stored as
    1.149999...), so formatting it rounds the value a second time (`1.1` instead of `1.2`) and
    loses the last digits of integers above 2^53. The quotient has a finite number of decimal
    places: dividing by `1000**power` shifts the decimal point by `3 * power` places, and dividing
    by `1024**power` (`2**n`, with `n = 10 * power`) is the same as multiplying by `5**n` and
    shifting the decimal point by `n` places. The value is returned as is for `power=0`.
    """
    if base == 1000:
        return _shift_decimal_point(value, -3 * power)
    n = 10 * power
    return _shift_decimal_point(value * 5**n, -n)


def _has_negative_value(value: float) -> bool:
    return value < 0


def _rounds_to_zero(x_formatted: str) -> bool:
    """Whether a formatted number shows as zero (all of its digits are `0`), e.g., `-0.00`.

    Non-finite values (`inf`, `nan`) have no digits, so they aren't zero.
    """
    digits = [char for char in x_formatted if char.isdigit()]
    return bool(digits) and all(char == "0" for char in digits)


def _has_positive_value(value: float) -> bool:
    return value > 0


def _has_zero_value(value: float) -> bool:
    return value == 0


def _context_exp_marks(context: str) -> list[str]:
    if context == "html":
        # Non-breaking spaces keep the mantissa and the power of ten on the same line (as in gt)
        marks = ["&nbsp;\u00d7&nbsp;10<sup style='font-size: 65%;'>", "</sup>"]
    elif context == "latex":
        marks = [" $\\times$ 10\\textsuperscript{", "}"]
    else:
        marks = [" \u00d7 10^", ""]

    return marks


def _context_exp_str(exp_style: str, context: str) -> str:
    if exp_style == "low-ten":
        # For the 'low-ten' style, use a specialized `exp_str` string value
        if context == "latex":
            exp_str = "\\textsubscript{10}"
        else:
            exp_str = "<sub style='font-size: 65%;'>10</sub>"

    elif _str_detect(exp_style, "^[a-zA-Z]{1}1?$"):
        # If there is a single letter (or a letter and a '1') then
        # use that letter as the `exp_str` value
        exp_str = exp_style[0]

    else:
        # Use `E` if none of the above conditions are met
        exp_str = "E"

    return exp_str


def _context_minus_mark(context: str) -> str:
    mark = "−" if context == "html" else "-"

    return mark


def _context_percent_mark(context: str) -> str:
    mark = "\\%" if context == "latex" else "%"

    return mark


def _context_dollar_mark(context: str) -> str:
    mark = "\\$" if context == "latex" else "$"

    return mark


def _replace_minus(string: str, minus_mark: str) -> str:
    """
    Replaces all occurrences of the minus sign '-' in the given string with the specified minus mark.

    Args:
        string (str): The input string.
        minus_mark (str): The mark to replace the minus sign with.

    Returns:
        str: The modified string with the minus sign replaced.
    """
    return _str_replace(string, "-", minus_mark)


def _remove_minus(string: str) -> str:
    """
    Removes all occurrences of the minus sign '-' in the given string.

    Args:
        string (str): The input string.

    Returns:
        str: The modified string with the minus sign removed.
    """
    return _str_replace(string, "-", "")


T_dict = TypeVar("T_dict", bound=TypedDict)


# TODO: remove pandas
def _filter_pd_df_to_row(pd_df: list[T_dict], column: str, filter_expr: str) -> T_dict:
    filtered_pd_df = [entry for entry in pd_df if entry[column] == filter_expr]
    if len(filtered_pd_df) != 1:
        raise RuntimeError(
            "Internal Error, the filtered table doesn't result in a table of exactly one row."
        )
    return filtered_pd_df[0]


def _get_locale_sep_mark(default: str, use_seps: bool, locale: str | None = None) -> str:
    # If `use_seps` is False, then force `sep_mark` to be an empty string
    # TODO: what does an empty string signify? Where is this used? Is it the right choice here?
    if not use_seps:
        return ""

    # If `locale` is NULL then return the default `sep_mark`
    if locale is None:
        return default

    # Get the correct `group` value from the locales lookup table
    pd_df_row = _filter_pd_df_to_row(pd_df=_get_locales_data(), column="locale", filter_expr=locale)

    # Obtain a single cell value from the single row in `pd_df_row` that is below
    # the column named 'group'; this could potentially be of any type but we expect
    # it to be a string (and we'll check for that here)
    sep_mark: Any
    sep_mark = pd_df_row["group"]
    if not isinstance(sep_mark, str):  # pragma: no cover
        raise TypeError(f"Variable type mismatch. Expected str, got {type(sep_mark)}.")

    # Replace any `""` or "\u00a0" with `" "` since an empty string actually
    # signifies a space character, and, we want to normalize to a simple space
    sep_mark = " " if sep_mark in {"", "\u00a0"} else sep_mark

    return sep_mark


def _get_locale_dec_mark(default: str, locale: str | None = None) -> str:
    # If `locale` is NULL then return the default `dec_mark`
    if locale is None:
        return default

    # Get the correct `decimal` value row from the locales lookup table
    pd_df_row = _filter_pd_df_to_row(pd_df=_get_locales_data(), column="locale", filter_expr=locale)

    # Obtain a single cell value from the single row in `pd_df_row` that is below
    # the column named 'decimal'; this could potentially be of any type but we expect
    # it to be a string (and we'll check for that here)
    dec_mark: Any
    dec_mark = pd_df_row["decimal"]

    # TODO: we control this data and should enforce this in the data schema
    if not isinstance(dec_mark, str):  # pragma: no cover
        raise TypeError(f"Variable type mismatch. Expected str, got {type(dec_mark)}.")

    return dec_mark


def _get_locale_min_sep_threshold(default: int, locale: str | None = None) -> int:
    # Stop if `min_sep_threshold` isn't a whole number of at least 1
    if isinstance(default, bool) or not isinstance(default, int) or default < 1:
        raise ValueError(
            f"The `min_sep_threshold=` value must be an integer of 1 or more, not {default!r}."
        )

    # If `locale` is None then return the default `min_sep_threshold`
    if locale is None:
        return default

    # As in gt, a locale's own minimum grouping digits value takes precedence (e.g., it is `2` for
    # the "es" and "pl" locales, so that four-digit numbers are written without a separator)
    pd_df_row = _filter_pd_df_to_row(pd_df=_get_locales_data(), column="locale", filter_expr=locale)

    return int(pd_df_row["minimum_grouping_digits"])


def _get_locales_list() -> list[str]:
    """
    Returns a list of locales as strings.

    Raises:
        TypeError: If the first element of the locale list is not a string.
    """

    # Get the 'locales' dataset and obtain from that a list of locales
    # TODO: remove pandas
    locales = _get_locales_data()
    locale_list: list[str] = [entry["locale"] for entry in locales]

    # Ensure that `locale_list` is of the type 'str'
    # TODO: we control this data and should enforce this in the data schema
    locale_list: Any
    if not isinstance(locale_list[0], str):  # pragma: no cover
        raise TypeError("Variable type mismatch. Expected str, got something entirely different.")
    return locale_list


def _validate_locale(locale: str | None = None) -> None:
    """
    Validates the given locale string against a list of supported locales.

    Args:
        locale (str or None): The locale string to validate. If None, the function returns without
        doing anything.

    Raises:
        ValueError: If the supplied `locale` is not available in the list of supported locales.
    """

    # If `locale` is None then return without doing anything (nothing to validate)
    if locale is None:
        return

    locales_list = _get_locales_list()
    default_locales_list = [entry["default_locale"] for entry in _get_default_locales_data()]

    # Replace any underscores with hyphens
    supplied_locale = _str_replace(locale, "_", "-")
    supplied_locale = _match_locale_case(supplied_locale, locales_list + default_locales_list)

    # Stop if the `locale` provided isn't a valid one
    if supplied_locale not in locales_list and supplied_locale not in default_locales_list:
        raise ValueError(
            f"The normalized locale name `{supplied_locale}` is not in the list of locales."
        )


def _match_locale_case(supplied_locale: str, known_locales: list[str]) -> str:
    """Return the known spelling of a locale, since BCP 47 tags are case insensitive."""
    lowered = supplied_locale.lower()

    for known_locale in known_locales:
        if known_locale.lower() == lowered:
            return known_locale

    return supplied_locale


def _normalize_locale(locale: str | None = None) -> str | None:
    """
    Normalize the given locale string by replacing any underscores with hyphens and resolving any default locales into their base names.

    Args:
        locale (str or None): The locale string to normalize. If None, returns None.

    Returns:
        str or None: The normalized locale string, or None if the input was None.

    Raises:
        TypeError: If the resolved locale is not of type 'str'.
    """

    # If `locale` is None then return None (we don't need to normalize anything here)
    if locale is None:
        return None

    # Replace any underscores with hyphens
    supplied_locale = _str_replace(locale, "_", "-")

    # Resolve any default locales into their base names (e.g., 'en-US' -> 'en')
    # TODO: remove pandas
    default_locales = _get_default_locales_data()

    supplied_locale = _match_locale_case(
        supplied_locale,
        _get_locales_list() + [entry["default_locale"] for entry in default_locales],
    )

    matches = [
        entry["base_locale"]
        for entry in default_locales
        if entry["default_locale"] == supplied_locale
    ]

    if matches:
        return matches[0]

    try:
        babel.Locale.parse(supplied_locale, sep="-")
    except babel.UnknownLocaleError:
        raise ValueError(
            f"Supplied locale `{supplied_locale}` is not a known locale. "
            "Great Tables uses the libraries like babel for locale-based work. "
            "See the babel.Locale class for more on locale handling."
        )

    return supplied_locale


def _resolve_locale(x: GTData | None, locale: str | None = None) -> str | None:
    if x is None and locale is None:
        return None

    # Get the locale from the locale value set globally; note that this may also be None
    # but a None value will eventually be resolved to the 'en' locale
    locale = x._locale._locale if locale is None else locale

    # An 'undetermined' locale should map back to the 'en' locale
    if locale == "und":
        locale = "en"

    # TODO: why do both the normalize and validate functions convert
    # underscores to hyphens? Should we remove from validate locale?
    _validate_locale(locale=locale)
    locale = _normalize_locale(locale=locale)

    return locale


def _get_locale_currency_code(locale: str | None = None) -> str:
    """
    Given a locale, returns the corresponding currency code. If no locale is provided,
    returns the currency code for the United States ('USD').

    Args:
        locale (str or None): A string representing the locale for which to retrieve the
            currency code. If None, the currency code for the United States ('USD') is returned.

    Returns:
        str: A string representing the currency code for the specified locale.

    Raises:
        TypeError: If the currency code is not a string.

    """

    # If `locale` is None then return `"USD"`
    if locale is None:
        return "USD"

    # Get the correct 'locale' value row from the `__x_locales` lookup table
    pd_df_row = _filter_pd_df_to_row(pd_df=_get_locales_data(), column="locale", filter_expr=locale)

    # Extract the 'currency_code' cell value from this 1-row DataFrame
    currency_code = pd_df_row["currency_code"]

    # Ensure that `currency_code` is of the type 'str'
    # TODO: we control this data and should enforce this in the data schema
    currency_code: Any
    if not isinstance(currency_code, str):  # pragma: no cover
        raise TypeError("Variable type mismatch. Expected str, got something entirely different.")

    # If the field isn't populated, we'll obtain an empty string; in such a case we fall
    # back to using the 'USD' currency code
    if currency_code == "":
        currency_code = "USD"

    return currency_code


def _get_currency_str(currency: str) -> str:
    """
    Given a currency code, returns the corresponding currency symbol as a string.

    Args:
        currency (str): The currency code to look up.

    Returns:
        str: The currency symbol corresponding to the given currency code.

    Raises:
        TypeError: If the currency symbol is not of type 'str'.
    """

    # Get the correct 'curr_code' value row from the `__x_currencies` lookup table
    pd_df_row = _filter_pd_df_to_row(
        pd_df=_get_currencies_data(), column="curr_code", filter_expr=currency
    )

    # Extract the 'symbol' cell value from this 1-row DataFrame
    # TODO: remove pandas
    currency_str = pd_df_row["symbol"]

    # Ensure that `currency_str` is of the type 'str'
    # TODO: we control this data and should enforce this in our data schema
    currency_str: Any
    if not isinstance(currency_str, str):  # pragma: no cover
        raise TypeError("Variable type mismatch. Expected str, got something entirely different.")

    return currency_str


def _validate_currency(currency: str) -> None:
    """
    Validates if the provided currency is available in the list of supported currencies.

    Args:
    - currency (str): The currency code to validate

    Raises:
    - ValueError: If the `currency` provided isn't a valid one

    Returns:
    - None
    """

    # Get the currencies data
    codes = [entry["curr_code"] for entry in _get_currencies_data()]

    # Stop if the `currency` provided isn't a valid one
    # TODO: how do users know what currencies are supported?
    if currency not in codes:
        raise ValueError(
            f"The supplied currency `{currency}` is not in the list of supported currencies."
        )


def _get_currency_decimals(currency: str, decimals: int | None, use_subunits: bool) -> int:
    """
    Returns the number of decimal places to use for a given currency.

    If `decimals` is not None, it is returned. Otherwise, if `use_subunits` is True,
    the number of decimal places is determined by the currency's exponent. Otherwise,
    the number of decimal places is 0.

    Args:
        currency (str): The currency code.
        decimals (int | None): The number of decimal places to use, if specified.
        use_subunits (bool): Whether to use subunits for the currency.

    Returns:
        int: The number of decimal places to use.
    """

    # If `decimals` is not None, return it
    if decimals is not None:
        return decimals

    # If `decimals` is None, then we need to determine the number of decimal places
    if decimals is None and use_subunits:
        # Get the number of decimal places from the currency's exponent
        decimals = _get_currency_exponent(currency=currency)
    elif decimals is None and not use_subunits:
        # If `use_subunits` is False, then the number of decimal places is 0
        decimals = 0

    # Assert that `decimals` is not None and then return it
    assert decimals is not None
    return decimals


def _get_currency_exponent(currency: str) -> int:
    """
    Given a currency code, returns the exponent associated with that` currency.
    If the currency code is not found, returns 2 as a default value.

    Args:
        currency (str): The currency code to look up.

    Returns:
        int: The exponent associated with the currency code.
    """
    currencies = _get_currencies_data()

    # get the curr_code column from currencies df as a list
    matches = [entry["exponent"] for entry in currencies if entry["curr_code"] == currency]

    if not matches:
        # An unknown code uses the most common exponent (`fmt_currency()` validates the code
        # first, so this only applies to internal callers)
        return 2

    # The data is read as strings; some codes (e.g., `XAU` for gold) have no minor unit, which
    # is recorded as `NA` and means no decimal places (as in R gt)
    exponent = matches[0]

    return 0 if exponent == "NA" else int(exponent)


def _validate_n_sigfig(n_sigfig: int) -> None:
    """
    Validates the input for the number of significant figures.

    Args:
        n_sigfig (int): The number of significant figures to validate.

    Raises:
        ValueError: If the length of `n_sigfig` is not 1, or if the value is `None` or less than 1.
        TypeError: If the input for `n_sigfig` is not an integer.

    Returns:
        None
    """

    # Check that the input `n_sigfig` is a scalar value (not a list or tuple)
    if isinstance(n_sigfig, (list, tuple)):
        raise TypeError("Any input for `n_sigfig` must be a scalar value.")
    # Check that the input `n_sigfig` is not `None`
    if not isinstance(n_sigfig, int):
        raise TypeError("Any input for `n_sigfig` must be an integer.")
    # The value of `n_sigfig` must be greater than or equal to 1
    if n_sigfig < 1:
        raise ValueError("The value for `n_sigfig` must be greater than or equal to `1`.")


def _round_rhu(x: float, digits: int = 0) -> float:
    """
    Rounds a number using the 'Round-Half-Up' (R-H-U) algorithm.

    As in `round_gt()` from the R gt package, the absolute value is rounded and the sign is
    then restored, so halves are rounded away from zero (e.g., `-2.5` becomes `-3`).

    Args:
        x (float): The number to round.
        digits (int): The number of digits to round to.

    Returns:
        float: The rounded number.
    """

    # Multiply the absolute value by 10^digits to move the decimal point to the right (`x` is
    # converted to a float first since NumPy scalars, like `float32` values, don't support
    # `math.trunc()`)
    z = abs(float(x)) * 10**digits

    # Add 0.5 + 2.220446049250313e-16 to the number to ensure that the number is rounded up
    z += 0.5 + math.sqrt(2.220446049250313e-16)

    # Truncate the number to remove the decimal places
    z = math.trunc(z)

    # Divide the number by 10^digits to move the decimal point back to the original position
    z /= 10**digits

    # Restore the sign of the original number (a value that rounds to zero stays at 0.0)
    return -z if x < 0 and z != 0 else z


def _as_roman(x: int) -> str:
    """
    Converts an integer to a Roman numeral string.

    Args:
        x (int): The integer to convert.

    Returns:
        str: The Roman numeral string representation of the integer.
    """

    roman_key_value_list = [
        (1000, "M"),
        (900, "CM"),
        (500, "D"),
        (400, "CD"),
        (100, "C"),
        (90, "XC"),
        (50, "L"),
        (40, "XL"),
        (10, "X"),
        (9, "IX"),
        (5, "V"),
        (4, "IV"),
        (1, "I"),
    ]

    out = ""
    while x > 0:
        for i, r in roman_key_value_list:
            while x >= i:
                out += r
                x -= i
    return out


def _validate_case(case: str) -> None:
    """
    Validates the case argument for the `fmt_roman()` method.

    Args:
        case (str): The case argument to validate.

    Raises:
        ValueError: If the case argument is not 'upper' or 'lower'.
    """
    if case not in ("upper", "lower"):
        raise ValueError(f"The `case` argument must be either 'upper' or 'lower' (not '{case}').")


# The `year_week` date style: an ISO 8601 week date (e.g., `2000-W09`), written with the CLDR fields
# for the week-based year and the week of that year
_ISO_WEEK_PATTERN = "Y-'W'ww"


def _resolve_iso_week(format_str: str, x: date) -> str:
    """Replace the ISO week-date fields in a format string with their values for `x`.

    Babel numbers weeks by the locale's rules (e.g., in `en_US` weeks start on Sunday), so the
    `year_week` style is filled in with the ISO 8601 week-based year and week (weeks start on Monday
    and week 1 is the week containing the first Thursday of the year) before formatting, giving the
    same week in every locale.
    """

    if _ISO_WEEK_PATTERN not in format_str:
        return format_str

    iso_year, iso_week, _ = x.isocalendar()

    # Only the letter `W` needs quoting (digits and `-` are literals in a CLDR pattern); leaving the
    # value unquoted at both ends keeps it from merging with an adjacent quoted literal into `''`
    return format_str.replace(_ISO_WEEK_PATTERN, f"{iso_year:04d}-'W'{iso_week:02d}")


def _get_date_formats_dict() -> dict[str, str]:
    date_formats = {
        "iso": "yyyy-MM-dd",
        "wday_month_day_year": "EEEE, MMMM d, y",
        "wd_m_day_year": "EEE, MMM d, y",
        "wday_day_month_year": "EEEE d MMMM y",
        "month_day_year": "MMMM d, y",
        "m_day_year": "MMM d, y",
        "day_m_year": "d MMM y",
        "day_month_year": "d MMMM y",
        "day_month": "d MMMM",
        "day_m": "d MMM",
        "year": "y",
        "month": "MMMM",
        "day": "dd",
        "year.mn.day": "y/MM/dd",
        "y.mn.day": "yy/MM/dd",
        "year_week": _ISO_WEEK_PATTERN,
        "year_quarter": "y-'Q'Q",
    }

    return date_formats


def _get_time_formats_dict() -> dict[str, str]:
    time_formats = {
        "iso": "HH:mm:ss",
        "iso-short": "HH:mm",
        "h_m_s_p": "h:mm:ss a",
        "h_m_p": "h:mm a",
        "h_p": "h a",
    }

    return time_formats


# The flexible date and time styles are CLDR skeletons, which name the fields to show; each locale
# has its own pattern for a skeleton (e.g., `"yMd"` is `"M/d/y"` in `en` and `"d.M.y"` in `de`)
_FLEXIBLE_DATE_STYLES = (
    "yMd",
    "yMEd",
    "yMMM",
    "yMMMM",
    "yMMMd",
    "yMMMEd",
    "GyMd",
    "GyMMMd",
    "GyMMMEd",
    "yM",
    "Md",
    "MEd",
    "MMMd",
    "MMMEd",
    "MMMMd",
    "GyMMM",
    "yQQQ",
    "yQQQQ",
    "Gy",
    "y",
    "M",
    "MMM",
    "d",
    "Ed",
)
_FLEXIBLE_TIME_STYLES = (
    "Hms",
    "Hm",
    "H",
    "EHm",
    "EHms",
    "Hmsv",
    "Hmv",
    "hms",
    "hm",
    "h",
    "Ehm",
    "Ehms",
    "EBhms",
    "Bhms",
    "EBhm",
    "Bhm",
    "Bh",
    "hmsv",
    "hmv",
    "ms",
)


def _get_date_format(date_style: str, locale: str | None) -> str:
    """
    Get the CLDR date pattern for a date style in a locale.

    Args:
        date_style (str): The style of the date.
        locale (str | None): The locale, which gives the pattern for a flexible date style.

    Returns:
        str: The date format string.

    Raises:
        ValueError: If `date_style` does not have a valid value.
    """

    # Stop if `date_style` does not have a valid value
    _validate_date_style(date_style=date_style)

    if date_style in _FLEXIBLE_DATE_STYLES:
        return _get_babel_locale(locale).datetime_skeletons[date_style].pattern

    return _get_date_formats_dict()[date_style]


def _get_time_format(time_style: str, locale: str | None) -> str:
    """
    Get the CLDR time pattern for a time style in a locale.

    Args:
        time_style (str): The style of the time format.
        locale (str | None): The locale, which gives the pattern for a flexible time style.

    Returns:
        str: The time format string.

    Raises:
        ValueError: If `time_style` does not have a valid value.
    """

    # Stop if `time_style` does not have a valid value
    _validate_time_style(time_style=time_style)

    if time_style in _FLEXIBLE_TIME_STYLES:
        return _get_babel_locale(locale).datetime_skeletons[time_style].pattern

    return _get_time_formats_dict()[time_style]


@cache
def _get_babel_locale(locale: str | None) -> babel.Locale:
    """
    Get the Babel `Locale` for a locale from `_resolve_locale()` (where `None` is `en_US`).

    It's cached, so that formatting each value doesn't parse the locale again.
    """
    if locale is None:
        locale = "en_US"

    return babel.Locale.parse(_str_replace(locale, "-", "_"))


# A CLDR pattern is made of unquoted text, where every ASCII letter is a field, and quoted literal
# text (`'...'`, where `''` is a single quote); the last alternative is an unterminated quote
_CLDR_PATTERN_PARTS = re.compile(r"'[^']*'|[^']+|'[^']*$")

# The letters of the CLDR fields for parts of the date (the others are for the time and the zone)
_CLDR_DATE_FIELDS = frozenset("GyYuQqMLwWdDFgEec")


def _unquoted_cldr_text(pattern: str) -> str:
    """Get the unquoted text of a CLDR pattern (i.e., its fields and any punctuation)."""
    return "".join(part for part in _CLDR_PATTERN_PARTS.findall(pattern) if part[0] != "'")


def _validate_cldr_pattern(pattern: str) -> None:
    """
    Stop if the CLDR pattern given to `format_str=` can't be formatted as written.

    Babel raises for a field of an invalid length (e.g., `EEEEEEE`), but it silently drops the
    text after an unterminated quote and shows letters that aren't fields (e.g., `j`) as is.
    """

    for part in _CLDR_PATTERN_PARTS.findall(pattern):
        if part[0] == "'" and (len(part) == 1 or part[-1] != "'"):
            raise ValueError(
                f"The `format_str=` pattern {pattern!r} has an unterminated quote. Literal text is "
                "quoted with `'` (e.g., `\"h 'o''clock' a\"`), where `''` is a single quote."
            )

    unknown = sorted(
        {
            char
            for char in _unquoted_cldr_text(pattern)
            if char.isascii() and char.isalpha() and char not in PATTERN_CHARS
        }
    )

    if unknown:
        raise ValueError(
            f"The `format_str=` pattern {pattern!r} has letters that aren't CLDR date or time "
            f"fields ({', '.join(f'`{char}`' for char in unknown)}). Literal text is quoted with "
            "`'` (e.g., `\"d MMMM 'at' h a\"`)."
        )

    try:
        parse_pattern(pattern)
    except ValueError as e:
        raise ValueError(f"The `format_str=` pattern {pattern!r} isn't valid: {e}") from None


def _split_cldr_pattern(pattern: str) -> list[tuple[str, bool]]:
    """
    Split a CLDR pattern into its unquoted text and its literal text, as `(text, is_literal)`
    pairs, where the literal text has its quotes removed (e.g., `"h 'o''clock' a"` gives
    `[("h ", False), ("o'clock", True), (" a", False)]`).
    """

    parts = []
    i = 0

    while i < len(pattern):
        if pattern[i] != "'":
            end = pattern.find("'", i)
            end = len(pattern) if end == -1 else end
            parts.append((pattern[i:end], False))
            i = end

        elif pattern.startswith("''", i):
            # A quote outside quoted text
            parts.append(("'", True))
            i += 2

        else:
            # Quoted text, where `''` is a quote; it ends at the next lone quote
            text = []
            i += 1
            while i < len(pattern):
                if pattern.startswith("''", i):
                    text.append("'")
                    i += 2
                elif pattern[i] == "'":
                    i += 1
                    break
                else:
                    text.append(pattern[i])
                    i += 1
            parts.append(("".join(text), True))

    return parts


def _join_cldr_pattern(parts: list[tuple[str, bool]]) -> str:
    """Join the parts from `_split_cldr_pattern()` into a CLDR pattern, quoting the literal text."""

    pattern = []
    literal = []

    # Adjacent literal parts are quoted together (`'a''b'` would be the text `a'b`); Babel reads
    # each `''` as a quote before it looks for the quoted text, so text made only of quotes can't
    # be quoted (`''''` would be two quotes) and is written as one `''` per quote
    def append_literal():
        literal_text = "".join(literal)
        literal.clear()

        if literal_text.strip("'"):
            pattern.append("'" + literal_text.replace("'", "''") + "'")
        else:
            pattern.append(literal_text.replace("'", "''"))

    for text, is_literal in parts:
        if is_literal:
            literal.append(text)
        elif text:
            append_literal()
            pattern.append(text)

    append_literal()

    return "".join(pattern)


# The fields that Babel can't format: the short localized GMT format (`O`) and the modified Julian
# day (`g`); `OOOO` is left to Babel
_CLDR_FIELDS_FILLED_IN = re.compile(r"(?<!O)O(?!O)|g+")

# The day that the modified Julian day counts from
_MJD_EPOCH_ORDINAL = date(1858, 11, 17).toordinal()


def _fill_in_cldr_fields(pattern: str, x: datetime | time, locale: str | None) -> str:
    """Replace the fields of a CLDR pattern that Babel can't format with their values for `x`."""

    parts = []

    for text, is_literal in _split_cldr_pattern(pattern):
        if is_literal:
            parts.append((text, True))
            continue

        end = 0
        for cldr_field in _CLDR_FIELDS_FILLED_IN.finditer(text):
            parts.append((text[end : cldr_field.start()], False))
            parts.append((_format_cldr_field(cldr_field.group(), x, locale), True))
            end = cldr_field.end()
        parts.append((text[end:], False))

    return _join_cldr_pattern(parts)


def _format_cldr_field(field: str, x: datetime | time, locale: str | None) -> str:
    """Format the `O` (e.g., `"GMT-5"`) or the `g` (e.g., `"51603"`) field of a CLDR pattern."""

    if field == "O":
        # The short localized GMT format: the hours without a leading zero, and the minutes (and
        # seconds) only when they aren't zero; a naive value is in UTC, as elsewhere in Babel
        offset = x.utcoffset() or timedelta(0)
        gmt_format = _get_babel_locale(locale).zone_formats["gmt"]

        if not offset:
            # CLDR's `gmtZeroFormat` (e.g., `"GMT"`, `"UTC"` in `fr`), which Babel doesn't have; it
            # is the GMT format without an offset (some keep a direction mark, e.g., in `he`)
            return (gmt_format % "").strip(" \u200e\u200f")

        sign = "-" if offset < timedelta(0) else "+"
        minutes, seconds = divmod(int(abs(offset).total_seconds()), 60)
        hours, minutes = divmod(minutes, 60)

        offset_str = f"{sign}{hours}"
        if minutes or seconds:
            offset_str += f":{minutes:02d}"
        if seconds:
            offset_str += f":{seconds:02d}"

        return gmt_format % offset_str

    # The modified Julian day of the date (days since 1858-11-17), zero-padded to the field's length
    # (a time without a date is rejected before formatting, as for the other date fields)
    days = x.toordinal() - _MJD_EPOCH_ORDINAL
    sign = "-" if days < 0 else ""

    return f"{sign}{abs(days):0{len(field)}d}"


def _has_generic_zone_name(x: datetime | time) -> bool:
    """
    Check whether the time zone of a value has a generic name (e.g., "ET" for `America/New_York`).

    The zones without one include those of naive values (formatted as UTC), fixed offsets, and the
    `Etc/*` zones; Babel names them as "Unknown Region (UTC) Time" and the like.
    """
    zone = getattr(x.tzinfo, "zone", None) or getattr(x.tzinfo, "key", None)
    zone = get_global("zone_aliases").get(zone, zone)

    return get_global("zone_territories").get(zone, "ZZ") != "ZZ"


# The generic zone names (`v`, `vvvv`) and the generic location format (`V`, `VVVV`; Babel gives
# names like "ET" and "United States (New York) Time"); `VV` (the zone ID) and `VVV` (the city) work
_GENERIC_ZONE_FIELDS = re.compile(r"(?<!V)(?:VVVV|V)(?!V)|v+")


@dataclass(frozen=True)
class _DatetimePattern:
    """A CLDR pattern for formatting times or datetimes, prepared once per formatting call."""

    pattern: str
    # The pattern with its generic zone names (`v` and `V`, e.g., "ET") written as specific ones
    # (`z`, e.g., "EST"), for the values whose zone has no generic name; `None` if there are none
    zone_fallback: str | None
    # Whether the pattern shows part of the date (e.g., the weekday), which a time doesn't have
    has_date_fields: bool
    # Whether the pattern has fields that Babel can't format (`O` and `g`), which are filled in
    has_filled_in_fields: bool

    @classmethod
    def from_pattern(cls, pattern: str) -> _DatetimePattern:
        parts = _split_cldr_pattern(pattern)
        # The fields are found in each unquoted part (`O'x'O` has two `O` fields, not an `OO`)
        unquoted_parts = [text for text, is_literal in parts if not is_literal]

        zone_fallback = None
        if any(_GENERIC_ZONE_FIELDS.search(text) for text in unquoted_parts):
            zone_fallback = _join_cldr_pattern(
                [
                    (
                        text
                        if is_literal
                        else _GENERIC_ZONE_FIELDS.sub(lambda m: "z" * len(m.group()), text),
                        is_literal,
                    )
                    for text, is_literal in parts
                ]
            )

        return cls(
            pattern=pattern,
            zone_fallback=zone_fallback,
            has_date_fields=not _CLDR_DATE_FIELDS.isdisjoint("".join(unquoted_parts)),
            has_filled_in_fields=any(
                _CLDR_FIELDS_FILLED_IN.search(text) for text in unquoted_parts
            ),
        )

    def for_value(self, x: datetime | time, locale: str | None) -> str:
        """Get the pattern that Babel formats `x` with."""

        pattern = self.pattern
        if self.zone_fallback is not None and not _has_generic_zone_name(x):
            pattern = self.zone_fallback

        if self.has_filled_in_fields:
            pattern = _fill_in_cldr_fields(pattern, x, locale)

        return pattern


def _validate_date_style(date_style: str) -> None:
    """
    Validates the given date style.

    Args:
        date_style (str): The date style to be validated.

    Raises:
        ValueError: If `date_style` is not a valid value.

    Returns:
        None
    """
    date_styles = [*_get_date_formats_dict(), *_FLEXIBLE_DATE_STYLES]

    if date_style not in date_styles:
        raise ValueError(f"date_style must be one of: {', '.join(date_styles)}")


def _validate_time_style(time_style: str) -> None:
    """
    Validate the time style.

    Args:
        time_style (str): The time style to validate.

    Raises:
        ValueError: If `time_style` is not a valid value.

    Returns:
        None
    """
    time_styles = [*_get_time_formats_dict(), *_FLEXIBLE_TIME_STYLES]

    if time_style not in time_styles:
        raise ValueError(f"time_style must be one of: {', '.join(time_styles)}")


def _iso_str_to_time(x: str) -> time | datetime:
    """
    Converts a string in ISO format to a time object (or a datetime object).

    The string can be a time (`HH:MM:SS`) or a datetime (`YYYY-MM-DD HH:MM:SS`), which is kept as a
    datetime so that a time style showing the weekday can be used. A date without a time
    (`YYYY-MM-DD`) is rejected rather than read as midnight.

    Args:
        x (str): The string to be converted.

    Returns:
        time | datetime: The converted time (or datetime) object.
    """
    try:
        return time.fromisoformat(x)
    except ValueError as e:
        time_error = e

    # A date in a time column is more likely a mistake than midnight
    try:
        date.fromisoformat(x)
    except ValueError:
        pass
    else:
        raise ValueError(
            f"Invalid time string: '{x}' is a date without a time. Use `fmt_date()` to format dates."
        )

    try:
        return datetime.fromisoformat(x)
    except ValueError:
        # The string is neither a time nor a datetime, so report the error for a time string
        raise time_error from None


def _iso_str_to_datetime(x: str) -> datetime:
    """
    Converts a string in ISO format to a datetime object.

    Args:
        x (str): The string to be converted.

    Returns:
        datetime: The converted datetime object.
    """
    return datetime.fromisoformat(x)


def _iso_str_to_date(x: str) -> date:
    """
    Converts a string in ISO format to a date object.

    Args:
        x (str): The string to be converted.

    Returns:
        date: The converted date object.
    """
    return datetime.fromisoformat(x).date()


def _validate_date_obj(x: Any) -> None:
    """
    Validate if the given object is a valid date object.

    Args:
        x (Any): The object to be validated.

    Raises:
        ValueError: If the object is not a valid date object.

    Returns:
        None
    """
    if not isinstance(x, date):
        raise ValueError(f"Invalid date object: '{x}'. The object must be a date object.")


def _validate_time_obj(x: Any) -> None:
    """
    Validate if the given object is a valid time object.

    Args:
        x (Any): The object to be validated.

    Raises:
        ValueError: If the object is not a valid time object.

    Returns:
        None
    """
    if not isinstance(x, time):
        raise ValueError(f"Invalid time object: '{x}'. The object must be a time object.")


def _validate_datetime_obj(x: Any) -> None:
    """
    Validate if the given object is a valid datetime object.

    Args:
        x (Any): The object to be validated.

    Raises:
        ValueError: If the object is not a valid datetime object.

    Returns:
        None
    """
    if not isinstance(x, datetime):
        raise ValueError(f"Invalid datetime object: '{x}'. The object must be a datetime object.")


def fmt_image(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    height: str | int | None = None,
    width: str | int | None = None,
    sep: str = " ",
    path: str | Path | None = None,
    file_pattern: str = "{}",
    encode: bool = True,
    alt: str | FromColumn | None = None,
) -> GTSelf:
    """Format image paths to generate images in cells.

    To more easily insert graphics into body cells, we can use the
    [`fmt_image()`](`great_tables.GT.fmt_image`) method. This allows for one or more images to be
    placed in the targeted cells. The cells need to contain some reference to an image file, either:
    (1) local paths to the files; (2) complete http/https to the files; (3) the file names, where a
    common path can be provided via `path=`; or (4) a fragment of the file name, where the
    `file_pattern=` argument helps to compose the entire file name and `path=` provides the path
    information. This should be expressly used on columns that contain *only* references to image
    files (i.e., no image references as part of a larger block of text). Multiple images can be
    included per cell by separating image references by commas. The `sep=` argument allows for a
    common separator to be applied between images.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    height
        The height of the rendered images.
    width
        The width of the rendered images.
    sep
        In the output of images within a body cell, `sep=` provides the separator between each
        image.
    path
        An optional path to local image files or an HTTP/HTTPS URL.
        This is combined with the filenames to form the complete image paths.
    file_pattern
        The pattern to use for mapping input values in the body cells to the names of the graphics
        files. The string supplied should use `"{}"` in the pattern to map filename fragments to
        input strings.
    encode
        The option to always use Base64 encoding for image paths that are determined to be local. By
        default, this is `True`.
    alt
        Alternative text for the images, which screen readers announce in place of an image. This
        can be a string, in which `{x}` is replaced by the image's reference in the cell (e.g.,
        `"Logo of {x}"`), or [`from_column()`](`great_tables.from_column`) to take each row's text
        from a column. By default, images get an empty `alt=""`, which marks them as decorative so
        that screen readers skip them; provide alternative text whenever an image conveys
        information that isn't also in the table as text.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Using a small portion of `metro` dataset, let's create a new table. We will only include a few
    columns and rows from that table. The `lines` column has comma-separated listings of numbers
    corresponding to lines served at each station. We have a directory of SVG graphics for all of
    these lines in the package (the path for the image directory can be accessed via
    `files("great_tables") / "data/metro_images"`, using the `importlib_resources` package). The
    filenames roughly corresponds to the data in the `lines` column. The
    [`fmt_image()`](`great_tables.GT.fmt_image`) method can be used with these inputs since the
    `path=` and `file_pattern=` arguments allow us to compose complete and valid file locations.
    What you get from this are sequences of images in the table cells, taken from the referenced
    graphics files on disk.

    ```{python}
    from great_tables import GT
    from great_tables.data import metro
    from importlib_resources import files

    img_paths = files("great_tables") / "data/metro_images"

    metro_mini = metro[["name", "lines", "passengers"]].head(5)

    (
        GT(metro_mini)
        .fmt_image(
            columns="lines",
            path=img_paths,
            file_pattern="metro_{}.svg"
        )
        .fmt_integer(columns="passengers")
    )
    ```
    """

    # TODO: most parameter options should allow a polars expression (or from_column) ----
    # can other fmt functions do this kind of thing?
    expr_cols = [height, width, sep, path, file_pattern, encode]

    if any(isinstance(x, PlExpr) for x in expr_cols):
        raise NotImplementedError(
            "fmt_image currently does not support polars expressions for arguments other than"
            " columns and rows"
        )

    if height is None and width is None:
        height = "2em"

    def format_images(gt: GTSelf, alt_text: str | None, rows: RowSelectExpr) -> GTSelf:
        formatter = FmtImage(
            gt._tbl_data, height, width, sep, path, file_pattern, encode, alt=alt_text
        )
        return fmt(
            gt,
            fns=FormatFns(
                html=formatter.to_html, latex=formatter.to_latex, default=formatter.to_html
            ),
            columns=columns,
            rows=rows,
        )

    if not isinstance(alt, FromColumn):
        return format_images(self, alt, rows)

    # With `from_column()`, each row's alternative text comes from a column: the rows are
    # grouped by their text, and each group is formatted with it
    alt_values = to_list(self._tbl_data[alt.column])
    rows_by_alt: dict[str, list[int]] = {}
    for _, row in resolve_rows_i(self, rows):
        value = alt_values[row]
        if is_na(self._tbl_data, value):
            text = ""
        else:
            text = str(alt.fn(value) if alt.fn is not None else value)
        rows_by_alt.setdefault(text, []).append(row)

    res = self
    for text, alt_rows in rows_by_alt.items():
        res = format_images(res, text, alt_rows)
    return res


@dataclass
class FmtImage:
    dispatch_on: DataFrameLike | Agnostic = field(default_factory=Agnostic)
    height: str | int | None = None
    width: str | int | None = None
    sep: str = " "
    path: str | Path | None = None
    file_pattern: str = "{}"
    encode: bool = True
    # Alternative text, with `{x}` replaced by each image's reference in the cell (an empty `alt`
    # marks the image as decorative)
    alt: str | None = None

    SPAN_TEMPLATE: ClassVar = '<span style="white-space:nowrap;">{}</span>'

    def to_html(self, val: Any):
        # TODO: are we assuming val is a string? (or coercing?)

        # otherwise...

        if is_na(self.dispatch_on, val):
            return val

        files = re.split(r",\s*", val) if "," in val else [val]

        # TODO: if we allowing height and width to be set based on column values, then
        # they could end up as bespoke types like np int64, etc..
        # We should ensure we process those before hitting FmtImage
        height = px(self.height) if isinstance(self.height, (int, float)) else self.height

        # TODO: note that only height can be numeric in the R program. Is this on purpose?
        # In any event, raising explicitly for numeric width below.
        if isinstance(self.width, (int, float)):
            raise NotImplementedError("The width argument must be specified as a string.")

        full_files = self._apply_pattern(self.file_pattern, files)

        out: list[str] = []
        for file_ref, file in zip(files, full_files):
            # Case 1: from url via `dispatch_on`
            if self.path is None and is_valid_http_schema(file):
                uri = file.rstrip().removesuffix("/")
            # Case 2: from url via `path`
            elif self.path is not None and is_valid_http_schema(str(self.path)):
                norm_path = str(self.path).rstrip().removesuffix("/")
                uri = f"{norm_path}/{file}"
            # Case 3:
            else:
                filename = str((Path(self.path or "") / file).expanduser().absolute())

                uri = self._get_image_uri(filename) if self.encode else filename

            # TODO: do we have a way to create tags, that is good at escaping, etc..?
            alt_text = "" if self.alt is None else self.alt.replace("{x}", file_ref)
            out.append(self._build_img_tag(uri, height, self.width, alt=alt_text))

        img_tags = self.sep.join(out)
        span = self.SPAN_TEMPLATE.format(img_tags)

        return span

    def to_latex(self, val: Any):
        from warnings import warn

        from ._gt_data import FormatterSkipElement

        warn("fmt_image() is not currently implemented in LaTeX output.")

        return FormatterSkipElement()

    @staticmethod
    def _apply_pattern(file_pattern: str, files: list[str]) -> list[str]:
        return [file_pattern.format(file) for file in files]

    @classmethod
    def _get_image_uri(cls, filename: str) -> str:
        import base64

        with open(filename, "rb") as f:
            encoded = base64.b64encode(f.read()).decode()

        mime_type = cls._get_mime_type(filename)

        return f"data:{mime_type};base64,{encoded}"

    @staticmethod
    def _get_mime_type(filename: str) -> str:
        # note that we strip off the leading "."
        suffix = Path(filename).suffix[1:]

        if suffix == "svg":
            return "image/svg+xml"
        elif suffix == "jpg":
            return "image/jpeg"

        return f"image/{suffix}"

    @staticmethod
    def _build_img_tag(
        uri: str, height: str | None = None, width: str | None = None, alt: str = ""
    ) -> str:
        style_string = "".join(
            [
                f"height: {height};" if height is not None else "",
                f"width: {width};" if width is not None else "",
                "vertical-align: middle;",
            ]
        )

        return f'<img src="{uri}" alt="{html.escape(alt)}" style="{style_string}">'


def fmt_icon(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    height: str | None = None,
    sep: str = " ",
    stroke_color: str | None = None,
    stroke_width: str | int | None = None,
    stroke_alpha: float | None = None,
    fill_color: str | dict[str, str] | None = None,
    fill_alpha: float | None = None,
    margin_left: str | None = None,
    margin_right: str | None = None,
) -> GTSelf:
    """Use icons within a table's body cells.

    We can draw from a library of thousands of icons and selectively insert them into a table. The
    `fmt_icon()` method makes this possible by mapping input cell labels to an icon name. We are
    exclusively using Font Awesome (version 7) icons here so the reference is the short icon name
    (e.g., `"star"`). Some icons come in both a regular and a solid style, and for these the
    regular icon is used; a full name like `"fas fa-star"` (or `"far fa-star"`) can be given to
    choose the style. Earlier names for icons are also accepted (e.g., `"user-large"` gives the
    `"user"` icon). Multiple icons can be included per cell by separating icon names with commas
    (e.g., `"hard-drive,clock"`). The `sep=` argument allows for a common separator to be applied
    between icons.

    The icon data is included in Great Tables, so icons are generated without any web requests.
    Font Awesome Free icons are licensed under CC BY 4.0 (<https://fontawesome.com/license/free>).

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    height
        The absolute height of the icon in the table cell. By default, this is set to "1em".
    sep
        In the output of icons within a body cell, `sep=` provides the separator between each icon.
    stroke_color
        The icon stroke is essentially the outline of the icon. The color of the stroke can be
        modified by applying a single color here. If not provided then no stroke is drawn.
    stroke_width
        The `stroke_width=` option allows for setting the color of the icon outline stroke. By
        default, the stroke width is very small at "1px" so a size adjustment here can sometimes be
        useful. If an integer value is provided then it is assumed to be in pixels.
    stroke_alpha
        The level of transparency for the icon stroke can be controlled with a decimal value between
        `0` and `1`.
    fill_color
        The fill color of the icon can be set with `fill_color=`; providing a single color here will
        change the color of the fill but not of the icon's 'stroke' or outline (use `stroke_color=`
        to modify that). A dictionary comprising the icon names with corresponding fill colors can
        alternatively be used here (e.g., `{"circle-check" = "green", "circle-xmark" = "red"}`. If
        nothing is provided then the default value of `"currentColor"` is applied so that the fill
        matches the color of the parent HTML element's color attribute.
    fill_alpha
        The level of transparency for the icon fill can be controlled with a decimal value between
        `0` and `1`.
    margin_left
        The length value for the margin that's to the left of the icon. By default, `"auto"` is
        used for this but if space is needed on the left-hand side then a length of `"0.2em"` is
        recommended as a starting point.
    margin_right
        The length value for the margin right of the icon. By default, `"auto"` is used but if
        space is needed on the right-hand side then a length of `"0.2em"` is recommended as a
        starting point.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    For this first example of generating icons with `fmt_icon()`, let's make a simple DataFrame that
    has two columns of Font Awesome icon names. We separate multiple icons per cell with commas. By
    default, the icons are 1 em in height; we're going to make the icons slightly larger here (so we
    can see the fine details of them) by setting height = "4em".

    ```{python}
    import pandas as pd
    from great_tables import GT

    animals_foods_df = pd.DataFrame(
        {
            "animals": ["hippo", "fish,spider", "mosquito,locust,frog", "dog,cat", "kiwi-bird"],
            "foods": ["bowl-rice", "egg,pizza-slice", "burger,lemon,cheese", "carrot,hotdog", "bacon"],
        }
    )

    (
        GT(animals_foods_df)
        .fmt_icon(
            columns=["animals", "foods"],
            height="4em"
        )
        .cols_align(
            align="center",
            columns=["animals", "foods"]
        )
    )
    ```

    Let's take a few rows from the towny dataset and make it so the `csd_type` column contains
    *Font Awesome* icon names (we want only the `"city"` and `"house-chimney"` icons here). After
    using `fmt_icon()` to format the `csd_type` column, we get icons that are representative of the
    two categories of municipality for this subset of data.

    ```{python}
    import polars as pl
    from great_tables import data

    towny_mini = (
        data.pl.towny[[323, 14, 26, 235]]
        .select(["name", "csd_type", "population_2021"])
        .with_columns(
           csd_type = pl.when(pl.col("csd_type") == "town")
           .then(pl.lit("house-chimney"))
           .otherwise(pl.lit("city"))
        )
    )

    (
       GT(towny_mini)
       .fmt_integer(columns="population_2021")
       .fmt_icon(columns="csd_type")
       .cols_label(
           csd_type="",
           name="City/Town",
           population_2021="Population"
       )
    )
    ```

    A fairly common thing to do with icons in tables is to indicate whether a quantity is either
    higher or lower than another. Up and down arrow symbols can serve as good visual indicators for
    this purpose. We can make use of the `"up-arrow"` and `"down-arrow"` icons here. As those
    strings are available in the `dir` column of the table derived from the `sp500` dataset,
    `fmt_icon()` can be used. We set the `fill_color` argument with a dictionary that indicates
    which color should be used for each icon.

    ```{python}
    from great_tables import data

    sp500_mini = (
        data.pl.sp500
        .head(10)
        .select(["date", "open", "close"])
        .sort("date", descending=False)
        .with_columns(
            dir = pl.when(pl.col("close") >= pl.col("open")).then(
                pl.lit("arrow-up")).otherwise(pl.lit("arrow-down"))
        )
    )

    (
        GT(sp500_mini, rowname_col="date")
        .fmt_icon(
            columns="dir",
            fill_color={"arrow-up": "green", "arrow-down": "red"}
        )
        .cols_label(
            open="Opening Value",
            close="Closing Value",
            dir=""
        )
        .opt_stylize(style=1, color="gray")
    )
    ```
    """

    formatter = FmtIcon(
        self._tbl_data,
        height=height,
        sep=sep,
        stroke_color=stroke_color,
        stroke_width=stroke_width,
        stroke_alpha=stroke_alpha,
        fill_color=fill_color,
        fill_alpha=fill_alpha,
        margin_left=margin_left,
        margin_right=margin_right,
    )

    return fmt(
        self,
        fns=FormatFns(html=formatter.to_html, latex=formatter.to_latex, default=formatter.to_html),
        columns=columns,
        rows=rows,
    )


@dataclass
class FmtIcon:
    dispatch_on: DataFrameLike | Agnostic = field(default_factory=Agnostic)
    height: str | None = None
    sep: str = " "
    stroke_color: str | None = None
    stroke_width: str | int | float | None = None
    stroke_alpha: float | None = None
    fill_color: str | dict[str, str] | None = None
    fill_alpha: float | None = None
    margin_left: str | None = None
    margin_right: str | None = None

    SPAN_TEMPLATE: ClassVar = '<span style="white-space:nowrap;">{}</span>'

    def to_html(self, val: Any):
        if is_na(self.dispatch_on, val):
            return val

        icon_list = re.split(r",\s*", val) if "," in val else [val]

        height = "1em" if self.height is None else self.height

        if self.stroke_width is None:
            stroke_width = "1px"
        elif isinstance(self.stroke_width, (int, float)):
            stroke_width = f"{self.stroke_width}px"
        else:
            stroke_width = self.stroke_width

        out: list[str] = []

        for icon in icon_list:
            if isinstance(self.fill_color, dict):
                fill_color = self.fill_color.get(icon, None)
            else:
                fill_color = self.fill_color

            icon_svg = fa_svg(
                icon,
                height=height,
                stroke=self.stroke_color,
                stroke_width=stroke_width,
                stroke_opacity=self.stroke_alpha,
                fill=fill_color,
                fill_opacity=self.fill_alpha,
                margin_left=self.margin_left,
                margin_right=self.margin_right,
            )

            out.append(icon_svg)

        img_tags = self.sep.join(out)
        span = self.SPAN_TEMPLATE.format(img_tags)

        return span

    def to_latex(self, val: Any):
        from warnings import warn

        from ._gt_data import FormatterSkipElement

        warn("fmt_icon() is not currently implemented in LaTeX output.")

        return FormatterSkipElement()


def fmt_flag(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    height: str | float | None = "1em",
    sep: str = " ",
    use_title: bool = True,
) -> GTSelf:
    """Generate flag icons for countries from their country codes.

    While it is fairly straightforward to insert images into body cells (using
    [`fmt_image()`](`great_tables.GT.fmt_image`) is one way to it), there is often the need to
    incorporate specialized types of graphics within a table. One such group of graphics involves
    iconography representing different countries, and the `fmt_flag()` method helps with inserting a
    flag icon (or multiple) in body cells. To make this work seamlessly, the input cells need to
    contain some reference to a country, and this can be in the form of a 2- or 3-letter ISO 3166-1
    country code (e.g., Egypt has the `"EG"` country code). This method will parse the targeted body
    cells for those codes and insert the appropriate flag graphics.

    Multiple flags can be included per cell by separating country codes with commas (e.g.,
    `"GB,TT"`). The `sep=` argument allows for a common separator to be applied between flag icons.

    Any code that isn't recognized as a 2- or 3-letter country code is left as is (i.e., the text
    is retained in place of a flag icon). This means that a column with a mix of valid and invalid
    codes can still be formatted, and the cells without flags can be identified and styled
    separately (e.g., with `tab_style()`).

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    height
        The height of the flag icons. The default value is `"1em"`. If given as a number, it is
        assumed to be in pixels.
    sep
        In the output of multiple flag icons within a body cell, `sep=` provides the separator
        between each of the flag icons.
    use_title
        The option to include a title attribute with the country name when hovering over the flag
        icon. The default is `True`.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Let's use the `countrypops` dataset to create a new table with flag icons. We will only include
    a few columns and rows from that table. The `country_code_2` column has 2-letter country codes
    in the format required for `fmt_flag()` and using that method transforms the codes to circular
    flag icons.

    ```{python}
    from great_tables import GT, data
    import polars as pl

    countrypops_mini = (
        data.pl.countrypops
        .filter(pl.col("year") == 2021)
        .filter(pl.col("country_name").str.starts_with("S"))
        .sort("country_name")
        .head(10)
        .drop(["year", "country_code_3"])
    )

    (
        GT(countrypops_mini)
        .fmt_integer(columns="population")
        .fmt_flag(columns="country_code_2")
        .cols_label(
            country_code_2="",
            country_name="Country",
            population="Population (2021)"
        )
        .cols_move_to_start(columns="country_code_2")
    )
    ```

    Here's another example (again using `countrypops`) where we generate a table providing
    populations every five years for the Benelux countries (`"BEL"`, `"NLD"`, and `"LUX"`). After
    some filtering and a pivot, the `fmt_flag()` method is used to obtain flag icons from 3-letter
    country codes present in the `country_code_3` column.

    ```{python}
    import polars.selectors as cs

    countrypops_mini = (
        data.pl.countrypops
        .filter(pl.col("country_code_3").is_in(["BEL", "NLD", "LUX"]))
        .filter((pl.col("year") % 10 == 0) & (pl.col("year") >= 1960))
        .pivot("year", index = ["country_code_3", "country_name"], values="population")
    )

    (
        GT(countrypops_mini)
        .tab_header(title="Populations of the Benelux Countries")
        .tab_spanner(label="Year", columns=cs.numeric())
        .fmt_integer(columns=cs.numeric())
        .fmt_flag(columns="country_code_3")
        .cols_label(
            country_code_3="",
            country_name="Country"
        )
    )
    ```
    """

    formatter = FmtFlag(self._tbl_data, height=height, sep=sep, use_title=use_title)

    return fmt(
        self,
        fns=FormatFns(html=formatter.to_html, latex=formatter.to_latex, default=formatter.to_html),
        columns=columns,
        rows=rows,
    )


@dataclass
class FmtFlag:
    dispatch_on: DataFrameLike | Agnostic = field(default_factory=Agnostic)
    height: str | int | float | None = None
    sep: str = " "
    use_title: bool = True

    SPAN_TEMPLATE: ClassVar = '<span style="white-space:nowrap;">{}</span>'

    def to_html(self, val: Any):
        if is_na(self.dispatch_on, val):
            return val

        flag_list = re.split(r",\s*", val) if "," in val else [val]

        if self.height is None:
            height = "1em"
        else:
            height = self.height

            if isinstance(height, (int, float)):
                height = f"{height}px"

        out: list[str] = []

        flags_data = _get_flags_data()

        for flag in flag_list:
            flag_dict = self._lookup_flag(flags_data=flags_data, code=flag.upper())

            # If the country code isn't recognized, keep the original text in place of a flag
            if flag_dict is None:
                out.append(_html_escape(flag))
                continue

            # Get the SVG string and country name for the flag
            flag_svg = str(flag_dict["country_flag"])
            flag_title = str(flag_dict["country_name"])

            # Extract the flag SVG data and modify it to include the height, width, and a
            # title based on the country name
            flag_icon = self._replace_flag_svg(
                flag_svg=flag_svg, height=height, use_title=self.use_title, flag_title=flag_title
            )

            out.append(str(flag_icon))

        img_tags = self.sep.join(out)
        span = self.SPAN_TEMPLATE.format(img_tags)

        return span

    def to_latex(self, val: Any):
        from warnings import warn

        from ._gt_data import FormatterSkipElement

        warn("fmt_flag() is not currently implemented in LaTeX output.")

        return FormatterSkipElement()

    @staticmethod
    def _lookup_flag(flags_data: list[FlagsDataDict], code: str) -> FlagsDataDict | None:
        # Since we allow 2- or 3- character country codes, create the name of the lookup
        # column based on the length of the country code
        if len(code) == 2:
            lookup_column = "country_code_2"
        elif len(code) == 3:
            lookup_column = "country_code_3"
        else:
            return None

        return next((entry for entry in flags_data if entry[lookup_column] == code), None)

    @staticmethod
    def _replace_flag_svg(flag_svg: str, height: str, use_title: bool, flag_title: str) -> str:
        # With a title, the flag is an image named after the country; otherwise it's decorative
        # and hidden from assistive technology
        if use_title:
            a11y_attrs = f'role="img" aria-label="{html.escape(flag_title)}" '
        else:
            a11y_attrs = 'aria-hidden="true" role="img" '

        replacement = (
            '<svg xmlns="http://www.w3.org/2000/svg" '
            f"{a11y_attrs}"
            'width="512" height="512" '
            'viewBox="0 0 512 512" '
            'style="vertical-align:-0.125em;'
            "image-rendering:optimizeQuality;"
            f"height:{height};"
            f"width:{height};"
            '">'
        )

        if use_title:
            replacement += f"<title>{html.escape(flag_title)}</title>"

        return re.sub(r"<svg.*?>", replacement, flag_svg)


def fmt_nanoplot(
    self: GTSelf,
    columns: str | None = None,
    rows: RowSelectExpr = None,
    plot_type: PlotType = "line",
    plot_height: str = "2em",
    missing_vals: MissingVals = "gap",
    autoscale: bool = False,
    reference_line: str | float | None = None,
    reference_area: list[Any] | None = None,
    expand_x: list[int] | list[float] | list[int | float] | None = None,
    expand_y: list[int] | list[float] | list[int | float] | None = None,
    options: dict[str, Any] | None = None,
    alt: str | FromColumn | None = None,
) -> GTSelf:
    """Format data for nanoplot visualizations.

    The `fmt_nanoplot()` method is used to format data for nanoplot visualizations. This method
    allows for the creation of a variety of different plot types, including line, bar, box, and
    scatter plots.

    :::{.callout-warning}
    `fmt_nanoplot()` is still experimental.
    :::

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    plot_type
        Nanoplots can either take the form of a line plot (using `"line"`), a bar plot (with
        `"bar"`), or a box plot (with `"boxplot"`). A line plot, by default, contains layers for a
        data line, data points, and a data area. With a bar plot, the always visible layer is that
        of the data bars. A box plot summarizes the distribution of each row's values (see the Box
        plots section below); like bar plots, box plots don't use *x* values.
    plot_height
        The height of the nanoplots. The default here is a sensible value of `"2em"`.
    missing_vals
        If missing values are encountered within the input data, there are three strategies
        available for their handling: (1) `"gap"` will show data gaps at the sites of missing data,
        where data lines will have discontinuities and bar plots will have missing bars; (2)
        `"marker"` will behave like `"gap"` but show prominent visual marks at the missing data
        locations; (3) `"zero"` will replace missing values with zero values; and (4) `"remove"`
        will remove any incoming missing values. Box plots leave missing values out, unless
        `"zero"` is used.
    autoscale
        Using `autoscale=True` will ensure that the bounds of all nanoplots produced are based on
        the limits of data combined from all input rows. This will result in a shared scale across
        all of the nanoplots (for *y*- and *x*-axis data), which is useful in those cases where the
        nanoplot data should be compared across rows. Box plots always share a scale.
    reference_line
        A reference line requires a single input to define the line. It could be a numeric value,
        applied to all nanoplots generated. Or, the input can be one of the following for generating
        the line from the underlying data: (1) `"mean"`, (2) `"median"`, (3) `"min"`, (4) `"max"`,
        (5) `"q1"`, (6) `"q3"`, (7) `"first"`, or (8) `"last"`. The quartiles (`"q1"` and `"q3"`)
        are interpolated between data values, as with the default method of R's `quantile()`.
    reference_area
        A reference area requires a list of two values for defining bottom and top boundaries (in
        the *y* direction) for a rectangular area. The types of values supplied are the same as
        those expected for `reference_line=`, which is either a numeric value or one of the
        following keywords for the generation of the value: (1) `"mean"`, (2) `"median"`, (3)
        `"min"`, (4) `"max"`, (5) `"q1"`, (6) `"q3"`, (7) `"first"`, or (8) `"last"`. Input can
        either be a vector or list with two elements.
    expand_x
        Should you need to have plots expand in the *x* direction, provide one or more values to
        `expand_x=`. Any values provided that are outside of the range of *x*-value data provided to
        the plot will result in a *x*-scale expansion.
    expand_y
        Similar to `expand_x=`, one can have plots expand in the *y* direction. To make this happen,
        provide one or more values to `expand_y=`. If any of the provided values are outside of the
        range of *y*-value data provided, the plot will result in a *y*-scale expansion.
    options
        By using the [`nanoplot_options()`](`great_tables.nanoplot_options`) helper function here,
        you can alter the layout and styling of the nanoplots in the new column.
    alt
        Alternative text for the nanoplots, which screen readers announce in place of the plot. By
        default, each nanoplot is described by a summary of its values (e.g., `"Line plot of 8
        values from 12.0 to 47.0, ending at 30.0"`). A string replaces that summary, with any `{x}`
        replaced by it (e.g., `"Weekly sales: {x}"`), and
        [`from_column()`](`great_tables.from_column`) takes each row's text from a column.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Details
    -------
    Nanoplots try to show individual data with reasonably good visibility. Interactivity is included
    as a basic feature so one can hover over the data points and vertical guides will display the
    value ascribed to each data point. Because **Great Tables** knows all about numeric formatting,
    values will be compactly formatted so as to not take up valuable real estate.

    While basic customization options are present in `fmt_nanoplot()`, many more opportunities for
    customizing nanoplots on a more granular level are possible with the aforementioned
    [`nanoplot_options()`](`great_tables.nanoplot_options`) helper function. With that, layers of
    the nanoplots can be selectively removed and the aesthetics of the remaining plot components can
    be modified.

    Box plots
    ---------
    With `plot_type="boxplot"`, each row's values are summarized as a horizontal box-and-whisker
    diagram. The box spans the first to the third quartile (with a line at the median), and the
    whiskers extend to the most extreme values within 1.5 times the interquartile range of the box;
    any values beyond the whiskers are outliers. Rows with fewer than 20 values show every value as
    a faint point, and rows with more show only their outliers. All of the box plots share a scale,
    so they can be compared across rows, and hovering over a box shows its statistics.

    A reference line or area is drawn vertically, with keywords (e.g., `"mean"`) computed from each
    row's values, and `expand_y=` extends the (horizontal) scale. In
    [`nanoplot_options()`](`great_tables.nanoplot_options`), `data_bar_stroke_color=` and
    `data_bar_stroke_width=` style the box and whiskers, `data_point_radius=` sets the box's
    thickness (six times the radius), `show_data_points=False` hides the points, and
    `y_val_fmt_fn=` formats the statistics.

    Examples
    --------
    Let's create a nanoplot from a Polars DataFrame containing multiple numbers per cell. The
    numbers are represented here as strings, where spaces separate the values, and the same values
    are present in two columns: `lines` and `bars`. We will use the `fmt_nanoplot()` method twice
    to create a line plot and a bar plot from the data in their respective columns.

    ```{python}
    from great_tables import GT
    import polars as pl

    random_numbers_df = pl.DataFrame(
        {
            "i": range(1, 5),
            "lines": [
                "20 23 6 7 37 23 21 4 7 16",
                "2.3 6.8 9.2 2.42 3.5 12.1 5.3 3.6 7.2 3.74",
                "-12 -5 6 3.7 0 8 -7.4",
                "2 0 15 7 8 10 1 24 17 13 6",
            ],
        }
    ).with_columns(bars=pl.col("lines"))

    (
        GT(random_numbers_df, rowname_col="i")
        .fmt_nanoplot(columns="lines")
        .fmt_nanoplot(columns="bars", plot_type="bar")
    )
    ```

    We can always represent the input DataFrame in a different way (with list columns) and
    `fmt_nanoplot()` will still work. While the input data is the same as in the previous example,
    we'll take the opportunity here to add a reference line and a reference area to the line plot
    and also to the bar plot.

    ```{python}
    random_numbers_df = pl.DataFrame(
        {
            "i": range(1, 5),
            "lines": [
                { "val": [20.0, 23.0, 6.0, 7.0, 37.0, 23.0, 21.0, 4.0, 7.0, 16.0] },
                { "val": [2.3, 6.8, 9.2, 2.42, 3.5, 12.1, 5.3, 3.6, 7.2, 3.74] },
                { "val": [-12.0, -5.0, 6.0, 3.7, 0.0, 8.0, -7.4] },
                { "val": [2.0, 0.0, 15.0, 7.0, 8.0, 10.0, 1.0, 24.0, 17.0, 13.0, 6.0] },
            ],
        }
    ).with_columns(bars=pl.col("lines"))

    (
        GT(random_numbers_df, rowname_col="i")
        .fmt_nanoplot(
            columns="lines",
            reference_line="mean",
            reference_area=["min", "q1"]
        )
        .fmt_nanoplot(
            columns="bars",
            plot_type="bar",
            reference_line="max",
            reference_area=["max", "median"])
    )
    ```

    Here's an example to adjust some of the options using
    [`nanoplot_options()`](`great_tables.nanoplot_options`).

    ```{python}
    from great_tables import nanoplot_options

    (
        GT(random_numbers_df, rowname_col="i")
        .fmt_nanoplot(
            columns="lines",
            reference_line="mean",
            reference_area=["min", "q1"],
            options=nanoplot_options(
                data_point_radius=8,
                data_point_stroke_color="black",
                data_point_stroke_width=2,
                data_point_fill_color="white",
                data_line_type="straight",
                data_line_stroke_color="brown",
                data_line_stroke_width=2,
                data_area_fill_color="orange",
                vertical_guide_stroke_color="green",
            ),
        )
        .fmt_nanoplot(
            columns="bars",
            plot_type="bar",
            reference_line="max",
            reference_area=["max", "median"],
            options=nanoplot_options(
                data_bar_stroke_color="gray",
                data_bar_stroke_width=2,
                data_bar_fill_color="orange",
                data_bar_negative_stroke_color="blue",
                data_bar_negative_stroke_width=1,
                data_bar_negative_fill_color="lightblue",
                reference_line_color="pink",
                reference_area_fill_color="bisque",
                vertical_guide_stroke_color="blue",
            ),
        )
    )
    ```

    Single-value bar plots and line plots can be made with `fmt_nanoplot()`. These run in the
    horizontal direction, which is ideal for tabular presentation. The key thing here is that
    `fmt_nanoplot()` expects a column of numeric values. These plots are meant for comparison
    across rows so the method automatically scales the horizontal bars to facilitate this type of
    display. The following example shows how `fmt_nanoplot()` can be used to create single-value bar
    and line plots.

    ```{python}
    single_vals_df = pl.DataFrame(
        {
            "i": range(1, 6),
            "bars": [4.1, 1.3, -5.3, 0, 8.2],
            "lines": [12.44, 6.34, 5.2, -8.2, 9.23]
        }
    )
    (
        GT(single_vals_df, rowname_col="i")
        .fmt_nanoplot(columns="bars", plot_type="bar")
        .fmt_nanoplot(columns="lines", plot_type="line")
    )
    ```

    Box plots are a good way to compare distributions across rows. Here, we collect the horsepower
    ratings of the cars in the `gtcars` dataset by body style and show each group as a box plot (all
    of them on the same scale). Hover over any box to see its quartiles and whiskers.

    ```{python}
    from great_tables import data

    hp_by_body_style = (
        data.pl.gtcars
        .group_by("bdy_style")
        .agg(n=pl.len(), hp=pl.col("hp"))
        .sort("bdy_style")
    )

    (
        GT(hp_by_body_style, rowname_col="bdy_style")
        .fmt_nanoplot(columns="hp", plot_type="boxplot")
        .cols_label(n="Cars", hp="Horsepower")
    )
    ```
    """

    # guards ----

    if not isinstance(columns, str):
        raise NotImplementedError(
            "Currently, fmt_nanoplot() only supports a single column name as a string. "
            f"\n\nReceived: {columns}"
        )

    if plot_type not in ("line", "bar", "boxplot"):
        raise NotImplementedError(
            "Currently, fmt_nanoplot() only supports line, bar, or boxplot as plot_type"
            f"\n\n Received: {plot_type}"
        )

    # main ----
    # Get the internal data table
    data_tbl = self._tbl_data

    # Values in the targeted rows, which are resolved the same way as in the other fmt_*() methods
    col_vals = to_list(data_tbl[columns])
    target_vals = [col_vals[i] for _, i in resolve_rows_i(self, rows)]

    col_class = str(_get_column_dtype(data_tbl, columns)).lower()

    # A numeric column has a single `y` value per cell; these are drawn as horizontal bars or lines
    # on a scale shared by all of the targeted cells (so autoscaling doesn't apply)
    # (dtype names differ between libraries: PyArrow calls float64 `double` and has `decimal128(...)`)
    if col_class.startswith(("int", "uint", "float", "double", "decimal")):
        # Missing values (e.g., `pd.NA` in a nullable pandas column) are given as `None`
        all_single_y_vals = [
            None if is_na(data_tbl, v) else float(v) if isinstance(v, Decimal) else v
            for v in target_vals
        ]
        autoscale = False
    else:
        all_single_y_vals = None

    if options is None:
        from great_tables._helpers import nanoplot_options

        options = nanoplot_options()

    # For autoscale, the `y` scale of every nanoplot spans the `y` values of all targeted cells
    # (missing cells and missing values are left out)
    if autoscale:
        all_y_vals = [
            val
            for cell in target_vals
            if not is_na(data_tbl, cell)
            for val in _get_cell_y_vals(cell)
            if not is_na(data_tbl, val)
        ]

        if all_y_vals:
            expand_y = [min(all_y_vals), max(all_y_vals)]

    # Box plots always share a scale, spanning the values of all targeted cells (with missing
    # values left out, or counted as zero with `missing_vals="zero"`)
    boxplot_vals = None
    if plot_type == "boxplot":
        boxplot_vals = [
            0 if is_na(data_tbl, val) else val
            for cell in target_vals
            if not is_na(data_tbl, cell)
            for val in _get_cell_y_vals(cell)
            if missing_vals == "zero" or not is_na(data_tbl, val)
        ]

    # Generate a function that turns the nanoplot data in a cell into an SVG nanoplot (with the
    # given alternative text)
    def make_fmt_nanoplot_fn(alt_text: str | None) -> Callable[[Any, str], str]:
        return lambda x, context: fmt_nanoplot_fn(x, context, alt_text)

    def fmt_nanoplot_fn(x: Any, context: str, alt_text: str | None = None) -> str:
        if context == "latex":
            raise NotImplementedError("fmt_nanoplot() is not supported in LaTeX.")

        # A missing cell value is returned as is
        if is_na(data_tbl, x):
            return x

        data_vals = _generate_data_vals(data_vals=x)

        # A cell with both `x` and `y` values (a dictionary with "x" and "y" keys) gives a tuple of
        # two lists of the same length
        if isinstance(data_vals, tuple):
            x_vals, y_vals = data_vals

            if not all(isinstance(val, (int, float)) for val in x_vals):
                raise ValueError("The 'x' values must be numeric.")

        else:
            x_vals, y_vals = None, data_vals

        return _generate_nanoplot(
            y_vals=y_vals,
            y_ref_line=reference_line,
            y_ref_area=reference_area,
            x_vals=x_vals,
            expand_x=expand_x,
            expand_y=expand_y,
            missing_vals=missing_vals,
            all_single_y_vals=all_single_y_vals,
            all_y_vals=boxplot_vals,
            plot_type=plot_type,
            svg_height=plot_height,
            alt=alt_text,
            **options,
        )

    if not isinstance(alt, FromColumn):
        return fmt_by_context(self, pf_format=make_fmt_nanoplot_fn(alt), columns=columns, rows=rows)

    # With `from_column()`, each row's alternative text comes from a column: the rows are grouped
    # by their text, and each group is formatted with it (sharing the scale computed above)
    alt_values = to_list(data_tbl[alt.column])
    rows_by_alt: dict[str, list[int]] = {}
    for _, row in resolve_rows_i(self, rows):
        value = alt_values[row]
        text = "" if is_na(data_tbl, value) else str(alt.fn(value) if alt.fn is not None else value)
        rows_by_alt.setdefault(text, []).append(row)

    res = self
    for text, alt_rows in rows_by_alt.items():
        res = fmt_by_context(
            res, pf_format=make_fmt_nanoplot_fn(text or None), columns=columns, rows=alt_rows
        )
    return res


def _get_cell_y_vals(cell: Any) -> list[int | float]:
    """Get the `y` values from a cell of nanoplot data (see `_generate_data_vals()`)."""

    data_vals = _generate_data_vals(data_vals=cell)

    # A cell with both `x` and `y` values gives a tuple of the two lists
    if isinstance(data_vals, tuple):
        data_vals = data_vals[1]

    return data_vals if isinstance(data_vals, list) else [data_vals]


def _to_python_number(val: Any) -> Any:
    """Turn a NumPy number (as in a pandas column) into a Python `int` or `float`."""

    if val is None or isinstance(val, (int, float)):
        return val

    return val.item() if hasattr(val, "item") else float(val)


def _generate_data_vals(
    data_vals: Any, is_x_axis: bool = False
) -> list[float] | tuple[list[float], list[float]]:
    """
    Generate a list of data values from the input data.

    Args:
        data_vals (Any): The input data values.

    Returns:
        list[Any]: A list of data values.
    """

    if is_series(data_vals):
        data_vals = to_list(data_vals)

    if isinstance(data_vals, list):
        # If the list contains string values, determine whether they are date values
        if all(isinstance(val, str) for val in data_vals):
            if not is_x_axis:
                raise ValueError("Only the x-axis of a nanoplot allows strings.")
            if re.search(r"\d{1,4}-\d{2}-\d{2}", data_vals[0]):
                data_vals = [_iso_str_to_date(val) for val in data_vals]

                # Transform the date values to numeric values
                data_vals = [val.toordinal() for val in data_vals]

        # If the cell value is a list of floats/ints, then return the same value

        # Check that the values within the list are numeric; missing values are allowed
        for val in data_vals:
            if val is not None and not isinstance(val, numbers.Real):
                raise ValueError(f"The input data values must be numeric.\n\nValue received: {val}")

        return [_to_python_number(val) for val in data_vals]

    elif isinstance(data_vals, numbers.Real):
        return _to_python_number(data_vals)

    elif isinstance(data_vals, Decimal):
        return float(data_vals)

    elif isinstance(data_vals, str):
        # If the cell value is a string, assume it is a value stream and convert to a list

        # Detect whether there are time values or numeric values in the string
        if re.search(r"\d{1,4}-\d{2}-\d{2}", data_vals) and is_x_axis:
            data_vals = _process_time_stream(data_vals)
        else:
            data_vals = _process_number_stream(data_vals)

    elif isinstance(data_vals, dict):
        # If the cell value is a dictionary, assume it contains data values
        # This is possibly for x and for y

        # Determine the number of keys in the dictionary
        num_keys = len(data_vals.keys())

        # If the dictionary contains only one key, then assume that the values are for y
        if num_keys == 1:
            data_vals = next(iter(data_vals.values()))

            # The data values can be anything, so recursively call this function to process them
            data_vals = _generate_data_vals(data_vals=data_vals)

        if num_keys >= 2:
            # For two or more keys, we need to see if the 'x' and 'y' keys are present
            if "x" in data_vals and "y" in data_vals:
                x_vals: Any = data_vals["x"]
                y_vals: Any = data_vals["y"]

                # The data values can be anything, so recursively call this function to process them
                x_vals = _generate_data_vals(data_vals=x_vals, is_x_axis=True)
                y_vals = _generate_data_vals(data_vals=y_vals)

                # Ensure that the lengths of the x and y values are the same
                if len(x_vals) != len(y_vals):
                    raise ValueError("The lengths of the 'x' and 'y' values must be the same.")

                return x_vals, y_vals

            else:
                raise ValueError("The dictionary must contain 'x' and 'y' keys.")

    else:
        # Raise not implemented
        raise NotImplementedError("The input data values must be a string.")

    return data_vals


def _process_number_stream(data_vals: str) -> list[float]:
    """
    Process a string of numeric values and convert to a list of floats.

    Args:
        data_vals (str): The string of numeric values.

    Returns:
        list[float]: A list of numeric values.
    """

    # Values are separated by whitespace, commas, or semicolons, and may be wrapped in brackets
    number_stream = re.sub(r"[;,\[\]]", " ", data_vals).split()

    result: list[float] = []
    for val in number_stream:
        # An `NA` marks a missing value, just like `nan` (which `float()` already accepts)
        if val.upper() == "NA":
            result.append(float("nan"))
            continue

        try:
            result.append(float(val))
        except ValueError:
            cleaned = re.sub(r"[\(\)a-dA-Df-zF-Z]", "", val)
            result.append(float(cleaned))

    return result


def _process_time_stream(data_vals: str) -> list[float]:
    """
    Process a string of time values and convert to a list of floats.

    Args:
        data_vals (str): The string of time values.

    Returns:
        list[float]: A list of time values.
    """

    time_stream = re.split(r"\s*[;,]\s*", data_vals)
    time_stream = [val.replace("T", " ") for val in time_stream]
    time_stream_vals = [float(val) for val in time_stream]

    return time_stream_vals


def fmt_passthrough(
    self: GTSelf,
    columns: SelectExpr = None,
    rows: RowSelectExpr = None,
    escape: bool = True,
    pattern: str = "{x}",
) -> GTSelf:
    """
    Format values by passing them through, optionally escaping and decorating.

    The `fmt_passthrough()` method allows you to mark cells as formatted without transforming
    them. This is useful in two situations:

    - **Escaping**: When `escape=True` (the default), special characters in cell values are escaped
      for the output context (HTML or LaTeX). This protects against cross-site scripting (XSS) while
      giving you explicit control over which cells are escaped.
    - **Decoration**: The `pattern=` argument lets you wrap values in a text pattern (e.g.,
      `pattern="[{x}]"`) without changing the underlying value.

    Since `fmt_passthrough()` marks cells as formatted, they are no longer subject to the automatic
    escaping that applies to unformatted cells. Setting `escape=False` is the way to include raw
    HTML or LaTeX in cell values without using the `html()` helper.

    Parameters
    ----------
    columns
        The columns to target. Can either be a single column name or a series of column names
        provided in a list.
    rows
        In conjunction with `columns=`, we can specify which of their rows should undergo
        formatting. The default is all rows, resulting in all rows in targeted columns being
        formatted. Alternatively, we can supply a row index, a list of row indices, or (for Polars
        DataFrames) a Polars expression such as `pl.col("x") > 0`.
    escape
        Should the cell values be escaped for the output context? When `True` (the default),
        HTML special characters like `<`, `>`, and `&` are escaped in HTML output, and LaTeX special
        characters are escaped in LaTeX output. Set to `False` to pass values through without
        escaping, which is useful when cell values already contain trusted HTML or LaTeX markup.
    pattern
        A formatting pattern that allows for decoration of the formatted value. The formatted value
        is represented by `{x}` (which can be used multiple times, if needed) and all other
        characters will be interpreted as string literals.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Examples
    --------
    Using `fmt_passthrough()` with `escape=True` (the default) to safely render user-supplied data:

    ```{python}
    from great_tables import GT
    import pandas as pd

    df = pd.DataFrame({"input": ["<b>bold</b>", "x & y", "normal text"]})

    GT(df).fmt_passthrough(columns="input")
    ```

    Using `pattern=` to decorate values without otherwise changing them:

    ```{python}
    from great_tables import GT
    import pandas as pd

    df = pd.DataFrame({"code": ["ABC", "DEF", "GHI"]})

    GT(df).fmt_passthrough(columns="code", pattern="[{x}]")
    ```

    Using `escape=False` to pass through trusted HTML:

    ```{python}
    from great_tables import GT
    import pandas as pd

    df = pd.DataFrame({"content": ["<b>bold</b>", "<em>italic</em>"]})

    GT(df).fmt_passthrough(columns="content", escape=False)
    ```
    """

    pf_format = partial(
        fmt_passthrough_context,
        escape=escape,
        pattern=pattern,
    )

    return fmt_by_context(self, pf_format=pf_format, columns=columns, rows=rows)


def fmt_passthrough_context(
    x: Any,
    escape: bool,
    pattern: str,
    context: str,
) -> str:
    if x is None:
        return x

    x_formatted = str(x)

    if escape:
        if context == "html":
            x_formatted = _html_escape(x_formatted)
        elif context == "latex":
            x_formatted = _latex_escape(x_formatted)

    x_formatted = _apply_value_pattern(x_formatted, pattern=pattern, context=context)

    return x_formatted


def fmt_by_context(
    self: GTSelf,
    pf_format: Callable[[Any], str],
    columns: SelectExpr,
    rows: RowSelectExpr,
) -> GTSelf:
    return fmt(
        self,
        fns=FormatFns(
            html=partial(pf_format, context="html"),  # type: ignore
            latex=partial(pf_format, context="latex"),  # type: ignore
            default=partial(pf_format, context="html"),  # type: ignore
        ),
        columns=columns,
        rows=rows,
    )
