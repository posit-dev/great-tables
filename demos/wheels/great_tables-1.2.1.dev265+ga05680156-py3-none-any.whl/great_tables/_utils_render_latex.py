from __future__ import annotations

import re
import warnings
from itertools import chain
from typing import TYPE_CHECKING

from ._spanners import spanners_print_matrix
from ._tbl_data import _get_cell, cast_frame_to_string, replace_null_frame
from ._text import _latex_escape, _process_text
from ._utils import heading_has_subtitle, heading_has_title, seq_groups
from ._utils_render_html import (
    _calculate_hierarchical_stub_rowspans,
    _get_spanners_matrix_height,
    _resolve_stubhead_label,
)
from .quarto import is_quarto_render

if TYPE_CHECKING:
    from ._gt_data import GroupRowInfo, GTData, SummaryRowInfo


LENGTH_TRANSLATIONS_TO_PX = {
    "px": 1.0,
    "pt": 4 / 3,
    "in": 96.0,
    "cm": 37.7952755906,
    "mm": 3.77952755906,
    "emu": 1 / 9525,
    "em": 16.0,
}

# The same lengths in points (1pt = 4/3px), given exactly so that they convert without rounding
LENGTH_TRANSLATIONS_TO_PT = {
    "px": 0.75,
    "pt": 1.0,
    "in": 72.0,
    "cm": 72 / 2.54,
    "mm": 72 / 25.4,
    "emu": 1 / 12700,
    "em": 12.0,
}


def _not_implemented(msg: str) -> None:
    warnings.warn(msg)


def is_css_length_string(x: str) -> bool:
    # This checks if there is a number followed by an optional string (only of letters)
    return re.match(r"^[0-9.]+[a-zA-Z]*$", x) is not None


def is_number_without_units(x: str) -> bool:
    # This check if the string is a number without any text
    return re.match(r"^[0-9.]+$", x) is not None


def css_length_has_supported_units(x: str, no_units_valid: bool = True) -> bool:
    # Check if the the string is a valid CSS length string with a text string

    if not is_css_length_string(x):
        return False

    # If the string is a number without units, we can return the value of `no_units_valid`
    if is_number_without_units(x):
        return no_units_valid

    units = get_units_from_length_string(x)

    return units in LENGTH_TRANSLATIONS_TO_PX


def get_units_from_length_string(length: str) -> str:
    # Extract the units from a string that is likely in the form of '123px' or '3.23in' in
    # order to return 'px' or 'in' respectively; we'll also need to trim any whitespace and
    # convert the string to lowercase
    units_str = re.sub(r"[0-9.]+", "", length).strip().lower()

    if units_str == "":
        return "px"

    return units_str


def get_px_conversion(length: str) -> float:
    input_units = get_units_from_length_string(length)

    if input_units == "px":
        return 1.0

    valid_units = list(LENGTH_TRANSLATIONS_TO_PX.keys())

    if input_units not in valid_units:
        raise ValueError(f"Invalid units: {input_units}")

    return LENGTH_TRANSLATIONS_TO_PX.get(input_units, 0.0)


def convert_to_px(length: str) -> float:
    # Extract the units from a string that is likely in the form of '123px' or '3.23in'
    units = get_units_from_length_string(length=length)

    # Extract the numeric value from the string and convert to a float
    value = float(re.sub(r"[a-zA-Z\s]", "", length))

    # If the units are already in pixels, we can return the value as-is (w/o rounding)
    if units == "px":
        return value

    # Get the conversion factor for the units
    # - this defaults to 1.0 if the units are 'px'
    # - otherwise, it will be a value that converts the units `value` to pixels
    px_conversion = get_px_conversion(length=units)

    return round(value * px_conversion)


def convert_to_pt(x: str) -> float:
    # Convert directly (not through whole pixels, as `convert_to_px()` does) so that, e.g., a
    # length in points is kept as is
    units = get_units_from_length_string(length=x)
    value = float(re.sub(r"[a-zA-Z\s]", "", x))

    if units not in LENGTH_TRANSLATIONS_TO_PT:
        raise ValueError(f"Invalid units: {units}")

    return value * LENGTH_TRANSLATIONS_TO_PT[units]


def _latex_indent_step(css_length: str) -> tuple[float, str]:
    """Get one step of stub indentation (`stub_indent_length`, a CSS length) as a LaTeX length.

    Returns the value and units: font-relative lengths (`em`, `rem`) are kept as LaTeX `em`, and
    absolute lengths are converted to points. A length with no fixed size (e.g., `%`) can't be
    used, so the default (`5px`) is used instead, with a warning.
    """

    length = css_length.strip().lower()
    units = get_units_from_length_string(length) if is_css_length_string(length) else None

    if units in ("em", "rem"):
        return float(re.sub(r"[a-z\s]", "", length)), "em"

    if units not in LENGTH_TRANSLATIONS_TO_PX:
        warnings.warn(
            f"The `stub_indent_length` value {css_length!r} can't be used in LaTeX output, so "
            "the default (`5px`) is used instead.",
            stacklevel=2,
        )
        length = "5px"

    return convert_to_pt(length), "pt"


def _protect_leading_bracket(text: str) -> str:
    """Keep text that starts with `[` from being read as an optional argument.

    A row starts after `\\\\` (or `\\toprule`), which takes an optional argument in brackets and
    looks for it past spaces and a line break, so a row starting with `[1]` fails to compile. An
    empty group in front of the bracket ends that search without adding anything to the output.
    """

    return "{}" + text if text.lstrip().startswith("[") else text


def _latex_row(cells: list[str]) -> str:
    """Join the cells of a row (without the line ending), protecting a leading `[`."""

    return _protect_leading_bracket(" & ".join(cells))


def latex_heading_row(content: list[str]) -> str:
    return "".join([_latex_row(content) + " \\\\ \n", "\\midrule\\addlinespace[2.5pt]"])


def _get_stub_layout_l(data: GTData) -> list[str]:
    """
    Get the stub layout (e.g., `["group_label", "rowname"]`) for LaTeX output.

    The table start, columns and body components must agree on the number of stub columns, so
    `_render_as_latex()` computes this once and passes it to each of them.
    """

    has_summary_rows = bool(data._summary_rows or data._summary_rows_grand)

    return data._stub._get_stub_layout(
        has_summary_rows=has_summary_rows, options=data._options, boxhead=data._boxhead
    )


def create_table_start_l(
    data: GTData, use_longtable: bool, stub_layout: list[str] | None = None
) -> str:
    """
    Create the table start component for LaTeX output.

    This function generates the LaTeX code that signifies the start of the table. The output is
    different depending on whether the table uses the `longtable` environment or not.

    Parameters
    ----------
    data : GTData
        The GTData object that contains all the information about the table.
    stub_layout : list[str] | None
        The stub layout from `_get_stub_layout_l()`; it's computed from `data` if not given.

    Returns
    -------
    str
        The LaTeX code that signifies the start of the table.
    """

    # Determine if there are any source notes; if any, add a `\setlength` command that will pull up
    # the minipage environment for the footer block

    # Get all source notes as a list
    source_notes = data._source_notes

    longtable_post_length = "\\setlength{\\LTpost}{0mm}\n" if len(source_notes) > 0 else ""

    # Get the column alignments for the visible columns as a list of `col_defs`
    col_defs = [align[0] for align in data._boxhead._get_default_alignments()]

    # Check if stub is present and determine layout
    if stub_layout is None:
        stub_layout = _get_stub_layout_l(data)

    # Determine if there's a stub column (rowname or group_label)
    has_stub = len(stub_layout) > 0

    # Build stub column definitions (left-aligned with separator)
    stub_col_defs = ""
    if has_stub:
        # Add 'l' for each stub column, with a '|' separator after the last one
        stub_col_defs = "l" * len(stub_layout) + "|"

    # If a table width is specified, add an extra column
    # space to fill in enough space to match the width
    extra_sep = ""

    # Obtain the table width value from the `table_width` options value
    table_width = data._options.table_width.value

    if table_width != "auto":
        extra_sep = "@{\\extracolsep{\\fill}}"

    # determine string for table width if using tabular* environment
    hdr_tabular = ""

    if not use_longtable:
        # we need to use the extracolsep here for tabular* regardless of width
        extra_sep = "@{\\extracolsep{\\fill}}"

        if table_width.endswith("%"):
            tw = float(table_width.replace("%", ""))

            tw_frac = tw / 100

            hdr_tabular = f"\\begin{{tabular*}}{{{tw_frac}\\linewidth}}{{"

        elif table_width.endswith("px"):
            width_in_pt = convert_to_pt(table_width)
            hdr_tabular = f"\\begin{{tabular*}}{{{width_in_pt}pt}}{{"

        else:
            hdr_tabular = "\\begin{tabular*}{\\linewidth}{"

    # Generate setup statements for table including default left
    # alignments and vertical lines for any stub columns
    table_start = "".join(
        [
            longtable_post_length if use_longtable else "",
            "\\begin{longtable}{" if use_longtable else hdr_tabular,
            extra_sep,
            stub_col_defs,
            "".join(col_defs),
            "}",
        ]
    )

    return table_start


def create_heading_component_l(data: GTData, use_longtable: bool) -> str:
    """
    Create the heading component for LaTeX output.

    This function generates the LaTeX code for the heading component of a table which involves the
    title and the optional subtitle. There is variation in the output based on whether the table
    uses the `longtable` environment or not.

    Parameters
    ----------
    data : GTData
        The GTData object that contains all the information about the table.

    Returns
    -------
    str
        The LaTeX code for the heading component of the table.
    """

    title = data._heading.title
    subtitle = data._heading.subtitle

    line_continuation = "\\\\"

    has_title = heading_has_title(title)

    # If there is no title, then return an empty string
    if not has_title:
        return ""

    title_str = _process_text(title, context="latex")

    title_row = f"{{\\large {title_str}}}"

    has_subtitle = heading_has_subtitle(subtitle)

    if has_subtitle:
        subtitle_str = _process_text(subtitle, context="latex")

        subtitle_row = f"{{\\small {subtitle_str}}}"

        header_component = f"""\\caption*{{
{title_row} \\\\
{subtitle_row}
}} {line_continuation if use_longtable else ""}"""

    else:
        header_component = f"""\\caption*{{
{title_row}
}} {line_continuation if use_longtable else ""}"""

    return header_component


def create_columns_component_l(data: GTData, stub_layout: list[str] | None = None) -> str:
    """
    Create the columns component for LaTeX output.

    This function generates the LaTeX code for the columns component of a table which involves the
    column headings and the spanners.

    Parameters
    ----------
    data : GTData
        The GTData object that contains all the information about the table.
    stub_layout : list[str] | None
        The stub layout from `_get_stub_layout_l()`; it's computed from `data` if not given.

    Returns
    -------
    str
        The LaTeX code for the columns component of the table.
    """

    # Determine the finalized number of spanner rows
    spanner_row_count = _get_spanners_matrix_height(data=data, omit_columns_row=True)

    # Check if stub is present and determine layout
    if stub_layout is None:
        stub_layout = _get_stub_layout_l(data)

    # Determine if there's a stub column (rowname or group_label)
    has_stub = len(stub_layout) > 0

    # Create stub header cells; a single stubhead label is placed in a cell spanning all of the
    # stub columns, a list of labels gives one cell per stub column (with an empty cell above any
    # row group column), and otherwise there is empty space for each stub column
    stub_headers = []
    if has_stub:
        # An empty label (e.g., `tab_stubhead("")`) is treated as no label
        stubhead = (
            _resolve_stubhead_label(data._stubhead, stub_layout=stub_layout)
            if data._stubhead
            else None
        )

        if isinstance(stubhead, list):
            stub_headers = [" "] * stub_layout.count("group_label") + [
                _process_text(label, context="latex") for label in stubhead
            ]
        elif stubhead is not None:
            stub_label = _process_text(stubhead, context="latex")

            if len(stub_layout) > 1:
                stub_label = f"\\multicolumn{{{len(stub_layout)}}}{{l|}}{{{stub_label}}}"

            stub_headers = [stub_label]
        else:
            stub_headers = [" "] * len(stub_layout)

    # Get the column headings
    headings_labels = data._boxhead._get_default_column_labels()

    # Ensure that the heading labels are processed for LaTeX
    headings_labels = [_process_text(x, context="latex") for x in headings_labels]

    # Prepend stub headers to column headings
    all_headings = stub_headers + headings_labels

    table_col_headings = "".join(latex_heading_row(content=all_headings))

    if spanner_row_count > 0:
        boxhead = data._boxhead

        table_col_spanners = []

        spanners, _ = spanners_print_matrix(
            spanners=data._spanners,
            boxhead=boxhead,
            include_hidden=False,
            ids=False,
            omit_columns_row=True,
        )

        spanner_ids, _ = spanners_print_matrix(
            spanners=data._spanners,
            boxhead=boxhead,
            include_hidden=False,
            ids=True,
            omit_columns_row=True,
        )
        for label_row, id_row in zip(spanners, spanner_ids):
            # Group adjacent columns by spanner ID; the IDs are wrapped in tuples because
            # `seq_groups()` never joins `None` values, and adjacent columns without a spanner
            # share one blank cell
            spanners_rle = seq_groups((span_id,) for span_id in id_row.values())

            group_spans = [[x[1]] + [0] * (x[1] - 1) for x in spanners_rle]
            colspans = chain.from_iterable(group_spans)
            level_i_spanners = (
                _process_text(span_label, context="latex") if span_label else None
                for colspan, span_label in zip(colspans, label_row.values())
                if colspan > 0
            )

            spanner_labs = []
            spanner_lines = []
            span_accumulator = 0

            # Add empty cells for stub columns in spanner row
            if has_stub:
                spanner_labs.extend([" "] * len(stub_layout))
                span_accumulator = len(stub_layout)

            for j, level_i_spanner_j in enumerate(level_i_spanners):
                # Get the number of columns the group covers
                span = group_spans[j][0]

                if level_i_spanner_j is None:
                    # An unspanned group still needs one cell per column it covers
                    spanner_labs.extend([""] * span)

                else:
                    # TODO: Get alignment for spanner, for now it's center (`c`)

                    # Get multicolumn statement for spanner
                    multicolumn_stmt = f"\\multicolumn{{{span}}}{{c}}{{{level_i_spanner_j}}}"

                    spanner_labs.append(multicolumn_stmt)

                    # Get cmidrule statement for spanner, it uses 1-based indexing over the
                    # columns of the table; `span_accumulator` holds how many columns the
                    # preceding groups, and any stub columns, already cover

                    begin = span_accumulator + 1
                    end = span_accumulator + span

                    cmidrule = f"\\cmidrule(lr){{{begin}-{end}}}"

                    spanner_lines.append(cmidrule)

                span_accumulator += span

            spanner_labs_row = _latex_row(spanner_labs) + " \\\\ \n"
            spanner_lines_row = " ".join(spanner_lines) + "\n"

            col_spanners_i = spanner_labs_row + spanner_lines_row

            table_col_spanners.append(col_spanners_i)

        table_col_spanners = "".join(table_col_spanners)

    else:
        table_col_spanners = ""

    columns_component = "\\toprule\n" + table_col_spanners + table_col_headings

    return columns_component


def create_body_component_l(data: GTData, stub_layout: list[str] | None = None) -> str:
    """
    Create the body component for LaTeX output.

    This function generates the LaTeX code for the body component of a table which involves the
    data cells, the row groups, and the stub.

    Parameters
    ----------
    data : GTData
        The GTData object that contains all the information about the table.
    stub_layout : list[str] | None
        The stub layout from `_get_stub_layout_l()`; it's computed from `data` if not given.

    Returns
    -------
    str
        The LaTeX code for the body component of the table.
    """

    _str_orig_data = cast_frame_to_string(data._tbl_data)
    tbl_data = replace_null_frame(data._body.body, _str_orig_data)

    # Get the default column vars
    column_vars = data._boxhead._get_default_columns()

    # Check if stub is present and determine layout
    if stub_layout is None:
        stub_layout = _get_stub_layout_l(data)

    # Determine what stub components are present
    has_row_stub_column = "rowname" in stub_layout
    has_group_stub_column = "group_label" in stub_layout
    has_groups = len(data._stub.group_ids) > 0

    # Get the stub columns (outermost level first) if they exist
    stub_col_vars = data._boxhead._get_stub_columns()

    body_rows = []

    ordered_index: list[tuple[int, GroupRowInfo | None]] = data._stub.group_indices_map()

    # In a hierarchical stub, a value repeated in an outer column is only shown on the first row
    # of its run (the same runs that are merged with rowspans in HTML output)
    stub_rowspans_by_col = (
        _calculate_hierarchical_stub_rowspans(
            [col.var for col in stub_col_vars], ordered_index, tbl_data
        )
        if len(stub_col_vars) > 1
        else []
    )

    prev_group_info = None
    first_group_added = False

    # The group whose label was already shown in a top summary row (with the group as a column)
    group_label_shown = None

    # One step of stub indentation, as a LaTeX length (worked out on first use)
    indent_step: tuple[float, str] | None = None

    # Calculate total number of columns for multicolumn spanning in group headers
    n_cols = len(column_vars) + len(stub_layout)

    # Add grand summary rows at top
    top_grand_summary = data._summary_rows_grand.get_summary_rows(side="top")
    if top_grand_summary:
        for summary_row in top_grand_summary:
            summary_str = _create_summary_row_l(
                summary_row=summary_row,
                column_vars=column_vars,
                n_stub_cols=len(stub_layout),
            )
            body_rows.append(summary_str)
        body_rows.append("\\midrule\\addlinespace[2.5pt]")

    for j, (i, group_info) in enumerate(ordered_index):
        # Handle row group labels
        if (has_groups and group_info is not None) and (group_info is not prev_group_info):
            # Only create group row if this is first row of the group
            # When a groupname_col formatter ran, group_label is already
            # safe for the output context; when it's the raw group_id, escape it.
            if group_info.group_label is not None:
                group_label = group_info.group_label
            else:
                group_label = _process_text(group_info.group_id, context="latex")

            # Add a midrule before each group (except for the first group, which already has
            # one from the column headers)
            if first_group_added:
                body_rows.append("\\midrule\\addlinespace[2.5pt]")
            first_group_added = True

            # When group is shown as a column, we don't add a separate row
            # Instead, it will be added as a cell in each data row
            if not has_group_stub_column:
                group_row = f"\\multicolumn{{{n_cols}}}{{l}}{{{group_label}}} \\\\[2.5pt] \n\\midrule\\addlinespace[2.5pt]"
                body_rows.append(group_row)

            # Group summary rows with `side="top"` go before the first row of the group
            if data._summary_rows:
                top_group_summary = data._summary_rows.get_summary_rows(
                    group_id=group_info.group_id, side="top"
                )

                if top_group_summary:
                    for k, summary_row in enumerate(top_group_summary):
                        # With the group as a column, the group label starts in the first
                        # (top summary) row of the group, as in HTML
                        group_cell = None
                        if has_group_stub_column:
                            group_cell = group_label if k == 0 else ""
                            group_label_shown = group_info

                        summary_str = _create_summary_row_l(
                            summary_row=summary_row,
                            column_vars=column_vars,
                            n_stub_cols=len(stub_layout),
                            group_cell=group_cell,
                        )
                        body_rows.append(summary_str)
                    body_rows.append("\\midrule\\addlinespace[2.5pt]")

        # Create data row cells
        body_cells: list[str] = []

        # Add stub cells first (group_label column, then rowname column)
        if has_group_stub_column and group_info is not None:
            # Only show group label in first row of group (unless a top summary row showed it)
            if group_info is prev_group_info or group_info is group_label_shown:
                # Use an empty cell for continuation rows in same group
                body_cells.append("")
            else:
                if group_info.group_label is not None:
                    group_label = group_info.group_label
                else:
                    group_label = _process_text(group_info.group_id, context="latex")

                body_cells.append(group_label)

        if has_row_stub_column:
            # Get the row name(s) from the stub
            if stub_col_vars:
                for k, stub_col in enumerate(stub_col_vars):
                    if stub_rowspans_by_col and stub_rowspans_by_col[k][j] == 0:
                        body_cells.append("")
                    else:
                        body_cells.append(str(_get_cell(tbl_data, i, stub_col.var)))

                # Indent the row label as set by `tab_stub_indent()`; in a hierarchical stub only
                # the primary (last) column is indented
                indent_level = data._stub.rows[i].indent
                if indent_level > 0:
                    if indent_step is None:
                        indent_step = _latex_indent_step(data._options.stub_indent_length.value)
                    indent = f"{indent_step[0] * indent_level:g}{indent_step[1]}"

                    # No space after the `\hspace*{}`, which would add an interword space
                    body_cells[-1] = f"\\hspace*{{{indent}}}{body_cells[-1]}"
            else:
                # Placeholder stub for summary rows (no actual rowname column)
                body_cells.append("")

        # Add data cells
        for colinfo in column_vars:
            cell_content = _get_cell(tbl_data, i, colinfo.var)
            cell_str: str = str(cell_content)

            body_cells.append(cell_str)

        # Join cells with ampersand and terminate with a double backslash
        body_row_str = _latex_row(body_cells) + " \\\\"

        body_rows.append(body_row_str)

        prev_group_info = group_info

        # After the last row in a group, append group summary rows with `side="bottom"`
        if has_groups and group_info is not None and data._summary_rows:
            is_last_in_group = (
                j == len(ordered_index) - 1 or ordered_index[j + 1][1] is not group_info
            )

            if is_last_in_group:
                group_id = group_info.group_id
                group_summary = data._summary_rows.get_summary_rows(
                    group_id=group_id, side="bottom"
                )

                if group_summary:
                    body_rows.append("\\midrule\\addlinespace[2.5pt]")
                    for summary_row in group_summary:
                        summary_str = _create_summary_row_l(
                            summary_row=summary_row,
                            column_vars=column_vars,
                            n_stub_cols=len(stub_layout),
                            # With the group as a column, the group cell is empty (the group
                            # label is in the group's first row), as in HTML
                            group_cell="" if has_group_stub_column else None,
                        )
                        body_rows.append(summary_str)

    # Add grand summary rows at bottom
    bottom_grand_summary = data._summary_rows_grand.get_summary_rows(side="bottom")
    if bottom_grand_summary:
        body_rows.append("\\midrule\\addlinespace[2.5pt]")
        for summary_row in bottom_grand_summary:
            summary_str = _create_summary_row_l(
                summary_row=summary_row,
                column_vars=column_vars,
                n_stub_cols=len(stub_layout),
            )
            body_rows.append(summary_str)

    # Join all body rows with newlines
    all_body_rows = "\n".join(body_rows)

    return all_body_rows


def _create_summary_row_l(
    summary_row: SummaryRowInfo,
    column_vars: list,
    n_stub_cols: int,
    group_cell: str | None = None,
) -> str:
    """Create a single LaTeX summary row.

    With `group_cell` (a group summary row when the row group is shown as a column), the row
    starts with that cell in the group column (the group label, or empty), as in HTML.
    """
    cells: list[str] = []

    summary_label = _process_text(summary_row.label, context="latex")

    # (only when there's also a row name stub column for the label; otherwise the label takes the
    # group column, which is the only stub column)
    if group_cell is not None and n_stub_cols > 1:
        cells.append(group_cell)
        n_stub_cols -= 1

    # The summary label goes in the stub position, spanning all of the (remaining) stub columns (a
    # row group column and any number of row name columns); with no stub it takes the first column
    if n_stub_cols > 1:
        cells.append(f"\\multicolumn{{{n_stub_cols}}}{{l}}{{{summary_label}}}")
    else:
        cells.append(summary_label)

    # Add data cells, formatted for LaTeX (`values` are formatted for HTML)
    for colinfo in column_vars:
        if summary_row.values_latex is not None:
            cells.append(summary_row.values_latex.get(colinfo.var, ""))
        else:
            cells.append(_latex_escape(str(summary_row.values.get(colinfo.var, ""))))

    return _latex_row(cells) + " \\\\"


def create_footer_component_l(data: GTData) -> str:
    """
    Create the footer component for LaTeX output.

    This function generates the LaTeX code for the footer component of a table which involves the
    source notes.

    Parameters
    ----------
    data : GTData
        The GTData object that contains all the information about the table.

    Returns
    -------
    str
        The LaTeX code for the footer component of the table.
    """

    # Get all source notes as a list
    source_notes = data._source_notes

    if len(source_notes) == 0:
        return ""

    # Ensure that the source notes are processed for LaTeX
    source_notes = [
        _protect_leading_bracket(_process_text(x, context="latex")) for x in source_notes
    ]

    # Create a formatted source notes string
    source_notes = "\\\\\n".join(source_notes) + "\\\\"

    # Create the footer block
    footer_block = f"""\\begin{{minipage}}{{\\linewidth}}
{source_notes}
\\end{{minipage}}"""

    return footer_block


def create_table_end_l(use_longtable: bool) -> str:
    """
    Create the table end component for LaTeX output.

    This function generates the LaTeX code that signifies the end of the table. The output is
    different depending on whether the table uses the `longtable` environment or not.

    Parameters
    ----------
    use_longtable : bool
        Whether the table uses the `longtable` environment.

    Returns
    -------
    str
        The LaTeX code that signifies the end of the table.
    """

    table_end = "\\bottomrule\n" + ("\\end{longtable}" if use_longtable else "\\end{tabular*}")

    return table_end


def derive_table_width_statement_l(data: GTData, use_longtable: bool) -> str:
    # Get the table width value
    tbl_width = data._options.table_width.value

    # Initialize the statement variables LTleft and LTright
    sides = ("LTleft", "LTright")

    # Bookends are not required if a table width is not specified or if using floating table
    if tbl_width == "auto" or not use_longtable:
        statement = ""

    elif tbl_width.endswith("%"):
        tw = float(tbl_width.strip("%"))

        side_width = (100 - tw) / 200
        side_width = f"{side_width:.6f}".rstrip("0").rstrip(".")

        statement = "\n".join([f"\\setlength\\{side}{{{side_width}\\linewidth}}" for side in sides])

    else:
        width_in_pt = convert_to_pt(tbl_width)

        halfwidth_in_pt = f"{width_in_pt / 2:.6f}".rstrip("0").rstrip(".")

        statement = "\n".join(
            f"\\setlength\\{side}{{\\dimexpr(0.5\\linewidth - {halfwidth_in_pt}pt)}}"
            for side in sides
        )

    return statement


def create_fontsize_statement_l(data: GTData) -> str:
    table_font_size = data._options.table_font_size.value

    fs_fmt = "\\fontsize{%3.1fpt}{%3.1fpt}\\selectfont\n"

    if table_font_size.endswith("%"):
        multiple = float(table_font_size.strip("%")) / 100
        fs_statement = fs_fmt % (multiple * 12, multiple * 12 * 1.2)

    elif table_font_size.endswith("pt"):
        size_in_pt = float(table_font_size[:-2])
        fs_statement = fs_fmt % (size_in_pt, size_in_pt * 1.2)

    elif css_length_has_supported_units(table_font_size):
        size_in_pt = convert_to_px(table_font_size) * 0.75
        fs_statement = fs_fmt % (size_in_pt, size_in_pt * 1.2)

    else:
        fs_statement = ""

    return fs_statement


def create_wrap_start_l(use_longtable: bool, tbl_pos: str | None) -> str:
    if is_quarto_render():
        tbl_pos = ""

    else:
        if tbl_pos is None:
            tbl_pos = "!t"

        tbl_pos = f"[{tbl_pos}]"

    return "\\begingroup" if use_longtable else f"\\begin{{table}}{tbl_pos}"


def create_wrap_end_l(use_longtable: bool) -> str:
    wrap_end = "\\endgroup" if use_longtable else "\\end{table}"

    return wrap_end


def _render_as_latex(data: GTData, use_longtable: bool = False, tbl_pos: str | None = None) -> str:
    # Check for styles (not yet supported so warn user)
    if data._styles:
        _not_implemented("Styles are not yet supported in LaTeX output.")

    # Throw exception if footnotes are present in the table
    if data._footnotes:
        raise NotImplementedError(
            "Footnotes are not yet supported in LaTeX output. "
            "Consider removing all `.tab_footnote()` calls before using `.as_latex()`."
        )

    # Get the stub layout once, so that every component uses the same number of stub columns
    stub_layout = _get_stub_layout_l(data)

    # Create a LaTeX fragment for the start of the table
    table_start = create_table_start_l(
        data=data, use_longtable=use_longtable, stub_layout=stub_layout
    )

    # Create the heading component
    heading_component = create_heading_component_l(data=data, use_longtable=use_longtable)

    # Create the columns component
    columns_component = create_columns_component_l(data=data, stub_layout=stub_layout)

    # Create the body component
    body_component = create_body_component_l(data=data, stub_layout=stub_layout)

    # Create the footnotes component
    footer_component = create_footer_component_l(data=data)

    # Create a LaTeX fragment for the ending tabular statement
    table_end = create_table_end_l(use_longtable=use_longtable)

    # Create a LaTeX fragment for the table width statement
    table_width_statement = derive_table_width_statement_l(data=data, use_longtable=use_longtable)

    # Allow user to set a font-size
    fontsize_statement = create_fontsize_statement_l(data=data)

    # Create wrapping environment
    wrap_start_statement = create_wrap_start_l(use_longtable=use_longtable, tbl_pos=tbl_pos)
    wrap_end_statement = create_wrap_end_l(use_longtable=use_longtable)

    # Compose the LaTeX table
    if use_longtable:
        finalized_table = f"""{wrap_start_statement}
{table_width_statement}
{fontsize_statement}
{table_start}
{heading_component}
{columns_component}
{body_component}
{table_end}
{footer_component}
{wrap_end_statement}
"""

    else:
        finalized_table = f"""{wrap_start_statement}
{heading_component}
{table_width_statement}
{fontsize_statement}
{table_start}
{columns_component}
{body_component}
{table_end}
{footer_component}
{wrap_end_statement}
"""

    return finalized_table
