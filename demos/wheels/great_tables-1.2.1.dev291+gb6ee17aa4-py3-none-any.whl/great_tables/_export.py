from __future__ import annotations

import sys
import tempfile
import time
import warnings
import webbrowser
from functools import partial
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import TYPE_CHECKING, Literal, TypeAlias

from ._helpers import random_id
from ._scss import compile_scss
from ._theme import pin_mode
from ._utils import _try_import
from ._utils_render_latex import _render_as_latex

if TYPE_CHECKING:
    # Note that as_raw_html uses methods on the GT class, not just data
    from IPython.core.interactiveshell import InteractiveShell
    from selenium import webdriver

    from ._types import GTSelf
    from .gt import GT


class PatchedHTTPRequestHandler(SimpleHTTPRequestHandler):
    """Patched handler, which does not log requests to stderr"""


class MISSING:
    """Represent a missing argument (where None has a special meaning)."""


def _create_temp_file_server(fname: Path) -> HTTPServer:
    """Return a HTTPServer, so we can serve a single request (to show the table)."""

    Handler = partial(PatchedHTTPRequestHandler, directory=str(fname.parent))
    server = HTTPServer(("127.0.0.1", 0), Handler)

    return server


def _running_in_marimo() -> bool:
    # A marimo kernel has always imported marimo, so there's no need to import it to check
    marimo = sys.modules.get("marimo")
    return marimo is not None and marimo.running_in_notebook()


def _infer_render_target(
    ipy: InteractiveShell | type | None = MISSING,
) -> Literal["auto", "notebook", "browser"]:
    # adapted from py-htmltools
    # Note that `ipy` arguments are possible return values of IPython.get_ipython()
    # They are manually passed in from unit tests to validate this function.
    target: Literal["auto", "notebook", "browser"]

    # marimo doesn't run an IPython shell, so get_ipython() returns None in it
    if _running_in_marimo():
        return "notebook"

    try:
        import IPython  # pyright: ignore[reportUnknownVariableType]
        from IPython.terminal.interactiveshell import TerminalInteractiveShell

        if ipy is MISSING:
            # Note that get_ipython may be None, to indicate no shell in use
            # e.g. if you're in the normal python repl
            ipy = IPython.get_ipython()

        if isinstance(ipy, TerminalInteractiveShell) or ipy is None:
            target = "browser"
        else:
            target = "notebook"

    except ImportError:
        target = "browser"

    return target


def show(
    self: GTSelf,
    target: Literal["auto", "notebook", "browser"] = "auto",
):
    """Display the table in a notebook or a web browser.

    Note that this function is often unnecessary in a notebook. However, it's sometimes useful for
    manually triggering display within a code cell.

    Parameters
    ----------
    target:
        Where to show the table. If "auto", infer whether the table can be displayed inline (e.g. in
        a notebook), or whether a browser is needed (e.g. in a console).

    Examples
    --------

    The example below when in the Great Tables documentation, should appear on the page.

    ```{python}
    from great_tables import GT, exibble

    GT(exibble.head(2)).show()
    GT(exibble.tail(2)).show()
    ```

    """

    if target == "auto":
        target = _infer_render_target()

    if target == "notebook" and _running_in_marimo():
        import marimo

        marimo.output.append(self)
    elif target == "notebook":
        from IPython.core.display import display_html

        html = self._repr_html_()

        # https://github.com/ipython/ipython/pull/10962
        display_html(  # pyright: ignore[reportUnknownVariableType]
            html, raw=True, metadata={"text/html": {"isolated": True}}
        )
    elif target == "browser":
        html = self.as_raw_html(make_page=True)
        with tempfile.TemporaryDirectory() as tmp_dir:
            f_path = Path(tmp_dir) / "index.html"
            f_path.write_text(html, encoding="utf-8")

            # create a server that closes after 1 request ----
            server = _create_temp_file_server(f_path)
            webbrowser.open(f"http://127.0.0.1:{server.server_port}/{f_path.name}")
            server.handle_request()
    else:
        raise ValueError(f"Unknown target display: {target}")


def as_raw_html(
    self: GT,
    inline_css: bool = False,
    make_page: bool = False,
    all_important: bool = False,
    runtime: Literal["inline", "none"] = "inline",
) -> str:
    """
    Get the HTML content of a GT object.

    The `as_raw_html()` method extracts the HTML representation of a GT table and returns it as a
    string. This is useful when you need to embed a table in existing HTML content, email templates,
    web applications, or other contexts where you need direct access to the HTML markup rather than
    displaying the table directly.

    By default, the method returns an HTML fragment containing just the table and its associated
    CSS styles in a `<style>` block. However, the method provides several parameters for customizing
    the output format--like `inline_css=`, `make_page=`, and `all_important=`.

    Body cells that have not been processed by a `fmt_*()` method are automatically HTML-escaped to
    prevent cross-site scripting (XSS). Cells that have been formatted (e.g., with
    [`fmt_number()`](`great_tables.GT.fmt_number`),
    [`fmt_markdown()`](`great_tables.GT.fmt_markdown`), etc.) are trusted as safe HTML. To include
    raw HTML in unformatted cells, use the `html()` helper (e.g., `html("<b>bold</b>")`) via a
    `fmt_*()` method or `text_transform()`.

    Parameters
    ----------
    inline_css
        If `True`, all CSS styles are inlined into the HTML elements as `style` attributes, with
        literal values for the table's mode (`"auto"` gives the light table). Use it for email and
        for older renderers: the default `<style>` block is written with CSS custom properties,
        which email clients such as Gmail and Outlook and old engines such as wkhtmltopdf don't
        support, so they draw the table unstyled. It doesn't apply to an interactive table (one made with
        [`opt_interactive()`](`great_tables.GT.opt_interactive`)), which needs its `<style>` block
        and its script: it's ignored, with a warning (for a table in an email, use
        `opt_interactive(active=False)`).
    make_page
        If `True`, the table will be wrapped in a complete HTML page with proper `<html>`, `<head>`,
        and `<body>` tags. This is useful when you want to display the table in a web browser or
        save it as a standalone HTML file.
    all_important
        If `True`, all CSS declarations are marked with `!important` to ensure they take precedence
        over other styles that might be present in the document.
    runtime
        Whether an interactive table's HTML (a table made with
        [`opt_interactive()`](`great_tables.GT.opt_interactive`)) is followed by the runtime that
        makes it interactive, its JavaScript and CSS: `"inline"` (the default) or `"none"`, for a
        page that has the runtime once, however many tables it shows (see
        [`runtime_tags()`](`great_tables.web.runtime_tags`)). A static table has no runtime, so
        this doesn't change it.

    Returns
    -------
    str
        An HTML string containing the table. The format depends on the parameters passed to the
        method.

    Examples:
    ------
    Let's use a subset of the `gtcars` dataset to create a new table.

    ```{python}
    from great_tables import GT, data, md, style, loc
    from great_tables.data import gtcars
    import polars as pl

    gtcars_mini = (
        data.pl.gtcars
        .select(["mfr", "model", "msrp"])
        .head(5)
    )

    gt_tbl = (
        GT(gtcars_mini)
        .tab_header(
            title=md("Data listing from **gtcars**"),
            subtitle=md("gtcars is an R dataset")
        )
        .tab_style(
            style=style.fill(color="LightCyan"),
            locations=loc.body(columns="mfr")
        )
        .fmt_currency(columns="msrp")
        .tab_options(
            heading_background_color="Azure",
            table_body_hlines_color="Lavender",
            table_body_hlines_width="2px"
        )
        .opt_horizontal_padding(scale=2)
    )

    gt_tbl
    ```

    Now we can return the table as an HTML string using the `as_raw_html()` method.

    ```{python}
    gt_tbl.as_raw_html()
    ```

    The HTML string contains the HTML for the table. It has only the table so it's not a complete
    HTML document but rather an HTML fragment. While this useful for embedding a table in an
    existing HTML document, you could also use the `make_page=True` argument to get a complete HTML
    page with the table contained within.

    ```{python}
    gt_tbl.as_raw_html(make_page=True)
    ```

    Should you want to include all of the CSS styles as inline styles, you can use `inline_css=True`
    to get an HTML string with all CSS inlined into the HTML tags.

    ```{python}
    gt_tbl.as_raw_html(inline_css=True)
    ```
    """

    if runtime not in ("inline", "none"):
        raise ValueError(f'`runtime=` must be "inline" or "none", not {runtime!r}.')

    # An interactive table (from `opt_interactive()`) is a `<gt-table>` element, whose CSS can't be
    # inlined: `inline_css=` doesn't apply to it
    if self._options.ihtml_active.value:
        from ._gti import page_html, render_gti_html

        if inline_css:
            warnings.warn(
                "An interactive table (from `opt_interactive()`) can't have its CSS inlined, so "
                "`inline_css=True` is ignored: its HTML needs a <style> block and a script, which "
                "email clients don't run. For a table in an email, use "
                "`opt_interactive(active=False)`.",
                stacklevel=2,
            )

        fragment = render_gti_html(self, runtime=runtime, all_important=all_important)
        return page_html(fragment, self) if make_page else fragment

    built_table = self._build_data(context="html")

    table_html = built_table._render_as_html(
        make_page=make_page,
        all_important=all_important,
        variables=not inline_css,
    )

    if inline_css:
        _try_import(name="css_inline", pip_install_line="pip install css-inline")
        from css_inline import inline, inline_fragment

        if make_page:
            return inline(html=table_html)

        else:
            # Obtain the `table_id` value from the Options (might be set, might be None)
            table_id = self._options.table_id.value

            id = random_id() if table_id is None else table_id

            # Compile the SCSS as CSS
            table_css = compile_scss(
                self, id=id, compress=False, all_important=all_important, variables=False
            )

            return inline_fragment(html=table_html, css=table_css)

    return table_html


def as_latex(self: GT, use_longtable: bool = False, tbl_pos: str | None = None) -> str:
    """
    Output a GT object as LaTeX

    The `as_latex()` method outputs a GT object as a LaTeX fragment. This method is useful for when
    you need to include a table as part of a LaTeX document. The LaTeX fragment contains the table
    as a string.

    :::{.callout-warning}
    `as_latex()` is still experimental.
    :::

    Parameters
    ----------

    use_longtable
        An option to use the `longtable` environment in LaTeX output. This is useful for tables that
        span multiple pages and don't require precise positioning.
    tbl_pos
        The position of the table in the LaTeX output when `use_longtable=False`. Valid values for
        positioning include `"!t"` (top of page), `"!b"` (bottom of the page), `"!h"` (here),
        `"!p"` (on a separate page), and `"!H"` (exactly here). If a value is not provided then the
        table will be placed at the top of the page; if in the Quarto render then the table
        positioning option will be ignored in favor of any setting within the Quarto rendering
        environment.

    Returns
    -------
    str
        A LaTeX fragment that contains the table.

    LaTeX packages
    --------------
    The LaTeX fragment uses commands from these packages, which need to be loaded in the
    document's preamble:

    - `booktabs` (always)
    - `longtable`, with `use_longtable=True`
    - `hyperref`, if the table has links from [`fmt_url()`](`great_tables.GT.fmt_url`) or
      [`fmt_email()`](`great_tables.GT.fmt_email`)
    - `anyfontsize` (optional), so that a `table_font_size=` set with `tab_options()` is used at
      exactly that size rather than the nearest available one

    For example, `\\usepackage{booktabs}` and `\\usepackage{longtable}`. Some currency symbols
    (e.g., `"₹"` for `"INR"`) need XeLaTeX or LuaLaTeX rather than pdfLaTeX (see
    [`fmt_currency()`](`great_tables.GT.fmt_currency`)).

    Limitations
    -----------
    The `as_latex()` method is still experimental and has some limitations. The following
    functionality that is supported in HTML output tables is not currently supported in LaTeX
    output tables:

    - footnotes (via the `tab_footnote()` method), which raise an error
    - the `fmt_nanoplot()` method, which raises an error
    - the [`fmt_image()`](`great_tables.GT.fmt_image`), `fmt_flag()`, and `fmt_icon()` methods,
      which issue a warning and leave the cell values unformatted
    - styles, whether set with the `tab_style()` or `data_color()` methods (a warning is issued
      and the table is rendered without them)
    - most options in the `tab_options()` method, particularly those that are specific to styling
      text, borders, or adding fill colors to cells (the ones that are used are `table_width=`,
      `table_font_size=`, `stub_indent_length=`, and `row_group_as_column=`), and so also the
      `opt_*()` methods that set them, such as `opt_stylize()`
    - interactive tables (via the `opt_interactive()` method), which are rendered as static
      tables

    As development continues, we will work to expand the capabilities of the `as_latex()` method to
    reduce these limitations and more clearly document what is and is not supported.

    Examples
    --------
    Let's use a subset of the `gtcars` dataset to create a new table.

    ```{python}
    from great_tables import GT, data
    from great_tables.data import gtcars
    import polars as pl

    gtcars_mini = (
        data.pl.gtcars
        .select(["mfr", "model", "msrp"])
        .head(5)
    )

    gt_tbl = (
        GT(gtcars_mini)
        .tab_header(
            title="Data Listing from the gtcars Dataset",
            subtitle="Only five rows from the dataset are shown here."
        )
        .fmt_currency(columns="msrp")
    )

    gt_tbl
    ```

    Now we can return the table as string of LaTeX code using the `as_latex()` method.

    ```{python}
    gt_tbl.as_latex()
    ```

    The LaTeX string contains the code just for the table (it's not a complete LaTeX document).
    This output can be useful for embedding a GT table in an existing LaTeX document.
    """
    built_table = self._build_data(context="latex")

    latex_table = _render_as_latex(data=built_table, use_longtable=use_longtable, tbl_pos=tbl_pos)

    return latex_table


# Create a list of all selenium webdrivers
WebDrivers: TypeAlias = Literal[
    "chrome",
    "firefox",
    "safari",
    "edge",
]

DebugDumpOptions: TypeAlias = Literal["zoom", "width_resize", "final_resize"]


def save(  # pragma: no cover
    self: GT,
    file: Path | str,
    selector: str = "table",
    scale: float = 1.0,
    expand: int = 5,
    web_driver: WebDrivers | webdriver.Remote = "chrome",
    window_size: tuple[int, int] = (6000, 6000),
    debug_port: int | None = None,
    encoding: str = "utf-8",
    _debug_dump: DebugDumpOptions | None = None,
) -> GTSelf:
    """
    Produce a high-resolution image file or PDF of the table.

    The output file is created by taking a screenshot of the table using a headless browser.

    Parameters
    ----------
    file
        The name of the file to save the image to. Accepts names ending with .png, .bmp, and other
        image extensions. Also accepts the extension .pdf.
    selector
        (NOT IMPLEMENTED) The HTML element name used to select table. Defaults to the whole table.
    scale
        The scaling factor that will be used when generating the image.  Lower values decrease
        resolution. A scale of 2 is equivalent to doubling the width of the table in pixels. Note
        that higher resolution results in larger file sizes.
    expand
        (NOT IMPLEMENTED) The number of pixels to expand the screenshot by.  This can be
        increased to capture more of the surrounding area, or decreased to capture less.
    web_driver
        The webdriver to use when taking the screenshot. Either a driver name, or webdriver
        instance. By default, uses Google Chrome. Supports `"firefox"` (Mozilla Firefox), `"safari"`
        (Apple Safari), and `"edge"` (Microsoft Edge).

        Specified browser must be installed. Note that if a webdriver instance is passed, options
        that require setting up a webdriver, like debug_port, will not be used.

        Chrome and Edge run with their sandbox turned off only when Python runs as root on Linux
        (e.g., in Google Colab or a Docker container), where these browsers won't start otherwise.
        To use other browser options, pass a configured webdriver instance (e.g.,
        `webdriver.Chrome(options=...)`).
    window_size
        The size of the browser window to use when laying out the table. This shouldn't be necessary
        to capture a table, but may affect the tables appearance.
    debug_port
        Port number to use for debugging. By default no debugging port is opened.
    encoding
        The character encoding used for the HTML content.
    _debug_dump
        Whether the saved image should be a big browser window, with key elements outlined. This is
        helpful for debugging this function's resizing, cropping heuristics. This is an internal
        parameter and subject to change.

    Returns
    -------
    GT
        The GT object is returned. This is the same object that the method is called on so that we
        can facilitate method chaining.

    Details
    -------
    We create the output file based on the HTML version of the table.

    This process is facilitated by two libraries:

    - `selenium`, which is used to control the Chrome browser and take a screenshot of the table.
    - `PIL`, which is used to crop the screenshot to only include the table element of the page.

    Both of these packages needs to be installed before attempting to save any table as an image
    file. The `selenium` package also requires the Chrome browser to be installed on the system.

    A pip-based reinstallation of **Great Tables** through the following command will install these
    required packages:

    ```bash
    pip install great_tables[extra]
    ```

    """
    warnings.warn(
        "GT.save() is deprecated and will be removed in a future release (mid-2027). "
        "Use GT.gtsave() instead, which uses the lightweight `nokap` package and does not "
        "require Selenium or Pillow.",
        FutureWarning,
        stacklevel=2,
    )

    # Import the required packages
    _try_import(name="selenium", pip_install_line="pip install selenium")

    from ._utils_selenium import _get_web_driver

    if selector != "table":
        raise NotImplementedError("Currently, only selector='table' is supported.")

    # If there is no file extension, add the .png extension
    if Path(file).suffix == "":
        file = str(Path(file).with_suffix(".png"))

    # Get the HTML content from the displayed output
    # Prepend utf-8 charset so the Chrome webdriver renders unicode correctly
    html_content = "<meta charset='utf-8'>" + as_raw_html(pin_mode(self))

    wdriver = _get_web_driver(web_driver)

    # run browser ----
    with (
        tempfile.TemporaryDirectory() as tmp_dir,
        wdriver(debug_port=debug_port) as headless_browser,
    ):
        # Write the HTML content to the temp file
        with open(f"{tmp_dir}/table.html", "w", encoding=encoding) as temp_file:
            temp_file.write(html_content)

        # Open the HTML file in the headless browser
        headless_browser.set_window_size(*window_size)
        headless_browser.get("file://" + temp_file.name)

        _save_screenshot(headless_browser, scale, file, debug=_debug_dump)

    if debug_port and web_driver not in {"chrome", "firefox"}:
        warnings.warn("debug_port argument only supported on chrome and firefox")
        debug_port = None

    if debug_port:
        input(
            f"Currently debugging on port {debug_port}.\n\n"
            "If you are using Chrome, enter chrome://inspect to preview the headless browser."
            "Other browsers may have different ways to preview headless browser sessions.\n\n"
            "Press enter to continue."
        )

    return self


def _save_screenshot(  # pragma: no cover
    driver: webdriver.Chrome, scale: float, path: str, debug: DebugDumpOptions | None
) -> None:
    from io import BytesIO

    from selenium.webdriver.common.by import By
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait

    # Based on: https://stackoverflow.com/a/52572919/
    # In some headless browsers, element position and width do not always reflect
    # css transforms like zoom.
    #
    # This approach works on the following assumptions:
    #   * Zoomed table width cannot always be obtained directly, but is its clientWidth * scale
    #   * Zoomed table height is obtained by the height of the div wrapping it
    #   * A sleep may be necessary before the final screen capture
    #
    # I can't say for sure whether the final sleep is needed. Only that it seems like
    # on CI with firefox sometimes the final screencapture is wider than necessary.
    original_size = driver.get_window_size()

    # set table zoom ----
    driver.execute_script(
        "var el = document.getElementsByTagName('table')[0]; "
        f"el.style.zoom = '{scale}'; "
        "el.parentNode.style.display='none'; "
        "el.parentNode.style.display='';"
    )

    if debug == "zoom":
        return _dump_debug_screenshot(driver, path)

    # get table width and height, resizing window as we go ----

    # the window can be bigger than the table, but smaller risks pushing text
    # onto new lines. this pads width and height for a little slack.
    # note that this is mostly to account for body, div padding, and table borders.
    crud_factor = 20
    outer_width, outer_height = driver.execute_script(
        "var w = window; return [w.outerWidth - w.innerWidth, w.outerHeight - w.innerHeight]"
    )
    offset_left, offset_top = driver.execute_script(
        "var div = document.body.childNodes[0]; return [div.offsetLeft, div.offsetTop];"
    )
    reported_width = driver.execute_script(
        "var el = document.getElementsByTagName('table')[0]; return el.clientWidth;"
    )
    required_width = (reported_width + offset_left * 2) * scale + crud_factor + outer_width

    # set to our required_width first, in case it changes the height of the table
    driver.set_window_size(required_width, original_size["height"])

    time.sleep(0.05)

    if debug == "width_resize":
        return _dump_debug_screenshot(driver, path)

    # height accounts for top-padding supplied by the browser (doubled to pad top and bottom)
    div_height = driver.execute_script(
        "var div = document.body.childNodes[0]; return div.scrollHeight;"
    )
    required_height = div_height + offset_top * 2 + outer_height

    # final resize window and capture image ----
    driver.set_window_size(required_width, required_height)

    if debug == "final_resize":
        return _dump_debug_screenshot(driver, path)

    el = WebDriverWait(driver, 1).until(EC.visibility_of_element_located((By.TAG_NAME, "body")))

    _try_import(name="PIL", pip_install_line="pip install pillow")

    from PIL import Image

    # convert to other formats (e.g. pdf, bmp) using PIL
    Image.open(fp=BytesIO(el.screenshot_as_png)).save(fp=path)


def _dump_debug_screenshot(driver, path):  # pragma: no cover
    driver.execute_script(
        "document.body.style.border = '3px solid blue'; "
        "document.body.childNodes[0].style.border = '3px solid orange'; "
        "document.getElementsByTagName('table')[0].style.border = '3px solid green'; "
    )
    driver.save_screenshot(path)


def write_raw_html(
    gt: GT,
    filename: str | Path,
    encoding: str = "utf-8",
    inline_css: bool = False,
    newline: str | None = None,
    make_page: bool = False,
    all_important: bool = False,
    runtime: Literal["inline", "none"] = "inline",
) -> None:
    """
    Write the table to an HTML file.

    This helper function saves the output of `GT.as_raw_html()` to an HTML file specified by the
    user.

    Parameters
    ----------
    gt
        A GT object.
    filename
        The name of the file to save the HTML. Can be a string or a `pathlib.Path` object.
    encoding
        The encoding used when writing the file. Defaults to 'utf-8'.
    inline_css
        An option to supply styles to table elements as inlined CSS styles. This is useful when
        including the table HTML as part of an HTML email message body, since inlined styles are
        largely supported in email clients over using CSS in a `<style>` block.
    newline
        The newline character to use when writing the file. Defaults to `os.linesep`.
    make_page
        If `True`, the table is wrapped in a complete HTML page, with `<html>`, `<head>` and
        `<body>` tags.
    all_important
        If `True`, all CSS declarations are marked with `!important`.
    runtime
        Whether an interactive table's HTML is followed by the runtime that makes it interactive,
        its JavaScript and CSS: `"inline"` (the default) or `"none"`, for a page that has the
        runtime once, however many tables it shows (see
        [`runtime_tags()`](`great_tables.web.runtime_tags`)). A static table has no runtime, so
        this doesn't change it.

    Returns
    -------
    None
        An HTML file is written to the specified path and the method returns `None`. (A `GTI`
        table with its rows as an asset, as [`i_scale()`](`great_tables.GTI.i_scale`) sets it,
        has the rows past its first page written beside it, to a file named as the HTML file is,
        with `.gti.json` for its extension.)
    """
    import os
    from urllib.parse import quote

    from ._gti._settings import settings_of
    from .gti import GTI

    rows = asset = None
    if isinstance(gt, GTI) and settings_of(gt).rows == "asset":
        # (Beside the page, as the table fetches it, by its name)
        asset = Path(filename).with_suffix(".gti.json")
        html_content, rows = gt._raw_html(
            inline_css, make_page, all_important, runtime, rows_src=quote(asset.name)
        )
    else:
        # (As the table renders itself: a `GTI` table renders as interactive HTML)
        html_content = gt.as_raw_html(
            inline_css=inline_css, make_page=make_page, all_important=all_important, runtime=runtime
        )

    newline = newline if newline is not None else os.linesep

    with open(filename, "w", encoding=encoding, newline=newline) as f:
        f.write(html_content)
    if asset is not None and rows is not None:
        asset.write_text(rows, encoding="utf-8")


# The formats gridwell writes from the table's gridwell IR (`as_gridwell()`): the ones Great Tables
# can't make itself, by file extension, with gridwell's name for each
_GRIDWELL_FORMATS = {
    ".svg": "svg",
    ".docx": "docx",
    ".xlsx": "xlsx",
    ".pptx": "pptx",
    ".rtf": "rtf",
    ".typ": "typst",
}

# The formats a headless browser makes from the table's HTML (with `nokap`)
_BROWSER_FORMATS = {".png", ".jpg", ".jpeg", ".webp", ".pdf"}


def gtsave(
    self: GT,
    file: Path | str,
    selector: str = "table",
    expand: int | tuple[int, int, int, int] = 5,
    zoom: float = 2.0,
    delay: float = 0.2,
    vwidth: int = 992,
    vheight: int = 744,
) -> GT:
    """
    Save a GT table to a file (PNG, JPEG, WebP, PDF, SVG, Word, Excel, PowerPoint, RTF, or Typst).

    The `gtsave()` method renders the table to an image or PDF using a headless Chrome browser via
    the `nokap` package. This provides a reliable way to produce high-resolution image files of
    tables without requiring Selenium or Playwright. Chrome or Chromium must be installed on the
    system for these formats.

    The other formats (SVG, Word, Excel, PowerPoint, RTF, and Typst) are written by
    [gridwell](https://github.com/rich-iannone/gridwell) from the table's gridwell IR (see
    `GT.as_gridwell()`), with no browser needed. Install gridwell with
    `pip install "great_tables[gridwell]"`. SVG output is experimental in gridwell, and its
    styling may change between gridwell releases.

    Parameters
    ----------
    file
        The file path to write the output to. The format is determined by the file extension:
        `.png`, `.jpg`/`.jpeg`, `.webp` for images; `.pdf` for PDF; and, with gridwell, `.svg` for
        SVG, `.docx` for Word, `.xlsx` for Excel, `.pptx` for PowerPoint, `.rtf` for RTF, and
        `.typ` for Typst. If no extension is provided, `.png` is assumed. The other arguments
        apply to images and PDF only.
    selector
        A CSS selector targeting the element to capture. Defaults to `"table"`, which captures just
        the table element with tight bounds.
    expand
        Padding (in pixels) to add around the captured element. A single integer applies equal
        padding on all sides. A 4-tuple specifies `(top, right, bottom, left)` padding individually.
        Defaults to `5`.
    zoom
        The scale factor for raster image output. Higher values produce higher resolution images.
        For example, `zoom=2` produces a retina-quality (2x) image. Defaults to `2.0`. Ignored for
        PDF output.
    delay
        Seconds to wait after page load before capturing. This is useful for ensuring that any
        web fonts or dynamic content have fully rendered. Defaults to `0.2`.
    vwidth
        Viewport width in pixels. This controls the layout width of the page and may affect how the
        table is rendered (e.g., responsive layouts). Defaults to `992`.
    vheight
        Viewport height in pixels. Defaults to `744`.

    Returns
    -------
    GT
        The GT object is returned (the same object the method is called on), facilitating method
        chaining.

    Examples
    --------
    Using a small subset of the `gtcars` dataset, let's create a table and save it to a PNG file.

    ```python
    from great_tables import GT, data
    from great_tables.data import gtcars
    import polars as pl

    gtcars_mini = (
        data.pl.gtcars
        .select(["mfr", "model", "msrp"])
        .head(5)
    )

    (
        GT(gtcars_mini)
        .tab_header(title="Some Cars from gtcars")
        .fmt_currency(columns="msrp")
        .gtsave("my_table.png")
    )
    ```

    Save a table as a high-resolution retina image with extra padding.

    ```python
    (
        GT(gtcars_mini)
        .fmt_currency(columns="msrp")
        .gtsave("my_table.png", zoom=3, expand=20)
    )
    ```

    Save a table as a PDF.

    ```python
    (
        GT(gtcars_mini)
        .fmt_currency(columns="msrp")
        .gtsave("my_table.pdf")
    )
    ```

    With gridwell installed, save the same table as SVG, or as a Word document.

    ```python
    GT(gtcars_mini).fmt_currency(columns="msrp").gtsave("my_table.svg")
    GT(gtcars_mini).fmt_currency(columns="msrp").gtsave("my_table.docx")
    ```
    """
    # If there is no file extension, default to .png
    out_path = Path(file)
    if out_path.suffix == "":
        out_path = out_path.with_suffix(".png")
    suffix = out_path.suffix.lower()

    if suffix in _GRIDWELL_FORMATS:
        gridwell = _try_import(
            name="gridwell", pip_install_line='pip install "great_tables[gridwell]"'
        )
        gridwell.Table(self.as_gridwell()).save(out_path, format=_GRIDWELL_FORMATS[suffix])
        return self

    # Validate file extension
    if suffix not in _BROWSER_FORMATS:
        supported = sorted(_BROWSER_FORMATS | set(_GRIDWELL_FORMATS))
        raise ValueError(
            f"Unsupported file extension: '{out_path.suffix}'. "
            f"Supported formats: {', '.join(supported)}"
        )

    import nokap

    # Get the HTML content of the table
    html_content = as_raw_html(pin_mode(self))

    # Use nokap.from_html() to render the table to an image or PDF
    nokap.from_html(
        html=html_content,
        file=out_path,
        selector=selector,
        expand=expand,
        zoom=zoom,
        delay=delay,
        vwidth=vwidth,
        vheight=vheight,
    )

    return self
